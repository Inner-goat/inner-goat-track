---
type: konzept
tags: [storytelling, prinzip, timing, zeitpunkt]
quelle: Marcos Storytelling-Diktat (08.07.2026)
erstellt: 2026-07-08
---

# Der richtige Zeitpunkt

Marcos Timing-Prinzip: **Im Storytelling ist es wichtig, den richtigen Zeitpunkt abzuwarten.** Nicht jede Geschichte gehört in jeden Moment — die stärkste Geschichte am falschen Zeitpunkt ist eine schwache Geschichte.

## Kernidee

> "Im Storytelling ist es wichtig, den richtigen Zeitpunkt abzuwarten." — Marco

Timing ist die zeitliche Seite der [[Relevanz]]. Eine Geschichte wird nicht nur *relevant* durch ihren Grund, sondern durch ihren **Moment**. Den richtigen Zeitpunkt abzuwarten heißt: die Geduld haben, eine Geschichte zurückzuhalten, bis der Raum, das Gespräch oder das Publikum reif dafür ist — und dann zuzuschlagen.

Wer zu früh erzählt, verschenkt die Wirkung, weil der Kontext fehlt. Wer zu spät erzählt, hat den Moment verpasst, in dem die Geschichte gebraucht wurde.

## Wie es funktioniert / Anwendung

- **Abwarten ist eine aktive Fähigkeit, kein Zögern.** Der richtige Zeitpunkt wird *erkannt* und *abgewartet* — nicht verpasst aus Unsicherheit.
- **Auf Öffnungen achten.** Der richtige Moment entsteht oft durch etwas, das im Gespräch/Publikum passiert: eine Frage, ein Schmerz, eine Behauptung, an die die Geschichte andockt.
- **In Formaten mit fixem Ablauf (Pitch, Keynote, Post):** Timing verschiebt sich auf *Reihenfolge und Platzierung* — an welcher Stelle im Bogen die Geschichte gesetzt wird.
- **Timing des Höhepunkts.** Wann fällt die Auflösung? Siehe [[Die Heldenreise-Kurve]] — Social Media hat den Zeitpunkt des Höhepunkts nach ganz vorne gezogen (Hook zuerst).

## Beispiel

Dieselbe Bruch-Geschichte kann in einem Erstgespräch deplatziert wirken und im dritten Gespräch — nachdem Vertrauen da ist und das Gegenüber eine verwandte Angst geäußert hat — genau ins Schwarze treffen. Die Geschichte hat sich nicht geändert. Nur der Zeitpunkt.

## Für Buch/Artikel

Der richtige Zeitpunkt ergänzt [[Relevanz]] um die Zeit-Achse: *Warum diese Geschichte (Relevanz) — und warum jetzt (Timing)?* Für ein Kapitel bietet sich der Kontrast an: die technisch perfekte Geschichte, die floppt, weil das Timing fehlt, gegen die einfache Geschichte, die trifft, weil der Moment stimmt. Verbindet sich mit der Hook-Logik (siehe [[Die Heldenreise-Kurve]]) und mit [[Reliving vs. Reporting]] (wann gehe ich in den Reliving-Modus?).

## Verwandte Konzepte

- [[Relevanz]] — Timing ist die zeitliche Dimension der Relevanz.
- [[Die Heldenreise-Kurve]] — Social Media hat den Zeitpunkt des Höhepunkts an den Anfang verschoben.
- [[Reliving vs. Reporting]] — den richtigen Moment wählen, um in die Szene zu gehen.
- [[Hook-Bibliothek]] — der Hook ist Timing in den ersten Sekunden.
- [[Storytelling als Lebensveränderung]] — Timing im eigenen Charakter-Bogen.

---

Zurück zu [[Storytelling Wissen]].
