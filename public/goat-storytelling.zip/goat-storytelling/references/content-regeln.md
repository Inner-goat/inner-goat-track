---
type: playbook
tags: [marco, storytelling, content, linkedin, regeln]
erstellt: 2026-07-08
---

# Storytelling-Content-Regeln

Wie jeder Storytelling-Post und jedes Video von [[Marco Maiworm]] aufgebaut sein muss. Verbindlich für alle Content-Erstellung — Tonalität siehe [[Schreibstil]].

## Die Grundregel

**Jeder Post/jedes Video = 1 Konzept/Methode klar erklärt + 1 geile Anekdote, die es illustriert und im Kopf hängen bleibt.**

**Why:** Marco will Mehrwert liefern (Methoden, Frameworks, Regeln) und sich als Storytelling-Experte positionieren, nicht als Selbstinszenierer.

- Konzept ohne Story = Vorlesung.
- Story ohne Konzept = Anekdote.
- Nur beides zusammen macht ihn zum Experten, den man sich merkt.

## Erlaubte Anekdoten-Quellen (in dieser Reihenfolge)

1. **Reale historische Storys** (Default) — z. B. Steve Jobs „1000 Songs", Nike „Just Do It" (Todeszelle-Zitat), Sara Blakelys Spanx-Anfang, MLK, Apollo 13, Kennedy „We choose to go to the moon", Netflix vs. Blockbuster.
2. **Kundenanekdoten anonymisiert** — NUR wenn Marco die echten Details liefert (Kunde X, Situation Y).
3. **Marcos eigene Erlebnisse** — NUR wenn Marco sie explizit erzählt und Details freigibt. Es wird NICHTS über Marco erfunden.
4. **Klar markierte Hypothesen** — „Stell dir vor…", „Angenommen ein Founder…", „Es ist wie…". Als Analogie/Gedankenexperiment eindeutig erkennbar. Nie als „ich habe erlebt" inszeniert.

## Verboten

Erfundene Marco-Ich-Storys, die real klingen („Ich stand vor 400 Leuten…", „Ein Kunde rief mich um 03:14 an…"). **Das zerstört Vertrauen, wenn es rauskommt.**

## How to apply

- Wenn Marco einen Post/ein Video will und keine echte Marco-Anekdote vorliegt → Quelle 1 (historisch) nutzen.
- Nur wenn Marco explizit Details liefert → Quelle 2/3.
- Quelle 4 als Verstärker, immer mit klarer Rahmung.

## Frequenz

Marco will **keinen starren Post-Rhythmus** vorgegeben bekommen. Nicht „3x/Woche" oder Ähnliches vorschlagen. Er entscheidet die Frequenz pro Woche selbst; der Assistent hält einen Backlog bereit.

## Verwandt

- [[Storytelling Wissen]] — der Wissens-Ordner, in dem der Content lebt
- [[Art of Breaking Yourself]] — Signature-Thema, häufigster Konzept-Winkel
- [[Outreach-Stil LinkedIn]] — Ton-Grundton (keine Emojis, direkt)
- [[Schreibstil]] — übergreifende Tonalität
