---
type: wissen
tags: [academy, storytelling, kommunikation, pitch, personal-branding, scr, mckinsey, heldenreise, karten-set]
reiter: Reiter 2 – Networking & Storytelling
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 2 – Storytelling & Kommunikation

Dieses Modul ist das Storytelling-Herzstück der [[Inner GOAT Academy]]. Nachdem Modul 1 gezeigt hat, wie echtes Netzwerken funktioniert (Vertrauen aufbauen, Host-Haltung), dreht sich hier alles um die andere Seite: **Was passiert, wenn du den Mund aufmachst?** Wie erzählst du, wer du bist, wie kommunizierst du dein Angebot, wie strukturierst du eine Präsentation, ein Gespräch, einen Post – und vor allem: *wie* klingst du dabei.

Die zentrale Überraschung, die das Modul durchzieht: **Was du sagst, ist bei weitem nicht das Wichtigste. Wie du es sagst — das ist entscheidend.** Von der Definition guten Storytellings über die McKinsey-SCR-Struktur, die Pitch-Perfect-Regel (65 % Ton, 25 % Körpersprache, 10 % Inhalt), die persönliche Vorher/Wendepunkt/Nachher-Geschichte, die Praxis wirksamer Geschichten, Marcos eigenes [[Storybuilder Cards|Storytelling-Karten-Set]] bis zu Personal Branding – jede Lektion baut einen Baustein auf.

Stark verlinkt ins [[Storytelling Wissen]]-Netz. Kern-Winkel: [[Der Bruch als Bauplan]] – der Wendepunkt, die geteilte Schwäche, die Verletzlichkeit als eigentlicher Ort der Verbindung.

---

## 01 · Einführung Storytelling & Kommunikation

Auftakt und Landkarte des Moduls. Video-Lektion mit substanziellem Lehrtext zu den Grundlagen des Storytellings.

**Die Kernthese vorweg:** Was du sagst, ist nicht das Wichtigste – *wie* du es sagst, ist entscheidend. Dieser Satz trägt das ganze Modul (und wird in Lektion 03 mit Zahlen unterlegt).

**Information vs. Geschichte** – der fundamentale Unterschied:

- **Informationen** aktivieren rationale Verarbeitung, nutzen abstrakte Konzepte, sind schwer zu verstehen und abzurufen, bieten keine Identifikationsmöglichkeit, tragen kein emotionales Potenzial, folgen einer rein logischen Abfolge und motivieren nicht.
- **Geschichten** aktivieren eine umfassende Verarbeitung, nutzen einfache Sprache und Konzepte, lassen sich leicht erinnern, haben Akteure (Identifikation), berühren unmittelbar, folgen einem spezifischen Verlauf mit Spannungsbogen und motivieren direkt.

**Was Storytelling ausmacht:** Es fasziniert, zeigt eine Entwicklung, stellt *nicht* die Marke in den Vordergrund, hat Konflikt und Herausforderung, wirbt nicht direkt, verfolgt langfristige/mittelbare Ziele, emotionalisiert (traurig, lustig …), ist sinnstiftend, interessant, realistisch, zeigt das Warum, personalisiert, hält den Menschen im Mittelpunkt und wirkt subtil.

**Wirkungsfaktoren einer Geschichte:**

- Ein Mensch steht im Mittelpunkt – oder eine Figur mit menschlichen Funktionen (z. B. Simba in „Der König der Löwen").
- Es gibt einen Spannungs- und Erzählbogen.
- Konflikte müssen gemeistert, Hindernisse überwunden werden.
- Die Figuren machen eine Entwicklung durch.
- Jede Menge Emotionen: Spannung, Spaß, Angst, Neugier, Trauer, Wut, Liebe …
- Eine tiefere Botschaft wird transportiert.
- Sie ist meist sehr einfach aufgebaut – selbst wenn kompliziert erzählt.

**Die Heldenreise** – drei Abschnitte: 1. Exposition, 2. Konflikt, 3. Auflösung. Ausformuliert in **12 Schritten** (nach Christopher Voglers Hollywood-Adaption von Campbell, „The Writer's Journey", 1992; Campbell selbst hatte in „The Hero with a Thousand Faces" eigentlich 17 Schritte):

1. Die gewohnte Welt
2. Ruf des Abenteuers
3. Weigerung des Helden
4. Begegnung mit dem Mentor
5. Überschreiten der ersten Schwelle
6. Bewährungsproben, Verbündete, Feinde
7. Vordringen zur tiefsten Höhle (gefährlichster Punkt)
8. Entscheidende Prüfung / Konfrontation / Überwindung des Gegners
9. Belohnung, Ergreifen des Schatzes
10. Rückweg in die gewohnte Welt
11. Auferstehung, Erneuerung, Verwandlung
12. Rückkehr mit dem Elixier

Siehe [[Die Heldenreise-Kurve|Die Heldenreise]] und [[Der Bruch als Bauplan]] (Schritt 11, die Verwandlung, ist Marcos Signature-Winkel).

**Regeln für gute Geschichten (aus dem Begleittext):**

- Kläre zuerst dein **Warum** – was ist deine Botschaft? Was soll das Publikum mitnehmen? (Damit die Geschichte keine hohle Aneinanderreihung von Worten bleibt.)
- Die Geschichte muss zu dir/deinem Unternehmen passen – authentisch, deine Werte spiegelnd. Nicht verstellen.
- **Mach dich angreifbar.** Gib etwas von dir preis, teile Ängste und Sorgen. Niemand identifiziert sich mit einem perfekten Menschen.
- **Sprich das Herz an** – provoziere emotionale Reaktionen (lachen, weinen, aufschreien). Emotionen verbinden Zuhörer miteinander.
- **Sprich auch den Verstand an** – gib Aha-Erlebnisse, neue Einsichten, Orientierung.
- **Hol das Publikum ab** – auf Augenhöhe, mit Empathie, schon beim Einstieg. Kenne dein Publikum: Was weiß es? Was will es wissen?
- **Erfülle dein Versprechen** – wenn du eine Frage aufwirfst, liefere die Antwort. Verschwende nicht die Zeit der Zuhörer.
- **Lass das Publikum teilhaben** – interaktiv aufbauen, den Zuhörer (wenigstens gedanklich) Teil der Handlung werden lassen.

**Ausblick auf die nächsten Lektionen:** SCR-Methode (McKinsey), der Pitch-Faktor (65 % Stimme/Tonalität), persönliche Geschichte.

**A5 – Pitch & Marke:** Die größten Deals werden nicht im Meeting entschieden – sondern Monate davor. Der eigentliche Pitch passiert früher: in den ersten Gesprächen, im Auftreten, in dem, was du online teilst.

**Community-Aufgabe:** Was ist gerade deine größte Herausforderung in der Kommunikation deines Angebots – klar strukturieren, überzeugend präsentieren oder die persönliche Geschichte teilen?

---

## 02 · McKinsey SCR — Deine Story strukturieren

McKinsey-Berater folgen bei jeder Präsentation demselben Grundprinzip: **SCR – Situation, Complication, Resolution** (Lage – Problem – Lösung). Eines der mächtigsten Kommunikationswerkzeuge überhaupt.

**Warum Struktur wichtiger ist als Inhalt:** Informationen ohne Struktur überfordern das Gehirn. Das Gehirn sucht das Narrativ, den roten Faden. Findet es ihn nicht, schaltet es ab (auch wenn der Zuhörer körperlich noch da ist). SCR gibt diesem Faden eine klare Form.

**Das SCR-Modell – 3 Schritte:**

1. **Situation (S)** – der Status quo. Wo stehen wir, was ist der Kontext? *Nicht* mit dem Problem, *nicht* mit der Lösung starten. Erst: die Ausgangslage, die beide Seiten kennen.
   *Beispiel:* „Du bist Coach und willst mehr Kunden gewinnen. Dein Angebot ist gut, aber du kommst nicht konsequent in die Sichtbarkeit."
2. **Complication (C)** – die Spannung, der emotionale Kern. Warum ist das ein Problem? Was verschärft die Lage? Der Moment, in dem der Zuhörer denkt: „Genau das ist mein Problem." Fehlt dieser Schritt, fehlt die Verbindung.
   *Beispiel:* „Ohne konsistente Sichtbarkeit werden potenzielle Kunden nicht auf dich aufmerksam – egal wie gut dein Angebot ist."
3. **Resolution (R)** – die Lösung. Klar, machbar, logisch. Und *erst jetzt*. Häufiger Fehler: mit der Lösung anfangen. Eine Lösung ohne aufgebaute Spannung klingt wie ein Angebot, nicht wie die Antwort auf ein echtes Problem.
   *Beispiel:* „Genau dafür haben wir ein System entwickelt – …"

**Zwei weitere McKinsey-Prinzipien:**

- **Erst denken, dann designen.** McKinsey beginnt nie mit Slides, sondern mit Stift und Papier – mit dem Argument. Die Visualisierung kommt am Ende, nicht am Anfang.
- **Jeder Slide ist ein Argument.** Die Überschrift eines Slides ist nicht das Thema, sondern die Kernaussage. Was soll die Person nach diesem Slide wissen? Das steht oben; was darunter steht, ist Beweisführung.

**SCR-Framework (Begleitdokument):**

| Schritt | Frage | Funktion |
|---|---|---|
| Situation | Was ist der Status quo? | Gemeinsamer Ausgangspunkt |
| Complication | Warum ist das ein Problem? | Emotionale Verbindung |
| Resolution | Was ist die Lösung? | Klare Handlungsoption |

**Regel:** Kein Slide ohne Kernaussage in der Überschrift. **Reihenfolge:** Erst denken (Word/Stift) → dann gestalten (Slides).

**Übung / Community-Aufgabe:** Schreibe dein aktuelles Angebot in genau 3 Sätzen nach SCR (S / C / R).

Verwandt: [[Relevanz]] (Complication = das, was den Zuhörer betrifft), [[Der Bruch als Bauplan]] (Complication als Bruchstelle).

---

## 03 · Pitch Perfect: 65% Ton, 25% Körpersprache

Die zentrale Zahlen-Lektion des Moduls. Laut einer Studie des Allensbach-Instituts verteilt sich die Wirkung in jeder Kommunikation so:

- **10 % Inhalt** – Worte, Argumente, Fakten
- **65 % Stimme** – Tonalität, Tempo, Stimmfarbe, Lautstärke
- **25 % Körpersprache** – Haltung, Mimik, Gestik, Augenkontakt

**Konsequenz:** Du kannst das Klügste, Durchdachteste sagen – es landet nicht, wenn Stimme und Körper nicht dazu passen. Umgekehrt: Mit wenigen einfachen Worten enorme Wirkung erzielen, wenn Stimme und Körper stimmig sind. Investiere die meiste Energie nicht in den Text, sondern in Haltung und Energie. Der Zuhörer entscheidet in den ersten Sekunden über nonverbale Signale, ob er vertraut und zuhören mag.

**Stimme – die unterschätzte Ressource** (transportiert nicht nur Information, sondern Emotion, Haltung, Überzeugung):

- **Tempo** – bewusst langsamer sprechen, als du denkst. Die meisten sprechen zu schnell, wenn sie nervös sind. Langsam = Sicherheit.
- **Pausen** – eine gute Pause ist mächtiger als zehn Worte. Sie gibt dem Gehirn Verarbeitungszeit und signalisiert Sicherheit („sicher genug, um zu schweigen").
- **Betonung** – welches Wort du betonst, verändert die Bedeutung komplett. Üben.
- **Stimmfarbe** – Wärme kommt aus der Tiefe. Flach/schnell = unsicher; aus dem Bauch = geerdet.

**Körpersprache** (permanente, unbewusst gelesene Signale):

- **Haltung** – aufrecht und offen = Selbstvertrauen; zusammengesackt/verschränkte Arme = Gegenteil.
- **Augenkontakt** – echter, entspannter Blickkontakt baut Verbindung („ich bin präsent"). Nicht starren.
- **Bewegungsgeschwindigkeit** – langsam/bewusst = Kontrolle; schnell/zappelig = Nervosität.

**Die 5 W der Vorbereitung** (für jeden Pitch, jede Präsentation, jedes Gespräch):

- **Wozu** – Was ist mein Ziel?
- **Warum** – Was ist meine Botschaft/Überzeugung?
- **Wem** – Wer ist mein Publikum? Was bewegt sie, was wissen sie schon?
- **Was** – Was sage ich konkret?
- **Wie** – In welchem Format, welcher Struktur?

**Die Kernbotschaft:** Wenn diese Person nur *einen* Satz mitnimmt – welcher soll das sein? Schreib ihn auf. Alles andere dient diesem Satz.

**Die 3 Wirkungsfaktoren (Begleitdokument):**

| Faktor | Anteil | Elemente |
|---|---|---|
| Stimme & Tonalität | **65 %** | Tempo, Pausen, Betonung, Stimmfarbe |
| Körpersprache | **25 %** | Haltung, Augenkontakt, Bewegung |
| Inhalt | **10 %** | Worte, Argumente, Fakten |

**Aufgabe / Community-Aufgabe:** Nimm dich 2 Minuten beim Erklären deines Angebots auf – dann ohne Ton anschauen. Was fällt dir auf (Körpersprache, Haltung, Bewegung)?

**B6 – Pitch Perfect:** Wer wirklich versteht, dass 65 % aus Ton/Stimme, 25 % aus Körpersprache und nur 10 % aus dem Inhalt kommen, investiert die meiste Energie in Haltung und Energie – nicht in den perfekten Text.

---

## 04 · Deine persönliche Geschichte erzählen

**„Fakten informieren. Geschichten verbinden."** Menschen erinnern sich nicht an Zahlen, Statistiken, Bullet Points – sondern an Geschichten. Und du hast eine Geschichte, sehr wahrscheinlich eine stärkere, als du denkst.

**Warum deine Geschichte wirkt – Neurowissenschaft, keine Floskel:** „People buy from people." Hört jemand eine Geschichte, in der er sich wiedererkennt, aktivieren sich **Spiegelneuronen**. Er erlebt und fühlt mit – und dieses Mitfühlen baut Vertrauen auf, schneller als jedes Argument. Wer sich zeigt (Erfahrungen, Herausforderungen, Wendepunkte), ist automatisch nahbar, glaubwürdig, vertrauenswürdig.

**Struktur einer starken persönlichen Geschichte** (universelle Drei-Phasen-Struktur – erkennbar das SCR-Prinzip aus Lektion 02):

1. **Vorher** – Wer warst du vor der Veränderung? Deine Situation, dein Problem, deine Unzufriedenheit.
2. **Der Wendepunkt** – Was ist passiert? Was hat sich verändert, was hast du erkannt? Muss kein dramatischer Moment sein – manchmal ein Gespräch, ein Buch, ein Misserfolg.
3. **Nachher** – Wer bist du jetzt? Was hat sich verändert? Und ganz wichtig: Was gibst du weiter?

**Tiefe entsteht durch geteilte Schwäche – nicht durch Stärke.** Die stärksten, verbindendsten Geschichten sind nicht die Erfolgsgeschichten, sondern die Momente der Verletzlichkeit. Wir vertrauen Menschen, die uns etwas zeigen, das sie sonst nicht zeigen, die ehrlich sind, sich öffnen. Das schafft emotionale Tiefe – und Tiefe schafft Verbindung. Nicht alles teilen, aber bewusst Momente wählen, in denen du *nicht* perfekt warst – und teilen, was du daraus gemacht hast.

**Was deine Story nicht sein muss:** nicht episch, nicht außergewöhnlich, nicht dramatisch. Eine Geschichte über die Erkenntnis, auf dem falschen Weg gewesen zu sein und umzukehren – stark. Ein kleiner Moment, der alles verändert hat – stark. **Echtheit schlägt Dramatik. Immer.**

**Frage zum Nachdenken:** Welcher Moment (oder Zeitraum) hat dich am meisten geprägt? Nicht der, auf den du am stolzesten bist – sondern der, der dich am meisten *verändert* hat. Das ist wahrscheinlich der Kern deiner Geschichte.

**3-Phasen-Struktur (Begleitdokument):**

| Phase | Inhalt | Frage |
|---|---|---|
| Vorher | Ausgangslage, Problem | Wer warst du? Was hat gefehlt? |
| Wendepunkt | Moment der Veränderung | Was ist passiert? Was hast du erkannt? |
| Nachher | Transformation & Weitergabe | Wer bist du jetzt? Was gibst du weiter? |

**Merksatz:** Tiefe entsteht durch geteilte Schwäche – nicht durch Stärke. **Aufgabe:** In 10 Minuten deine Geschichte in diesen drei Phasen aufschreiben – erst schreiben, nicht filtern.

**A4 – Personal Branding: People buy from people.** Zeige dich mit Haltung, mit Schwächen, mit echten Gedanken.

Diese Lektion ist der direkteste Bezug zu [[Der Bruch als Bauplan]] und dem Signature-Thema „Art of Breaking Yourself" – der Wendepunkt/Bruch als eigentlicher Bauplan der Story. Verwandt: [[Die 12 Plots]] (der Wandlungs-/Rebirth-Plot).

---

## 05 · Wirksame Geschichten in der Praxis

Praxis-Lektion, primär rund um ein YouTube-Video von Nel & Marco. Notizhafte, aber inhaltlich klare Lektion.

**Geschichten sind wirksam, wenn sie …**

- ehrlich und echt sind
- eine Struktur und einen roten Faden haben
- eine Botschaft haben
- Menschen sich damit identifizieren (Spiegelneuronen)
- andere Menschen einbinden
- Schwäche statt Stärke zeigen

**Praktische Hebel:**

- **Corporate Influencing & Testimonials** – lass andere deine Geschichten erzählen.
- **LinkedIn Achievement** – deine Kunden machen Beiträge über dich und deine Arbeit.
- **Ton, Stimme, Inhalt gelten auch in Schriftform** – über Bindestriche, viele Absätze etc. Es muss **snackable** sein.

**Finde dein Warum** (Kern der Praxis-Lektion, Anschluss an Simon Sineks „Start With Why"):

- **Grundidee:** Jede Geschichte wird von einem Kernmotiv angetrieben – einem „Warum", das Richtung, Ton und Botschaft bestimmt.
- **Kontext:** Wie bei Sinek ist es entscheidend, das fundamentale Warum zu verstehen. Ist es ein politisches Statement (wie Orwells „1984") oder Unterhaltung mit moralischen Untertönen (wie Rowlings „Harry Potter")?
- **Anwendung:** Erforsche die tiefere Motivation und den Zweck deiner Erzählung. Unterhalten, informieren, zum Handeln anregen, eine Botschaft vermitteln, eine Diskussion provozieren?
- **Schritte:**
  1. **Definiere dein Warum** – was ist der Hauptzweck der Geschichte, was willst du erreichen? Fokus auf tiefere Motive, Überzeugungen und Werte – nicht auf Gewinn oder Produkt.
  2. **Passe Ton und Stil an** – sobald das Warum klar ist, richte Ton, Stil und Erzählweise darauf aus.
  3. **Prüfe Konsistenz** – alle Elemente (Charaktere, Handlung, Dialoge) arbeiten auf das zentrale Warum hin.

Verwandt: Start With Why / Der Golden Circle, [[Relevanz]], [[Storytelling Wissen]].

---

## 06 · Storytelling Advanced: Das Karten-set

Vorstellung von **Marcos eigenem Storytelling-Modell** – dem Karten-Set der Storybuilder-Cards (siehe [[Storybuilder Cards|Storytelling-Karten-Set]]). Legt man aus jeder Kategorie eine Karte zusammen, entsteht ein Schritt-für-Schritt-Leitfaden durch alle Aspekte des Geschichtenerzählens – von der Ideenfindung bis zur Ausführung. Jede Karte ist ein Baustein der übergeordneten Erzählung; die sechs Kategorien decken die wesentlichen Elemente ab und bieten kreative Inspiration wie praktische Orientierung.

**Die sechs Kategorien:**

1. **Entdecken** (Die Landkarte der Möglichkeiten) – Leitfrage: *Weißt du, wo du deine Geschichte findest?*
2. **Grundidee** (Plot-Strukturen) – Leitfrage: *Weißt du, welche Art Geschichte du brauchst?* (Anschluss an [[Die 12 Plots]] und die [[Die Heldenreise-Kurve|Heldenreise]].)
3. **Geschichts-Formeln** (Wesentliche Elemente) – inspirieren lassen und erfahren: *Welche Aspekte braucht jede Geschichte?*
4. **Raum und Zeit** – den Ort/die Szenen finden und zeitliche Aspekte wie Tempo klären.
5. **Charaktere** (Persönlichkeit) – Leitfrage: *Weißt du, welche Rolle du und andere in dieser Geschichte haben?*
6. **Stilelemente** – Leitfrage: *Weißt du, wie du deine Geschichte erzählen sollst?*

Dieses Modell ist das inhaltliche Fundament der Storybuilder-Cards-App und Marcos didaktischer Kern. Siehe [[Storybuilder Cards]] und [[Storytelling Wissen]].

---

## 07 · Wer du bist als Person — Personal Branding & Self-Branding

Die tiefste Lektion des Moduls. **Die wichtigste Geschichte, die du je erzählst, ist nicht die im Pitch – es ist die Geschichte, die Menschen über dich erzählen, wenn du nicht im Raum bist. Das ist deine Personal Brand.**

**Personal Branding ist Storytelling. Storytelling ist Self-Branding.** Eine Marke ist eine verdichtete Geschichte. „Apple" → „Think different" (eine Haltung, kein Marktanteil). „Patagonia" → Berge, Verantwortung, ein Versprechen. Genauso bei dir: Hört jemand deinen Namen, läuft eine Mini-Geschichte ab. Frage: Hast du sie bewusst gestaltet – oder hat sie sich zufällig zusammengesetzt?

**Die drei Ps – Person · Profession · Passion** (drei Säulen; fehlt eine, kippt das Ganze):

- **Person** – wer du bist: Werte, Eigenheiten, Geschichte. Der Mensch hinter der Rolle.
- **Profession** – was du kannst: Expertise, Handwerk, konkreter Mehrwert.
- **Passion** – wofür du brennst: das Thema, bei dem dein Auge funkelt.

Nur Person = nett, aber unklar. Nur Profession = kompetent, aber austauschbar. Nur Passion = begeistert, aber nicht ernstzunehmen. **Alle drei verbunden = unverwechselbar.**

**Vision Board** (Klarheit nach innen, bevor du nach außen kommunizierst): 30 Minuten, intuitiv Bilder/Zitate/Wörter/Orte/Menschen sammeln, die etwas auslösen. Ziel ist kein hübsches Pinterest-Board, sondern ein **Muster** – welche Themen, Farben, Welten tauchen immer wieder auf? Da ist deine Story.

**Authentisch heißt nicht „einfach du selbst sein".** Das ist der häufigste Irrtum. Authentizität = etwas, das dir Spaß macht UND dich fordert. Nur Spaß = Hobby; nur Forderung = Pflicht. Der Sweet Spot ist der **Flow State** (Mihály Csíkszentmihályi): dort, wo Fähigkeiten und Herausforderung perfekt passen. Zu leicht = Langeweile, zu schwer = Angst, genau richtig = du verlierst die Zeit. Flow ist der ehrlichste Indikator für Authentizität – Menschen kaufen Flow.

**Sich selbst sein – und ein bisschen darüber hinaus.** Personal Branding heißt, dich bewusst zu inszenieren – bewusst, aber nicht künstlich. Wie ein guter Schauspieler: nicht eine andere Person, sondern eine *verdichtete Version* seiner selbst – mehr Kontur, klarere Linien, wiedererkennbar.

**Das Signature-Prinzip – der rote Teppich, der sich durchzieht.** Menschen erinnern sich an Bilder, Symbole, wiederkehrende Elemente. Starke Personal Brands arbeiten fast immer mit einem **Signature-Element** – einem visuellen/situativen Anker. Beispiele:

- Periodenprodukte → auf jedem Auftritt etwas Rotes anziehen → „Rot" wird deine Farbe.
- Mentale Gesundheit → ein kleines Schild mit einem Satz, den du am Anfang hochhältst.
- Coach für Kreative → derselbe Hut auf jedem Foto/Video → der Hut wird Symbol.
- Female Leadership → ein tatsächlicher roter Teppich, den du auf Events ausrollst.
- B2B-Sales → Sneaker zu jeder Präsentation → „Ich bin nicht die Krawatten-Person."

Der rote Teppich kann Outfit, Accessoire, Geste, Begrüßungsformel, wiederkehrende Pose, Handschrift oder eine Farbe in jedem Slide sein. Es muss nur eines sein: **Du, klar erkennbar.**

**Faustregel: spielerisch, nicht künstlich.** Das Signature-Element muss zu dir passen. Magst du keinen Hut, trag keinen. Steht dir Rot nicht, wähle eine andere Farbe. Fühlst du dich verkleidet, merken Menschen das in Sekunden – und du verlierst genau das Vertrauen, das du aufbauen wolltest. Nicht „was wäre auffällig?", sondern: **Was ist sowieso schon da – und kann ich es größer, klarer, konsistenter machen? Personal Branding ist Verstärkung, nicht Verkleidung.**

**Verhaltens-Branding** (zweite Ebene neben äußerer Wiedererkennung – wie verhältst du dich konsistent?): immer innerhalb von 24 h antworten (oder mit charmanter Notiz); Meetings mit einer Check-in-Frage beginnen; nach dem ersten Treffen eine handgeschriebene Karte schicken; eine wiederkehrende LinkedIn-Eröffnung. Keine Tricks – kleine, wiederholbare Gesten, die kumulativ die Marke bauen. Menschen erinnern sich an Muster.

**Zusammenfassung – innen klären, außen verdichten:**
1. Innen: Person, Profession, Passion. Vision Board. Flow als Kompass.
2. Außen: ein Signature-Element, das dich verstärkt – nicht verkleidet.
3. Verhalten: wiederholbare Gesten, an denen Menschen dich erkennen.

**Drei Säulen (Begleitdokument):**

| Säule | Frage | Mini-Übung |
|---|---|---|
| Person | Wer bist du? Welche Werte und Eigenheiten machen dich aus? | Drei Adjektive, die Freunde über dich sagen würden. |
| Profession | Was kannst du wirklich gut? Wofür kommen Menschen zu dir? | Was hast du in 12 Monaten dreimal von verschiedenen Menschen gehört? |
| Passion | Wofür brennst du? Welches Thema lässt dich nicht los? | Worüber hast du zuletzt unbezahlt zwei Stunden gesprochen? |

**Signature-Element-Brainstorm:** Farbe (konsistente Farbe in Outfit/Slides/Profilbild) · Objekt (Hut, Brille, Schal, Sneaker, Schild) · Geste (Begrüßung, Eröffnungssatz, Pose) · Format (wiederkehrendes Posting-Format, Newsletter-Rhythmus, z. B. „Montagmorgen-Mini-Insight") · Symbol (roter Teppich, Wandbild, Mascot).

**Authentizitäts-Test:** Würde ich das auch tun, wenn niemand zuschaut? Macht es Spaß UND fordert es mich? Würden enge Freunde sagen „ja, das bist du" – oder „komisch, das passt nicht"?

**Merksatz:** *Personal Brand ist nicht, wie du dich verkaufst – sondern wie Menschen sich an dich erinnern.*

**A4 – Personal Branding:** Marke entsteht aus Klarheit. Klarheit aus drei Schritten: Wisse, wer du bist (Person, Profession, Passion). Wähle, wie du sichtbar wirst (Signature-Element). Verhalte dich konsistent (wiederkehrende Gesten).

**Community-Aufgabe:** Welches Signature-Element könnte dein „roter Teppich" sein – und warum passt genau dieses zu dir (nicht nur „weil's auffällt")?

Verwandt: Personal Branding, [[Outreach-Stil LinkedIn]] (Signature-Sprachmuster: „Moin", „LG, Marco"), [[Art of Breaking Yourself|Signature-Thema „Art of Breaking Yourself"]].

---

## 08 · Abschluss Storytelling & Kommunikation

Abschluss von Modul 2 *und* des gesamten Reiters 2. Bringt Netzwerk und Kommunikation zusammen.

**Der Pitch passiert nicht im Meeting.** Kernsatz des Reiters: *„Die größten Deals werden nicht im Meeting entschieden – sondern Monate davor."* Wirklich überzeugen tust du selten im finalen Gespräch – da wird oft nur bestätigt, was Menschen längst über dich denken. Der eigentliche Pitch passiert früher: in ersten lockeren Gesprächen, im Auftreten, in dem, was du online teilst, im Verhalten, wenn niemand zuschaut. Dein ganzes Auftreten ist ein **kontinuierlicher Pitch** – kein Moment, ein Dauerzustand.

**Was du aus Reiter 2 mitnimmst:**

*Aus Modul 1 – Netzwerk & Community:*
- Netzwerken ist Gärtnern – nicht Jagen.
- Die Host-Haltung verändert alles.
- Qualität schlägt Quantität (Dunbar-Zahl).
- Dein Netzwerk spiegelt dich.

*Aus Modul 2 – Storytelling & Kommunikation:*
- **SCR** (Situation, Complication, Resolution) – die Struktur jeder starken Botschaft.
- **65 % Wirkung** kommt von deiner Stimme – investiere dort.
- **Echtheit schlägt Dramatik. Immer.**
- Menschen erinnern sich an Geschichten – nicht an Fakten.

**Die Verbindung beider Module:** Wer ein echtes Netzwerk aufbaut *und* klar kommuniziert, hat einen entscheidenden Vorteil – nicht wegen Strategie, sondern wegen **Vertrauen**. Vertrauen entsteht, wenn jemand merkt: Diese Person meint, was sie sagt, ist klar, denkt an andere.

**Deine nächsten Schritte:**
1. Persönliche Geschichte in 3 Phasen aufschreiben (Vorher / Wendepunkt / Nachher).
2. Angebot nach dem SCR-Prinzip formulieren.
3. Dich 2 Minuten aufnehmen und ohne Ton anschauen.
4. 3 Menschen im Netzwerk benennen, die du diese Woche aktiv kontaktierst.

**Abschluss-Checkliste Reiter 2:** persönliche Geschichte in 3 Phasen verschriftlicht · Angebot nach SCR formuliert · Video-Selbstanalyse (2 Min., ohne Ton) · Top-3-Netzwerk-Kontakte diese Woche kontaktiert · Host-Haltung in einer konkreten Situation eingenommen.

**Leitgedanke:** *„Der Pitch passiert nicht im Meeting – sondern Monate davor."*

**A5 – Pitch & Marke:** Marke entsteht aus Klarheit – nicht automatisch aus Kapital. Eine starke Marke braucht vor allem Vision und Werte. Wissen ist Potenzial, Umsetzung ist Momentum. Nur durch Iteration entsteht Fortschritt.

Weiter geht es in **Reiter 3 – Sales & Marketing & Personal Branding**.

---

## Verbindungen

- [[Inner GOAT Academy]] – übergeordnete Struktur
- [[Storytelling Wissen]] – zentraler Wissens-Ordner, in den dieses Modul stark einzahlt
- [[Storybuilder Cards]] (Storytelling-Karten-Set) – Lektion 06 ist das didaktische Fundament der App
- [[Der Bruch als Bauplan]] – Wendepunkt & geteilte Schwäche (Lektionen 01, 04)
- [[Die Heldenreise-Kurve|Die Heldenreise]] · [[Die 12 Plots]] – Plot-Strukturen (Lektionen 01, 06)
- [[Relevanz]] · Start With Why – Warum & Complication (Lektionen 02, 05)
- Personal Branding · [[Art of Breaking Yourself|Signature-Thema „Art of Breaking Yourself"]] – Lektion 07
- [[Outreach-Stil LinkedIn]] – Signature-Sprachmuster in der Praxis
