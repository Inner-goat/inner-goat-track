---
type: konzept
tags: [storytelling, prinzip, transformation, charakter, heldenreise]
quelle: Marcos Storytelling-Diktat (08.07.2026)
erstellt: 2026-07-08
---

# Storytelling als Lebensveränderung

Marcos größte Behauptung über Storytelling: **Storytelling ist die Kunst, sein Leben zu verändern.** Man kann die eigene Geschichte erzählen *und verändern*, indem man weiß, wo man als Charakter steht — und wie man "aus Ägypten geht, um ins Paradies zu kommen".

## Kernidee

> "Storytelling ist die Kunst, sein Leben zu verändern. Man kann seine eigene Geschichte erzählen und verändern, indem man weiß, wo man als Charakter steht und wie man 'aus Ägypten geht, um ins Paradies zu kommen'." — Marco

Storytelling ist hier nicht nur Kommunikations-Technik, sondern ein **Werkzeug der Selbst-Transformation**. Zwei Fähigkeiten stecken darin:

1. **Wissen, wo man als Charakter steht.** Du bist die Hauptfigur deiner eigenen Geschichte. An welchem Punkt des Bogens? Im gewohnten Alltag, am Bruch, in der Prüfung, auf dem Rückweg? Wer das erkennt, gewinnt Orientierung.
2. **Die Reise bewusst gehen.** "Aus Ägypten gehen, um ins Paradies zu kommen" — das Bild des Auszugs: einen alten, unhaltbaren Zustand verlassen (Ägypten), um in einen neuen zu gelangen (Paradies). Man kann seine Geschichte nicht nur erzählen, sondern durch das Erzählen und Erkennen aktiv verändern.

Wenn du deine Geschichte als Charakter-Reise begreifst, wirst du vom Erleidenden zum Gestalter deines eigenen Plots.

## Wie es funktioniert / Anwendung

- **Standort-Bestimmung.** Frag dich: *Wo stehe ich gerade in meiner eigenen Geschichte?* Das ist die Grundoperation — die Charakter-Position benennen.
- **Ägypten benennen.** Was ist der Zustand, der nicht mehr haltbar ist und den du verlassen musst? (Anschluss an [[Der Bruch als Bauplan]] — der Bruch ist oft der Auszug aus Ägypten.)
- **Paradies benennen.** Wohin gehst du? Nicht als vages "besser", sondern als konkreter neuer Zustand.
- **Die Geschichte erzählen, um sie zu verändern.** Das Erzählen ist Teil der Transformation, nicht nur ihr Bericht.

## Beispiel

Die Auszugs-Metapher ("aus Ägypten ins Paradies") ist ein Charakter-Reise-Bild: Der alte Zustand ist die Knechtschaft, aus der man aufbricht; die Reise durch die Wüste sind die Prüfungen; das Paradies ist der transformierte Zielzustand. Übertragen auf einen Founder: Ägypten = der Angestellten-Sicherheit-Käfig; die Wüste = die harten Gründungsjahre; das Paradies = die selbstbestimmte, wirksame Version seiner selbst. Vgl. die klassische [[Die Heldenreise-Kurve]].

## Für Buch/Artikel

Dies ist das philosophische Herzstück von Marcos Storytelling-Lehre und die Brücke zu [[Art of Breaking Yourself]]: Der Bruch ist der Auszug aus Ägypten. Ein Kapitel könnte lauten *"Du bist die Hauptfigur — also führe deinen Plot"*. Verbindet [[Olivenbaum-Essenz]] (wissen, wer du im Inneren bist → wissen, wo du als Charakter stehst) mit [[Lebe deine Geschichte]] (die Reise leben, um sie zu erzählen).

## Verwandte Konzepte

- [[Der Bruch als Bauplan]] — der Bruch als der Auszug aus Ägypten.
- [[Die Heldenreise-Kurve]] — die Charakter-Reise als Struktur.
- [[Lebe deine Geschichte]] — die Reise leben, nicht nur beschreiben.
- [[Olivenbaum-Essenz]] — Identität kennen, um den Standort zu kennen.
- [[Marcos eigene Breaking Story]] — Marcos eigener Auszug aus Ägypten.
- [[Art of Breaking Yourself]] — Signature-Thema der Transformation.

---

Zurück zu [[Storytelling Wissen]].
