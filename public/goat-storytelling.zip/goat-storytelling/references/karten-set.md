---
type: wissen
tags: [storytelling, archetypen, pearson, tafelrunde, ritter, quiz, storybuilder]
quelle: Notion
erstellt: 2026-07-08
---

# Storytelling Karten-Set

Das Herzstück des Ritter-Persönlichkeitstests von [[Storybuilder Cards]]: ein vollständiges Mapping der 12 Pearson-Archetypen auf Planet, Sternzeichen und einen Ritter der Artus-Tafelrunde. „Welcher Ritter bist du?" übersetzt einen Jung/Pearson-Archetyp in eine erzählbare Figur — damit User ihren eigenen Archetyp als Story-Charakter erleben statt als abstraktes Etikett. Quelle: Notion-Notiz „Storytelling cards" — „so wie wir es im System gebaut haben".

## Warum die Ritter-Metapher

Der Persönlichkeitstest basiert auf den 12 Archetypen nach Carl Gustav Jung bzw. Carol S. Pearson. Statt den Archetyp trocken zu benennen, bekommt jede/r einen Ritter der Tafelrunde zugewiesen — plus den passenden Planeten (astrologische Grundenergie) und das Sternzeichen. Die Figur macht den Archetyp erzählbar und verbindet Selbsterkenntnis mit einer konkreten Heldenrolle. Das speist direkt in die Story-DNA (siehe [[Story-DNA PDF Output]]) und in die Plot-Wahl (siehe [[Die 12 Plots]]).

## Das 12er-Archetyp-Mapping

| Pearson-Archetyp | Hauptmotivation | Planet | Sternzeichen | Ritter der Tafelrunde |
|---|---|---|---|---|
| Innocent · Der Reine | Vertrauen, Hingabe, höhere Wahrheit | Neptun | Fische | Galahad — der reinste Ritter, findet den Gral |
| Explorer · Der Entdecker | Suche, Freiheit, Heimat-Finden | Mond | Krebs | Parzival — der naive Suchende auf Gralfahrt |
| Hero · Der Held | Mut, Sieg, direkte Aktion | Mars | Widder | Gawain — der Schwertritter, kämpferisch und schnell |
| Outlaw · Der Rebell | Befreiung, Untergrabung | Venus (Schatten) | Waage | Mordred — der subtile Verräter, zerstört Camelot |
| Sage · Der Weise | Wahrheit, Verstehen, Lehre | Jupiter | Schütze | Bors — Gralsritter, weiser Berater |
| Lover · Der Liebende | Intimität, Hingabe, Schönheit | Venus | Stier | Lanzelot — größter Ritter, durch Liebe gefallen |
| Magician · Der Magier | Transformation, Tiefe, Macht | Pluto | Skorpion | Tristan — durch Bruch und Schmerz transformiert |
| Creator · Der Schöpfer | Innovation, Vision, Originalität | Uranus | Wassermann | Merlin — Zauberer, Visionär, Erbauer Camelots |
| Ruler · Der Herrscher | Verantwortung, Repräsentation | Sonne | Löwe | Artur — König, Zentrum der Tafel |
| Caregiver · Der Beschützer | Dienst, Sorgfalt, Loyalität | Merkur | Jungfrau | Gareth — der Treue, dient im Verborgenen |
| Jester · Der Narr | Wahrheit durch Witz, Spott | Merkur | Zwillinge | Kay — der Spötter, scharfe Zunge |
| Everyman · Der Verlässliche | Zugehörigkeit, Realismus | Saturn | Steinbock | Bedivere — der Veteran, schon viel durchlebt |

## Anmerkungen zum Mapping

- **Venus doppelt:** Der Lover (Stier) trägt die helle Venus, der Outlaw (Waage) die Venus im Schatten — zwei Seiten derselben Grundkraft.
- **Merkur doppelt:** Caregiver (Jungfrau) und Jester (Zwillinge) teilen sich Merkur — die beiden Merkur-Sternzeichen.
- **Der Bruch als Bauplan:** Tristan (Magician) ist explizit die Figur, die „durch Bruch und Schmerz transformiert" wird — passt zu Marcos Signature-Thema (siehe [[Der Bruch als Bauplan]]) und der Rebirth-Struktur (siehe [[Olivenbaum-Essenz]]).
- Die 72 Karten des Cards-Decks selbst liegen in 6 Ebenen; dieses Archetyp-Raster ist die Persönlichkeits-Grundlage, auf der das Ritter-Quiz aufsetzt.

## Verwandte Notizen

- [[Die 12 Plots]] — die Plotstrukturen, aus denen im Karten-Set Geschichten gebaut werden
- [[Storybuilder Cards]] — die App, die dieses Mapping im Ritter-Quiz einsetzt
- [[Olivenbaum-Essenz]] — Identitäts-/Why-Kern, in den der Archetyp einfließt
- [[Der Bruch als Bauplan]] — Marcos Signature-Winkel (Transformation durch Bruch)
- [[Storytelling Wissen]] — Wissens-Hub Storytelling
