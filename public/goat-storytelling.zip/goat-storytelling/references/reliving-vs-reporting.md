---
type: konzept
tags: [storytelling, prinzip, reliving, präsens, body-language]
quelle: Marcos Storytelling-Diktat (08.07.2026)
erstellt: 2026-07-08
---

# Reliving vs. Reporting

Reliving vs. Reporting ist Marcos Prinzip der Unmittelbarkeit: Erzähle so, dass du die Szene **wieder-erlebst** (Reliving), statt sie nur zu **berichten** (Reporting). Das Werkzeug dafür: im Präsens sprechen, das [[Six Senses Framework]] nutzen, Body Language einsetzen.

## Kernidee

> "Reliving or Reporting: Versuch, im Präsens zu sprechen, nutz das 6-Senses-Framework, benutze Body Language." — Marco

Es gibt zwei Modi, eine Geschichte zu erzählen:

- **Reporting (berichten):** Du stehst außerhalb der Szene und referierst, was passiert *ist*. Vergangenheit, Distanz, Zusammenfassung. Der Zuhörer bekommt Information.
- **Reliving (wieder-erleben):** Du gehst zurück *in* die Szene und durchlebst sie erneut, während du erzählst. Präsens, Nähe, Sinne, Körper. Der Zuhörer erlebt mit.

Reliving ist der Unterschied zwischen "ich erzähle dir, was war" und "wir sind gerade dort".

## Die drei Werkzeuge des Reliving

1. **Präsens sprechen.** Nicht "ich stand vor 400 Leuten", sondern "ich stehe vor 400 Leuten". Das Präsens zieht Erzähler und Zuhörer gemeinsam in den Moment.
2. **Six Senses nutzen.** Sehen, Hören, Fühlen, Schmecken, Riechen + Emotion — das macht die Szene wieder erlebbar (siehe [[Six Senses Framework]]). Marcos Frage: *was hast du gefühlt und gerochen?*
3. **Body Language einsetzen.** Der Körper erzählt mit — Haltung, Geste, Blick, Stimme. Wieder-Erleben passiert auch physisch, nicht nur sprachlich.

## Wie es funktioniert / Anwendung

- **Test:** Hörst du dich "ich habe … / dann war … / danach ist …" sagen, bist du im Reporting-Modus. Wechsle ins Präsens und geh in die Szene.
- **Für gesprochenes Storytelling (Bühne, Video, Pitch):** Body Language ist voll verfügbar — nutze sie bewusst als vierte Dimension.
- **Für Text (LinkedIn, Buch):** Präsens + Six Senses tragen das Reliving; Body Language wird zu beschriebener Körperlichkeit ("meine Hände zittern").

## Beispiel

- **Reporting:** "Vor drei Jahren hatte ich einen wichtigen Pitch und war sehr nervös, aber am Ende lief es gut."
- **Reliving:** "Ich stehe im Aufzug hoch zum 14. Stock. Meine Handflächen sind nass, mein Herz schlägt bis in den Hals, es riecht nach frischem Teppich und kaltem Kaffee. Die Türen gehen auf — und da sitzen sie schon."

## Für Buch/Artikel

Reliving vs. Reporting ist die praktische Anwendung von [[Six Senses Framework]] und ein Kern-Kapitel für jedes Storytelling-Handwerk. Es lässt sich als Vorher/Nachher-Übung schreiben: dieselbe Szene einmal berichtet, einmal wieder-erlebt. Verbunden mit [[Der richtige Zeitpunkt]] (wann relive ich?) und [[Olivenbaum-Essenz]] (nur was innerlich gespürt wurde, lässt sich wieder-erleben).

## Verwandte Konzepte

- [[Six Senses Framework]] — das zentrale Werkzeug des Wieder-Erlebens.
- [[Relevanz]] — Reliving verstärkt eine relevante Geschichte, ersetzt Relevanz nie.
- [[Olivenbaum-Essenz]] — Wieder-Erleben setzt inneren Kontakt voraus.
- [[Lebe deine Geschichte]] — nur Gelebtes lässt sich wieder-erleben.
- [[Die Heldenreise-Kurve]] — Reliving an den Höhepunkt-Beats setzen.

---

Zurück zu [[Storytelling Wissen]].
