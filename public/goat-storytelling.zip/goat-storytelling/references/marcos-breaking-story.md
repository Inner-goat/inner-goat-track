---
type: konzept
tags: [storytelling, bruch, transformation, marco, persönlich, signature-thema]
quelle: Mailenstein/Storytelling Wissen/07_Marco_Personal_Storys/rohmaterial.md + Marcos Diktat 08.07.2026
erstellt: 2026-07-08
---

# Marcos eigene Breaking Story

**Worum es geht:** Marcos persönlicher Bruch, strukturiert nach [[Der Bruch als Bauplan]]. Das ist die glaubwürdigste Version des Signature-Themas — die eigene. Bislang ist das Rohmaterial noch dünn: Die Prompt-Sets stehen, aber die Antworten fehlen. Dies ist das **Gerüst plus gezielte Fragen**, das gefüllt wird, sobald Marco liefert.

> **Sensibel behandeln.** Der Bruch muss echt sein und darf nicht erfunden werden (siehe [[Storytelling-Content-Regeln]]). Diese Notiz ist ein privater Arbeitsraum, kein Veröffentlichungs-Text. Was hier reinkommt, entscheidet Marco.

Verwandt: [[Der Bruch als Bauplan]] · [[Breaking-Yourself-Beispiele]] · [[Art of Breaking Yourself]] · [[Lebe deine Geschichte]] · [[Marco Maiworm]]

---

## Kernidee

Marco lehrt: *"Du musst erst sterben — oder zumindest Teile von dir — um neugeboren zu werden."* Ein Founder, der den Bruch nur andeutet, klingt wie ein Vortrag über Resilienz. Ein Founder, der den eigenen Bruch als Bauplan präzise erzählt, klingt wie ein Mensch, dem man vertraut.

Also braucht das Framework eine getragene, **eigene** Marco-Story — nach genau denselben 6 Beats, an denen [[Breaking-Yourself-Beispiele]] die fremden Storys zerlegt. Und sie kann nur so gut sein wie das Rohmaterial, das Marco liefert. Deshalb: erst leben, dann erzählen ([[Lebe deine Geschichte]]).

---

## Das Gerüst (die 6 Beats — zu füllen)

Sobald Marco das Material liefert, wird jeder Beat konkret, sinnlich, im Präsens (→ [[Reliving vs. Reporting]], [[Six Senses Framework]]) ausgeschrieben.

1. **Vorher-Selbst** — Wer war Marco vor dem Bruch? Konkret. Ein Bild, ein Satz, ein Alltag. *(offen)*
2. **Auslöser** — Der EINE Moment, an dem klar wurde: so geht es nicht weiter. Nicht der Prozess — der Moment. *(offen)*
3. **Weigerung** — Wogegen hat Marco sich gewehrt? Was wollte er nicht loslassen? *(offen)*
4. **Der Riss** — Was ist gestorben? Der Punkt ohne Rückkehr. *(offen)*
5. **Motivationsverschiebung** — Was tut Marco heute aus einem NEUEN Grund? *Warum machen wir, was wir machen?* — für Marco selbst beantwortet. *(offen)*
6. **Neue Handlungsebene** — Was ist heute möglich, das vorher nicht ging (Inner GOAT, Storytelling-Positionierung, der verkaufte Skill)? *(offen)*

**Welcher der 4 Auslöser?** (körperlich / moralisch / Erwartung / "nicht genug") — noch zu bestimmen. Möglich ist auch eine Kombination.

---

## Gezielte Fragen an Marco (nicht alle auf einmal — 1–2 pro Woche)

Aus dem Rohmaterial-Set. Formlos beantworten, Stichpunkte reichen. Antworten hier unter "Antworten" reinschreiben, dann wird die Story gebaut.

**Wendepunkte (Set A):**
- Der Moment, in dem du wusstest, dass du Gründer wirst — bevor du es jemandem gesagt hast.
- Der Moment, in dem du Angst hattest, das Ganze aufzugeben.
- Die letzte Entscheidung, die du gegen den Rat aller getroffen hast.

**Konflikt & Preis (Set B — für den Bruch am wichtigsten):**
- Ein Preis, den du für einen Fehler bezahlt hast (in Euro, in Zeit, in Menschen).
- *(Interne Bank, NICHT für externe Storys: die Streit-Erfahrungen — Elisa/Anabel — als Rohstoff für den Riss, aber nur intern.)*

**Menschen & Sätze (Set C):**
- Ein Satz, den ein Mentor mal zu dir gesagt hat, der dich bis heute begleitet.
- Ein Satz von Familie, der eine Business-Entscheidung geändert hat.

**Zukunft (Set E):**
- Was ist der eine Satz, mit dem du eines Tages zitiert werden willst?
- Wovor hast du wirklich Angst — beruflich?

> Format pro Antwort: *Wo/wann/wer · Was ist passiert (Szene) · Was hab ich gefühlt · Was ist danach passiert · Was hab ich draus gelernt · Für welches Publikum ist die Lehre gut.*

---

## Für Buch/Artikel

- Marcos eigener Bruch als **Rahmen-Story** eines Kapitels von [[Der Bruch als Bauplan]] — der Autor zerlegt zuerst fremde Storys, dann die eigene, um zu zeigen, dass das Framework auf einen selbst anwendbar ist.
- Sobald der Auslöser-Typ feststeht: als Ankerbeispiel für genau diese Kategorie in [[Breaking-Yourself-Beispiele]] spiegeln.

---

## Antworten

*(Hier trägt Marco seine Antworten ein. Bis dahin bleibt die Story ein Gerüst.)*

---

## Verwandte Konzepte

- [[Der Bruch als Bauplan]] — das Framework, nach dem diese Story gebaut wird
- [[Breaking-Yourself-Beispiele]] — die fremden Storys als Muster
- [[Lebe deine Geschichte]] — erst leben, dann erzählen
- [[Reliving vs. Reporting]] · [[Six Senses Framework]] · [[Der richtige Zeitpunkt]] — Handwerk fürs Ausschreiben
- [[Art of Breaking Yourself]] · [[Marco Maiworm]] · [[Storytelling Wissen]]
