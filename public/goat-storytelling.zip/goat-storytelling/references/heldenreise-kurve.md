---
type: konzept
tags: [storytelling, heldenreise, hero-journey, campbell, vogler, social-media, hook]
quelle: Marcos Diktat 08.07.2026 + externe Heldenreise-Recherche (Campbell/Vogler)
erstellt: 2026-07-08
---

# Die Heldenreise-Kurve

**Worum es geht:** Die klassische Heldenreise ist eine Kurve — flacher Aufbau, langsamer Anstieg, später Höhepunkt. Marcos Punkt: **Social Media hat diese Kurve gekippt.** Heute steigt man bei ~80 % ein — der Hook/Höhepunkt steht am Anfang, nicht mehr der langsame Aufbau.

Verwandt: [[Der Bruch als Bauplan]] · [[Hook-Bibliothek]] · [[Die 12 Plots]] · [[Kern-Frameworks]] · [[Der richtige Zeitpunkt]]

---

## Kernidee (Marcos Diktat, wortgetreu)

> **Die Heldenreise-Kurve** und das, was Social Media damit angestellt hat: Jetzt fängt sie bei 80 % an (d.h. der Hook/Höhepunkt steht am Anfang, nicht mehr der langsame Aufbau).

Die klassische Erzählung baut sich auf: gewohnte Welt → Prüfungen → Krise → Rückkehr. Auf einer Kurve gelesen ist das ein langsamer Anstieg mit spätem Höhepunkt. In Kurzformaten (Reels, Shorts, TikTok, LinkedIn) hat man diesen Vorlauf nicht: Der Zuschauer scrollt weiter, bevor der Aufbau überhaupt trägt.

**Also klappt man die Kurve nach vorne:** Man beginnt nah an dem, was in der langen Fassung der Höhepunkt (die ~80-%-Marke) wäre. Erst der Peak, dann — wenn Aufmerksamkeit da ist — der Kontext.

---

## Wie es funktioniert / Anwendung

### Die klassische Kurve (der Rahmen, aus dem [[Der Bruch als Bauplan]] eine Station isoliert)

Grob in drei Akten: **Aufbruch → Einweihung/Prüfungen → Rückkehr.** Der Bruch sitzt im mittleren Akt (die Krise / Death & Rebirth).

### Die neue, gekippte Kurve für Social Media

Praktiker-Aufbau eines Kurzformats:

1. **Hook (0–3 s)** — der Höhepunkt zuerst. Die ~80-%-Marke der klassischen Story steht ganz vorne. → [[Hook-Bibliothek]]
2. **Body / Eskalation** — der zurückgehaltene Kontext, der den Hook auflöst.
3. **Payoff** — die eigentliche Auflösung, spät.
4. **CTA / Loop** — die letzten Sekunden.

Für den [[Der Bruch als Bauplan]] heißt das konkret: nicht mit dem **Vorher-Selbst** anfangen (Beat 1), sondern mit dem **Riss** oder der **Motivationsverschiebung** (Beat 4/5) — und den Vorher-Zustand danach nachliefern.

---

## Beispiel

**Klassisch:** "Als ich 15 war, liebte ich Basketball. Ich trainierte jeden Tag. Dann, eines Tages, verpasste ich das Team…" (langsamer Aufbau, Höhepunkt spät)

**Gekippt (bei 80 % eingestiegen):** "Der schlimmste Tag meines Lebens machte mich zum besten Spieler der Welt." → *dann* der Kontext. Der Hook ist der Peak, der Aufbau kommt danach.

---

## Für Buch/Artikel

- Kapitel-Idee: "Warum die Heldenreise heute rückwärts erzählt wird." Erst die klassische Kurve (Campbell/Vogler), dann Marcos These vom 80-%-Einstieg, dann die Brücke zur [[Hook-Bibliothek]].
- Als Übung: eine [[Breaking-Yourself-Beispiele]]-Story einmal klassisch und einmal gekippt aufschreiben — der Unterschied ist sofort spürbar.

---

## 📎 Kontext (extern recherchiert)

Zur Fundierung — Marcos These vom "80-%-Einstieg" ist an etabliertes Wissen anschlussfähig, aber der exakte Prozentwert ist Marcos eigene Heuristik, keine kanonische Quelle.

**[ETABLIERT] Die klassische Heldenreise:**
- **Joseph Campbell**, *The Hero with a Thousand Faces* (1949): prägt den Begriff **Monomythos**; ursprünglich 17 Stationen, kulturübergreifend. Drei Akte: Departure (Aufbruch) → Initiation (Prüfungen) → Return (Rückkehr).
- **Christopher Vogler**, *The Writer's Journey* (1992): adaptiert das zu **12 Stufen** (Hollywood-Standard, funktions- statt mythologisch benannt):
  1. Ordinary World (gewohnte Welt)
  2. Call to Adventure (Ruf des Abenteuers)
  3. Refusal of the Call (Weigerung)
  4. Meeting the Mentor (Begegnung mit dem Mentor)
  5. Crossing the Threshold (Überschreiten der Schwelle)
  6. Tests, Allies, Enemies (Prüfungen, Verbündete, Feinde)
  7. Approach to the Inmost Cave (Vordringen zur tiefsten Höhle)
  8. The Ordeal (die entscheidende Prüfung / Krise)
  9. Reward / Seizing the Sword (Belohnung)
  10. The Road Back (Rückweg)
  11. Resurrection (Auferstehung / finale Läuterung)
  12. Return with the Elixir (Rückkehr mit dem Elixier)
- **[HINWEIS]** Als Kurve: flacher Start (gewohnte Welt), Anstieg über Prüfungen, Höhepunkt in Ordeal/Resurrection, Auflösung in der transformierten Rückkehr. Der Bruch aus [[Der Bruch als Bauplan]] = Stufe 8/11.

**[VERBREITET, Praktiker-Konsens] Was Social Media verändert hat:**
- **Kondensierung:** Die volle 12/17-Stufen-Reise wird für Kurzformate auf wenige Beats reduziert — oft zurück auf Campbells 3 Kern-Akte. TikTok/Reels "komprimieren die Reise in 60-Sekunden-Kapitel".
- **In medias res** [ETABLIERT als literarische Technik]: mitten in die Handlung einsteigen statt bei der gewohnten Welt. In sehr kurzen Formaten startet man nah an dem, was in der langen Fassung der Höhepunkt wäre. Filmbeispiele: *Star Wars* (Weltraumschlacht als Eröffnung), *Pulp Fiction*. Der ruhige "Ordinary World"-Aufbau wird nach vorne geklappt oder gestrichen.
- **Hook-Primat / die ersten 3–8 Sekunden:** Der Einstieg entscheidet, bevor der Algorithmus den Rest bewertet. Primäre Kennzahl ist die 3-Sekunden-View-Rate (Hook-KPI), nicht die Completion-Rate. Praxis-Faustregel: unter ~30 % 3-Sek-View-Rate ist der Hook gescheitert.
- **[HINWEIS zum "80 %"] :** In der Praxisliteratur taucht "80 %" als **Grenze zwischen Eskalation und Payoff** auf (Body läuft bis ~80 % der Laufzeit, dann Auszahlung). Marcos Formulierung — "man steigt bei 80 % der Story ein" — meint denselben Effekt aus Erzähler-Sicht: man startet NAH AM HÖHEPUNKT (in medias res / Hook zuerst) und lässt die Auszahlung spät fallen. Eine kanonische Quelle, die wörtlich "beim 80-%-Punkt einsteigen" prägt, ist NICHT verifizierbar → **Marcos Heuristik**, nicht etablierte Lehre.

---

## Verwandte Konzepte

- [[Der Bruch als Bauplan]] — isoliert Stufe 8/11 (Ordeal/Resurrection) als eigenen Bauplan
- [[Hook-Bibliothek]] — der Hook, der aus dem gekippten Einstieg entsteht
- [[Die 12 Plots]] — Plot-Typologien als Alternative zur Stufen-Struktur
- [[Kern-Frameworks]] — die Heldenreise im Werkzeugkasten
- [[Der richtige Zeitpunkt]] — wann welcher Beat fällt
- [[Reliving vs. Reporting]] · [[Six Senses Framework]] — Handwerk fürs Ausschreiben
- [[Storytelling Wissen]]
