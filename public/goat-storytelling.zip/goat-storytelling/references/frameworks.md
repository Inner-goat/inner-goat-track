# Kern-Frameworks

Die belastbaren Werkzeuge. Kein akademischer Zoo — nur das, was auf LinkedIn, im Verkauf, in Keynotes und in YouTube-Skripten wirklich zieht.

Für jedes Framework: **Kern**, **Struktur**, **Wann einsetzen**, **Beispiel-Skelett**.

---

## 1. StoryBrand (Donald Miller) — der Vertriebs-Standard

**Kern:** Der Kunde ist der Held, nicht du. Du bist der Guide.

**Struktur (SB7):**
1. Held mit einem Problem
2. Trifft einen Guide (das bist du/deine Marke)
3. Der einen Plan gibt
4. Und ihn zum Handeln aufruft
5. Damit er Scheitern vermeidet
6. Und Erfolg erlebt
7. Transformation

**Wann einsetzen:** Landingpages, Sales-Decks, Kunden-Case-Studies, jede B2B-Kommunikation, in der es um "Buy from us" geht.

**Skelett:**
> "Du bist [Held] und willst [Ziel]. Aber [Problem]. Wir sind [Guide], haben [Beweis für Kompetenz] und geben dir [3-Schritte-Plan]. Klick [CTA], sonst passiert [Scheitern]. Wenn du das machst, wirst du [Transformation]."

---

## 2. Heldenreise (Joseph Campbell / Christopher Vogler) — der Klassiker für Longform

**Kern:** 12 Stationen einer Transformation. Für Marco-Founder-Storys, Buch-Kapitel, Keynotes.

**Reduzierte Struktur (7 Beats):**
1. Gewohnte Welt
2. Ruf zum Abenteuer / Bruch
3. Weigerung / Zögern
4. Mentor / Begegnung
5. Prüfungen
6. Tiefster Punkt (Death & Rebirth)
7. Rückkehr mit dem Elixier

**Wann einsetzen:** Founder-Story, Personal-Brand-Kern-Narrativ, YouTube-Long-Form, Buch, Keynote.

---

## 3. Pixar Story Spine — die 6-Zeilen-Formel

**Kern:** Kleine, große Stories in 6 Sätzen.

**Struktur:**
1. "Es war einmal..."
2. "Jeden Tag..."
3. "Bis eines Tages..."
4. "Deswegen..."
5. "Deswegen..."
6. "Bis endlich..."

**Wann einsetzen:** Kurze LinkedIn-Storys, Insta-Captions, YouTube-Shorts, Kundengeschichten in 30 Sekunden.

---

## 4. ABT — And, But, Therefore (Randy Olson)

**Kern:** Die drei Wörter, die aus Info eine Story machen.

**Struktur:**
- **And:** Kontext, was ist.
- **But:** Der Bruch, das Problem.
- **Therefore:** Die Konsequenz, die Handlung.

**Wann einsetzen:** Wenn du in 2 Sätzen einen Punkt setzen musst — Sales-Zeile, Post-Hook, E-Mail-Eröffnung, Talk-Intro.

**Beispiel:** "Founder wollen sichtbar sein UND posten fleißig. ABER sie klingen wie ein Pressetext. DESWEGEN scrollen 99% weiter."

---

## 5. PAS — Problem, Agitate, Solve (Copywriting-Klassiker)

**Kern:** Schmerz aufreißen, salzen, Lösung geben.

**Wann einsetzen:** Direct-Response-Copy, Ads, Sales-E-Mails, harte Sales-Posts.

**Warnung:** Nicht überstrapazieren. Auf LinkedIn wirkt es 2026 schnell klischeehaft, wenn ohne Wahrhaftigkeit gebaut.

---

## 6. Nancy Duarte — "What is / What could be" (Resonate)

**Kern:** Große Reden pendeln zwischen dem Ist und dem Möglichen. Je öfter, je stärker.

**Struktur:**
- Beginn: Was IST (Status quo).
- Bruch: Was KÖNNTE sein.
- Pendeln (mehrfach).
- Ende: New Bliss / Call to Adventure.

**Wann einsetzen:** Keynotes, Manifeste, Vision-Posts, Investoren-Pitches.

**Referenz:** MLKs "I Have a Dream" ist die Blaupause.

---

## 7. Freytag'sche Pyramide

**Kern:** Exposition → Steigerung → Höhepunkt → Fallende Handlung → Auflösung.

**Wann einsetzen:** Case Studies, "Wie ich X gelernt habe"-Storys, Reportagen.

---

## 8. In Media Res — mitten rein

**Kern:** Beginn mitten in der heißesten Szene. Kontext später.

**Wann einsetzen:** LinkedIn-Hooks, YouTube-Intros (erste 5 Sekunden), Story-basierte Cold-DMs.

**Beispiel-Öffnungen:**
- "Ich stand vor 400 Leuten und wusste plötzlich nicht mehr, was Storytelling ist."
- "Um 03:14 Uhr klingelt mein Handy. Es ist ein Kunde, der 27.000 Euro verloren hat."

---

## 9. Contrast Storytelling (Alex Hormozi / Alex Cattoni)

**Kern:** Vorher/Nachher als Motor. Je größer der Kontrast, je stärker die Story.

**Struktur:**
1. Vorher-Zustand (spezifisch, sinnlich, emotional)
2. Auslöser
3. Nachher-Zustand (messbar + emotional)
4. Verallgemeinerte Lehre

**Wann einsetzen:** Case Studies, Founder-Story-Ausschnitte, "Wende-Story"-Posts.

---

## 10. Der 3-Akt-Aufbau

**Kern:** Setup → Konfrontation → Auflösung. Universalstruktur.

**Wann einsetzen:** Wenn du gerade nicht weißt, welches Framework passt — 3-Akt geht IMMER.

---

## 11. Kishotenketsu (japanisch — 4 Akte, ohne Konflikt)

**Kern:** Ki (Einführung) → Sho (Entwicklung) → Ten (Wendung) → Ketsu (Auflösung). Ohne klassischen Konflikt.

**Wann einsetzen:** Wenn Konflikt-Rhetorik zu westlich/aggressiv ist (Purpose-Marken, Achtsamkeits-Themen, sensible B2C).

---

## 12. The 5 Cs (Kurz-Story-Formel)

1. **Circumstance** — wo, wann, wer?
2. **Curiosity** — was ist merkwürdig?
3. **Characters** — wer treibt?
4. **Conversations** — wörtliche Rede.
5. **Conflict** — worum geht der Kampf?

**Wann einsetzen:** Wenn eine flache Info-Story lebendig werden soll. Checklisten-Werkzeug beim Umschreiben.

---

## 13. Sparklines (Nancy Duarte) — Vision-Storytelling

**Struktur:** Über die gesamte Rede/den Post oszilliert die Kurve zwischen "das ist die Welt heute" und "das ist die Welt, die möglich ist". Immer wieder. Am Ende: der "Point of no Return".

**Wann einsetzen:** Company-Manifest, Fundraising-Pitch, Movement-Aufbau.

---

## 14. Story Circle (Dan Harmon, "Community" / "Rick and Morty")

**Struktur (8 Beats):**
1. Du (Held im Alltag)
2. Brauchst etwas
3. Betrittst ungewohnte Welt
4. Suchst danach
5. Findest es
6. Zahlst einen Preis
7. Kehrst zurück
8. Verändert

**Wann einsetzen:** Character-getriebene Founder-Storys, YouTube-Long-Form, Buch-Kapitel.

---

## Meta-Regel

**Nicht das Framework retten die Story. Die Wahrheit rettet die Story.**
Frameworks sind Skelette. Fleisch = spezifische Details, wörtliche Zitate, sinnliche Anker (Geruch, Zeit, Ort, Objekt).

Nach 6 Monaten Arbeit hat Marco sein eigenes Framework (`GOAT-Story-Loop`? — noch zu bauen), das aus 3–4 dieser Werkzeuge komponiert ist und in `01_Frameworks/goat_story_loop.md` landet.
