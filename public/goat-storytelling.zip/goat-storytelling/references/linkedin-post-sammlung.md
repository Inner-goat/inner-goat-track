---
type: wissen
tags: [storytelling, linkedin, content, swipe-file]
quelle: Mailenstein/Storytelling Wissen/03_LinkedIn_Posts/
erstellt: 2026-07-08
---

# LinkedIn-Post-Sammlung

Nutzbare Swipe- und Beispiel-Sammlung aller LinkedIn-Drafts, Serien, des Backlogs und des Performance-Logs aus dem Drive-Ordner `03_LinkedIn_Posts/`. Dient als Fundus für neue Posts nach den [[Storytelling-Content-Regeln]] und im Ton von [[Outreach-Stil LinkedIn]] (verwandt, aber nicht identisch — der gilt nur für Connects/DMs).

## Grundformel

Jeder Post = **1 Konzept + 1 Anekdote**, die es unvergesslich macht.

**Anekdoten-Quelle (Reihenfolge):** historisch (Standard) → Kundenanekdoten anonymisiert (wenn Marco Details liefert) → Marcos eigene Erlebnisse (wenn Marco sie erzählt) → klar markierte Hypothesen ("stell dir vor…").

Backlog-Zeilenformat: `[Status] [Konzept] Illustrations-Anekdote — Kern-Hook`
Status: 📌 Idee | ✍ Draft | ⏳ Review | ✅ Live

## Postfertige Drafts (Swipe)

### Draft 01 — "Du bist nicht der Held deiner Founder-Story"
- **Framework:** StoryBrand (SB7) · **Hook-Typ:** Contrarian · **~1.100 Zeichen**
- **Kernidee:** Der Kunde ist der Held, der Founder ist der Guide (Yoda hilft Luke, Gandalf hilft Frodo). Vier Umbau-Regeln: erst den Schmerz des Kunden nennen; Weg-Kenntnis statt Weg-Historie zeigen; 3-Schritte-Plan statt Lebenslauf; mit "Wenn du das machst, wirst du…" enden statt "Ich freue mich…".
- **Ziel:** Positionierung als Storytelling-Berater; DMs von pitchenden Foundern.
- **CTA:** "Wo verrutschst du am häufigsten in die Ich-Rolle?" / DM "GUIDE" für Pitch-Check.
- **Status:** sofort postbar.

### Draft 03 — "Ich habe 100 der viralsten Founder-Posts der Woche zerlegt"
- **Framework:** Listicle + PAS-Feinstruktur · **Hook-Typ:** Specific Number · **~1.500 Zeichen (Save-Post)**
- **Kernidee:** 87 von 100 Posts nutzen dieselben 3 Hooks — (1) der Konfrontative ("Alle sagen X. Falsch. In Wahrheit Y."), (2) die Spezifische Zahl ("27.000 Euro…"), (3) Mitten rein / In Media Res. Gegenbeispiele, die NICHT ziehen ("In der heutigen schnelllebigen Welt…"). Pointe: Hooks funktionieren nur mit echter Story dahinter — erst die Story, dann der Hook.
- **Ziel:** Saves, Autorität als Analyst — perfekte Vorstufe zum Skill-Verkauf.
- **Recycling:** als Karussell (Slide-Post) noch stärker; Text-Only zuerst testen.
- **Status:** sofort postbar. Speist die [[Hook-Bibliothek]].

### Draft 04 — "1000 Songs in deiner Hosentasche"
- **Konzept:** *Konkretion schlägt Abstraktion* (In Media Res + The 5 Cs) · **~1.100 Zeichen**
- **Kernidee:** Jobs' iPod-Keynote (23.10.2001): nicht "5 GB", nicht "Ultra-High-Density-Storage", sondern "1000 Songs in deiner Hosentasche". Konkretion schlägt Abstraktion — immer. Founder-Umbau: nicht "Unsere KI erhöht die Effizienz", sondern "Deine Vertriebler gewinnen 7 Stunden pro Woche zurück". Test: jedes Adjektiv streichen, durch Zahl/Objekt/Szene ersetzen.
- **Ziel:** DMs mit Pitch-Sätzen zum Umbauen (liefert Material für Folge-Posts).
- **Recycling:** YouTube-Short (60 Sek), 5-Slide-Karussell, Newsletter-Absatz.
- **Status:** sofort postbar.

## Serie "Vorher-Nachher — The Art of Breaking Yourself"

Wochen-Serie (Vorschlag Montag als Anker). Format: Post + Vorher-Nachher-Bild (Kind ↔ Erwachsener). Bewusst kürzer (900–1300 Zeichen), damit das Bild trägt. Baut auf [[Der Bruch als Bauplan]] und [[Art of Breaking Yourself]].

**Post-Bauplan jeder Folge:** (1) Bild vorher↔nachher · (2) behauptende Hook-Zeile · (3) 3–5 Brüche als Titel-Sätze, keine Details · (4) Kern-Frage "warum mache ich das eigentlich?" · (5) Motivationsverschiebung (alter vs. neuer Antrieb) · (6) Konzept-Anker "was ist The Art of Breaking Yourself" · (7) Serien-Fuß + Kandidaten-CTA.

**Warum es trägt:** Bild + kurze Bruch-Liste = Vulnerabilität ohne Selbstbloßstellung. Wiederholbar (nur Person + Brüche + Motivations-Satz wechseln). Serien-Effekt (Wochen-Anker). Community-Sog: "Wer will Kandidat werden?" → DMs → Content-Fuel für 6+ Monate. Positionierung: Marco als jemand, der andere SIEHT.

**Skill-Bridge:** nur jede 4.–5. Folge endet mit "PS: Wenn du deinen eigenen Bruch strukturieren willst — der Skill dazu ist [Link]." Nicht jede Folge, sonst tot.

### Folge 01 — Marco: "20 Jahre um zu dem Jungen zurückzufinden"
- **Bild:** Marco als 6-Jähriger (06.08.2006) ↔ Marco heute · **~1.700 Zeichen**
- **Kernidee:** Das Kind links, voll Energie und Selbstvertrauen. Sieben Monate nach dem Foto: Skiunfall — erster Bruch, erste Grenze. Viele weitere Brüche, bis er verstand: Erfolg kommt nicht aus den falschen Gründen (reich, berühmt, gesehen), sondern wenn man tut, was man liebt, um etwas zu bewegen. 20 Jahre, um wieder der Junge zu werden. Ein Bruch ist kein Feind, sondern eine Version von dir, die stirbt, weil sie dich nicht mehr tragen kann. Zwei Fragen: "Welche Version von mir stirbt hier gerade? Und welche will hier geboren werden?"
- **Status:** postfertig — wartet auf Marcos Freigabe + Bilder. Teil von [[Marcos eigene Breaking Story]].
- **Setup:** Karussell mit 2 Bildern, Bilder VOR Text hochladen, Montag 07:30. Erster Eigen-Kommentar 5 Min nach Post.

## Breaking-Yourself — 5 Post-Winkel + Skill-Launch-Bridge

Fünf ausformulierte Winkel auf [[Der Bruch als Bauplan]]. Marco pickt EINEN, der wird voll ausgebaut (900–1500 Zeichen). Beispiele auch in [[Breaking-Yourself-Beispiele]].

- **Winkel 1 — Alex Zanardi** ("Der Athlet, den man töten musste, damit der Athlet entsteht"): F1-Pilot, beide Beine verloren, 4× Paralympic-Gold im Handbike. Körperlicher Bruch als Katalysator neuer Motivation. *Empfohlener Erst-Post — größter emotionaler Aufschlag, positioniert international.*
- **Winkel 2 — Steve Jobs** ("Ich habe erst dann angefangen zu bauen, als ich zerbrochen war"): Rauswurf 1985 → NeXT & Pixar → Rückkehr 1997 → iPod/iPhone/iPad. Der Bruch tötet, wer du warst — das ist die Bedingung, nicht der Nebeneffekt.
- **Winkel 3 — Meta über Founder-Pitches** ("Die einzige Founder-Story, die verkauft"): 9 von 10 Pitches haben ein Loch in der Mitte. Vor dem Bruch bist du Verkäufer, nach dem Bruch bist du Guide. Direkt B2B, direkt kaufbar.
- **Winkel 4 — Reinhold Messner** ("Der Mann, der sich verbot, aufzuhören"): nach dem Tod des Bruders am Nanga Parbat. Nach dem Bruch tust du dieselbe Sache aus einem NEUEN Grund — der Grund macht den Unterschied.
- **Winkel 5 — Skill-Launch-Post:** Reprise des Bruch-Themas → Behauptung (jede verkaufende Founder-Story hat einen Bruch) → Diagnose (3 Gründe, warum Founder ihn umschiffen) → Lösung (Skill mit 6 Fragen) → Preis/CTA (79 € oder Waitlist). **Voraussetzung:** Winkel 1 oder 2 vorher gepostet, damit der Launch als "endlich das Werkzeug" wirkt, nicht als kalter Verkauf. Siehe [[Storytelling-Skill (Produkt)]].

**Empfohlene Reihenfolge:** Woche 1 Winkel 1 (Zanardi) → Woche 1/2 Winkel 2 (Jobs) → Woche 2 Winkel 3 (Meta, bringt B2B-DMs) → Woche 2/3 Winkel 5 (Launch, wenn Thema warm) → später Winkel 4 (Messner) als deutschsprachige Vertiefung.

## Backlog — Konzept × Anekdote (Ideen)

### Historische Anekdoten × Konzepte
- ✍ [Konkretion schlägt Abstraktion] Jobs iPod "1000 Songs" — Draft 04 fertig
- 📌 [Sparklines / Was ist vs. was sein könnte] MLK "I Have a Dream" — 6× Pendeln zwischen Realität und Vision
- 📌 [In Media Res] Nike "It's only crazy until you do it" — Spot ohne Produktshot
- 📌 [Contrast Storytelling] Sara Blakelys Spanx-Anfang — 5000 $ und ein geschwänzter Anwaltstermin
- 📌 [Pixar Story Spine] Netflix vs. Blockbuster in 6 Sätzen
- 📌 [Heldenreise-Ruf zum Abenteuer] Kennedy "We choose to go to the moon" — "weil es schwer ist"
- 📌 [The 5 Cs] Airbnbs erste 3 Luftmatratzen — Detail schlägt Argument
- 📌 [ABT] Simon Sinek "Start With Why" — 3 Wörter, 60 Mio Views
- 📌 [Kishotenketsu] Muji-Erfolg — Storytelling ohne Konflikt, japanisch gedacht
- 📌 [Pattern Interrupt] Dollar Shave Club "Our blades are f***ing great"
- 📌 [StoryBrand Guide-Rolle] Yoda, Gandalf, Miyagi — warum keiner der Held ist

### Konzept-Bibliothek (noch ohne Anekdote)
- 📌 [Der Riss ist Teil des Bauwerks] Kalibrierte Ehrlichkeit verkauft stärker als Perfektion
- 📌 [Show, don't tell — falsch?] Wann "tell" besser ist als "show"
- 📌 [Der Preis der Konkretion] Warum Founder das Wort "Effizienz" streichen sollten
- 📌 [Konflikt ist die Wirbelsäule] Warum jede gute Story mit einem "Aber" beginnt
- 📌 [Das Trojanische Pferd] Story bringt deine Botschaft dahin, wo Argumente nicht hinkommen
- 📌 [Der Elevator Pitch ist tot] Was ihn ersetzt
- 📌 [Details, die riechen] Sinnliche Anker — "grüner Kaffeebecher" > "Getränk"
- 📌 [Der 3-Sekunden-Test] Post prüfen, bevor du postest

### Kundenanekdoten (nur mit Marcos Details + Freigabe)
- 📌 Elisa-Story anonymisiert — Winkel + Freigabe nötig
- 📌 Insight-Impact-Workshop — was Studierende gelernt haben
- 📌 Anabel-Fall anonymisiert — Konflikt-Storytelling für B2B (heikel; nur wenn Vergleich durch ist)

## Bau-Schleife (Standard)

Wenn Marco 1 Konzept aus der Bibliothek pickt UND 1 Anekdote-Idee dazu nennt (real oder anonymisiert-eigen), werden **3 Post-Varianten** gebaut. Das ist die Standard-Schleife.

## Performance-Log

Nach jedem veröffentlichten Post 24h- + 7-Tage-Snapshot eintragen, dann monatlich reviewen. Erfasste Felder: Framework/Hook-Typ, Link, Impressions, Reactions, Kommentare, Saves, Reposts, DMs (Zahl + Qualität), was funktionierte/nicht, Ableitung. **Einträge:** noch leer (Stand 08.07.2026).

## Verwandte Notizen

- [[Storytelling-Content-Regeln]] — Konzept + Anekdote, keine erfundenen Ich-Storys
- [[Outreach-Stil LinkedIn]] — Ton für Connects/DMs (verwandt, nicht identisch)
- [[Hook-Bibliothek]] — die Hook-Typen hinter den Posts
- [[Der Bruch als Bauplan]] · [[Art of Breaking Yourself]] · [[Breaking-Yourself-Beispiele]] · [[Marcos eigene Breaking Story]]
- [[Storytelling-Skill (Produkt)]] — jeder Post ist Werbung dafür
- [[Storytelling Wissen]] — Hub
- [[Schreibstil]] · [[Marco Maiworm]]
