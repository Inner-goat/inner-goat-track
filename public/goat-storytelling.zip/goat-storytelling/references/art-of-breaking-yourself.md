---
type: wissen
tags: [marco, storytelling, signature-thema, framework, bruch]
erstellt: 2026-07-08
---

# Art of Breaking Yourself

Marcos Storytelling-Signature-Thema: *"The Art of Breaking Yourself"* — der bewusst herbeigeführte oder anerkannte **Bruch als Storytelling-Bauplan**. Es ist der Kern-Winkel für Posts, Videos und den Launch von Skill-Version-1.

> **Das ausgearbeitete Framework liegt jetzt als eigene Konzept-Notiz vor: [[Der Bruch als Bauplan]]** (mit 4 Auslösern, 6 Beats, Anwendungs-Räumen und externer Fundierung). Diese Notiz hier bleibt die Signature-Thema-Übersicht; die Methodik lebt in [[Der Bruch als Bauplan]], die Fallbank in [[Breaking-Yourself-Beispiele]], Marcos eigener Fall in [[Marcos eigene Breaking Story]].

## Kern

- **Kern-Satz:** „Du musst erst sterben — oder Teile von dir — um neugeboren zu werden."
- Basiert auf Bookers **Rebirth-Plot** und Campbells **Death & Rebirth**-Station, aber Marco positioniert es als **eigenständiges Handwerk**.
- Marco hat das Konzept über ein YouTube-Video als seinen persönlichen Storytelling-Winkel identifiziert: [https://youtu.be/8-vXMo9o7pI](https://youtu.be/8-vXMo9o7pI)

## Warum es differenziert

Im überfüllten „Founder-Story"-Feld ist es kein „Resilienz-Porn", sondern eine präzise Struktur:

- **4 Bruch-Auslöser:** körperlich, moralisch, Erwartung, Nicht-genug
- **6 Beats:** Vorher-Selbst → Auslöser → Weigerung → Riss → Motivationsverschiebung → Neue Handlungsebene

Der Bruch ist die **Bedingung** für die Transformation, nicht ein Nebeneffekt.

## Zwei parallele Framework-Namen

- **"The Art of Breaking Yourself"** — thematisches Dach, international
- **"Bruch-Bauplan"** — methodischer Name, deutsch/technisch

Später konvergiert eines der beiden.

## Material im [[Storytelling Wissen]]-Ordner

- Framework-Doku: `Mailenstein/Storytelling Wissen/01_Frameworks/der_bruch_als_bauplan.md`
- Beispielbank: `06_Case_Studies_&_Beispiele/breaking_yourself_beispiele.md` (Zanardi, Anderson, Kramer, Jobs, Messner, Blakely, Oprah, Jordan, Frankl)
- 5 Post-Winkel + Skill-Launch-Bridge: `03_LinkedIn_Posts/breaking_yourself_winkel.md`
- Marcos eigener Bruch: `07_Marco_Personal_Storys/rohmaterial.md`, **Set B (Konflikt & Preis)** — wird erst genutzt, wenn Marco die Antworten liefert.

## Anwendung

- Bei allen Storytelling-Posts/Videos ist „Bruch" ein Kandidat für den Konzept-Winkel (Aufbau nach [[Storytelling-Content-Regeln]]).
- **Das verkaufte [[Storytelling-Skill (Produkt)]] v1 basiert genau auf [[Der Bruch als Bauplan]]:** Der Skill hilft dem User, genau **EINEN** Bruch aus seinem Leben zu identifizieren und durch die 6 Beats zu strukturieren. Das ist das erste verkaufte Produkt und das MVP.

## Harte Regel

Bruch-Storys dürfen **NICHT erfunden** sein — nicht für Marco selbst, nicht für Kunden. Historische/öffentlich dokumentierte Storys sind der Standard (siehe [[Storytelling-Content-Regeln]]).

## Verwandt

- [[Der Bruch als Bauplan]] — das ausgearbeitete Kern-Framework (4 Auslöser, 6 Beats)
- [[Breaking-Yourself-Beispiele]] — die Fallbank (Zanardi, Anderson, Kramer, Jobs, Messner, Blakely, Oprah, Jordan, Frankl)
- [[Marcos eigene Breaking Story]] — Marcos persönlicher Bruch (Gerüst + offene Fragen)
- [[Die Heldenreise-Kurve]] — der Rahmen, aus dem der Bruch isoliert wird
- [[Storytelling-Skill (Produkt)]] — das darauf basierende verkaufte Produkt (v1)
- [[Marco Maiworm]] — wessen Signature-Thema das ist
- [[Storytelling Wissen]] — der Ordner, in dem das Material lebt
- [[Storytelling-Content-Regeln]] — allgemeine Content-Regel (Konzept + Anekdote)
- [[Schreibstil]] — Tonalität
