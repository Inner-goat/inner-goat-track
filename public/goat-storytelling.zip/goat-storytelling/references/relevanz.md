---
type: konzept
tags: [storytelling, prinzip, relevanz, hook]
quelle: Marcos Storytelling-Diktat (08.07.2026)
erstellt: 2026-07-08
---

# Relevanz

Marcos wichtigstes Storytelling-Prinzip: **Das Wichtigste beim Storytelling ist die Relevanz** — der Grund, warum ich dir *diese* Geschichte *jetzt* erzähle. Fehlt dieser Grund, ist die Geschichte deplatziert, und die Leute wissen nicht, warum man sie ihnen erzählt.

## Kernidee

> "Das Wichtigste beim Storytelling ist die Relevanz: der Grund, warum ich dir die Geschichte erzähle, ist … Man kann sehr schnell deplatziert seine Geschichte erzählen. Und Leute wissen nicht, warum man sie erzählt." — Marco

Relevanz ist der unsichtbare Vertrag zwischen Erzähler und Zuhörer. Bevor der erste Satz fällt, muss (bewusst oder unbewusst) beantwortet sein: *Warum sollte ich dir gerade jetzt zuhören?* Eine Geschichte ohne Relevanz ist nicht falsch erzählt — sie ist am falschen Ort erzählt. Sie ist **deplatziert**.

Der Fehler ist selten die Geschichte selbst. Der Fehler ist, dass der Erzähler den Grund im Kopf hat, ihn aber nie an den Zuhörer weitergibt. Die Verbindung zwischen *dieser Geschichte* und *diesem Moment / diesem Publikum / diesem Punkt* bleibt im Erzähler stecken.

## Wie es funktioniert / Anwendung

1. **Den Grund zuerst finden, dann erst erzählen.** Frag dich vor jeder Geschichte: *Warum erzähle ich sie genau jetzt, genau diesem Menschen?* Wenn du keine klare Antwort hast, ist es der falsche Moment (siehe [[Der richtige Zeitpunkt]]).
2. **Den Grund sichtbar machen.** Relevanz muss aus deinem Kopf heraus in die Erzählung. Das kann ein Vorsatz sein ("Ich erzähle dir das, weil …"), eine Brücke zum Thema, oder ein Bezug auf etwas, das der Zuhörer gerade gesagt/erlebt hat.
3. **An das anknüpfen, was gerade im Raum ist.** Die relevanteste Geschichte ist die, die auf den letzten Satz des Gesprächs, die aktuelle Frage des Publikums oder den Schmerz des Lesers antwortet.
4. **Deplatzierung als Warnsignal lesen.** Wenn du merkst, dass Leute höflich, aber ratlos zuhören, fehlt fast immer die Relevanz — nicht die Dramatik.

## Beispiel

Marcos Warnung: Man kann *sehr schnell* deplatziert erzählen. Die beeindruckendste Founder-Story wirkt hohl, wenn niemand versteht, warum sie in diesem Pitch, in diesem Post, in diesem Gespräch auftaucht. Umgekehrt trägt selbst eine kleine, unspektakuläre Szene enorm, wenn glasklar ist, *worauf* sie eine Antwort ist.

## Für Buch/Artikel

Relevanz ist das Fundament unter allen anderen Techniken. [[Six Senses Framework]] macht eine Geschichte *lebendig*, [[Reliving vs. Reporting]] macht sie *unmittelbar* — aber wenn die Relevanz fehlt, verpufft beides. Ein Kapitel könnte lauten: *"Bevor du lernst, wie du erzählst, lerne, warum du erzählst."* Relevanz ist auch der stille Motor jedes Hooks: Ein Hook funktioniert, weil er in Sekunden Relevanz behauptet.

## Verwandte Konzepte

- [[Der richtige Zeitpunkt]] — Relevanz und Timing sind Geschwister: die richtige Geschichte zur richtigen Zeit.
- [[Six Senses Framework]] — macht die *relevante* Geschichte erlebbar.
- [[Reliving vs. Reporting]] — Unmittelbarkeit verstärkt eine relevante Geschichte, ersetzt Relevanz aber nie.
- [[Storytelling als Lebensveränderung]] — nur eine relevante Geschichte kann etwas verändern.
- [[Hook-Bibliothek]] — Hooks sind angewandte Relevanz in den ersten Sekunden.
- [[Kern-Frameworks]] — Frameworks sind Skelette; Relevanz entscheidet, ob das Skelett am richtigen Ort steht.
- [[Storytelling-Content-Regeln]] — Konzept + Anekdote; die Anekdote muss zum Konzept *relevant* sein.

---

Zurück zu [[Storytelling Wissen]].
