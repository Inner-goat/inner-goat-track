# Der Bruch als Bauplan — *The Art of Breaking Yourself*

**Status:** Marcos Signature-Framework in Entwicklung. Angedockt an Bookers **Rebirth-Plot** und Campbells **Death & Rebirth**-Station der Heldenreise, aber neu positioniert: **Der Bruch ist keine Katastrophe, die dir zustößt — er ist ein Handwerk, das du beherrschen kannst.**

## Der Kern-Satz

> "Du musst erst sterben — oder Teile von dir — um neugeboren zu werden."

Und der Bruch ist selten die Geschichte. Der Bruch ist die **Voraussetzung** für die Geschichte, die erzählenswert wird.

## Warum das eine eigene Kategorie ist

Fast jede große Story hat einen Konflikt. Aber "Der Bruch" ist mehr als Konflikt. Konflikt ist: *Du willst X, jemand steht dagegen.* Bruch ist: *Was du warst, ist nicht mehr überlebensfähig. Du selbst musst neu.*

Konflikt hast du mit der Welt.
Bruch hast du mit dir.

## Die 4 Bruch-Auslöser

Aus Marcos Notizen — was einen Bruch anstößt:

1. **Der körperliche Bruch** — Unfall, Krankheit, Verletzung. Der Körper zwingt eine Neuordnung.
2. **Der moralische Bruch** — du kannst nicht mehr sein, wer du warst, ohne dich selbst zu verraten. Ein Wert kollidiert mit deinem Leben.
3. **Der Erwartungs-Bruch** — die Rolle, die dir zugewiesen wurde (Familie, Job, Branche, Kultur), wird zu klein oder zu falsch, dass du sie länger tragen kannst.
4. **Der "Nicht-genug"-Bruch** — Feedback von außen (Ablehnung, Scheitern, Vergleich) trifft eine Wunde in dir, die sagt: *So wie du bist, wirst du es nicht schaffen.*

Alle vier führen zu derselben Schwelle: **Die Motivation verschiebt sich.** Du machst nicht mehr, was du machst, aus demselben Grund wie vorher. Der Antrieb wechselt seine Quelle.

## Die 6 Beats (Marcos GOAT-Bruch-Loop v0.1)

Dies ist das Skelett. Für Posts, Videos, Pitches, Reden.

1. **Vorher-Selbst** — wer du warst. Konkret. Sinnlich. Ein Bild, ein Satz, ein Alltag.
2. **Auslöser** — der Moment, an dem klar wurde, dass es nicht mehr weitergeht. Nicht der Prozess. Der Moment.
3. **Weigerung** — du willst nicht. Du kämpfst gegen den Bruch. Das ist wichtig — sonst wirkt es wie ein leichter Wechsel.
4. **Der Riss** — das Ich zerbricht. Der Punkt ohne Rückkehr. Was ist gestorben?
5. **Motivationsverschiebung** — was du jetzt tust, tust du aus einem NEUEN Grund. Nenne den Grund. (Das ist die Magie — ohne diesen Schritt ist es nur Selbstoptimierung.)
6. **Neue Handlungsebene** — was passiert jetzt, das vorher nicht möglich war. Nicht "Erfolg". Handlung. Konkret.

## Warum das für Founder das schärfste Werkzeug überhaupt ist

Founder pitchen ständig Transformation. "Wir verändern die Branche." "Wir revolutionieren X."
Aber die glaubwürdigste Version einer Transformations-Story ist die eigene.

- Ein Founder, der **nicht gebrochen wurde**, klingt wie ein Produkt-Katalog mit Beinen.
- Ein Founder, der **den Bruch nur andeutet**, klingt wie ein Vortrag über Resilienz.
- Ein Founder, der **den Bruch als Bauplan präzise erzählt**, klingt wie ein Mensch, dem man 100.000 Euro gibt.

## Die harte Regel dieses Frameworks

**Der Bruch muss echt sein.**

Alle anderen Frameworks lassen dir Spielraum für Inszenierung. Dieses nicht. Wenn du einen Bruch erfindest, erwischt es dich früher oder später — und dann ist es Karrieren-schädigend, nicht -bauend.

Deswegen ist der Bruch das größte Story-Asset, das du haben kannst — aber du kannst ihn nicht faken. Nur finden.

## Verbindung zu anderen Frameworks

- **Heldenreise:** Der Bruch ist Station 8 (Death & Rebirth / "Belly of the Whale"). Wir isolieren diese Station und behandeln sie wie einen eigenen Bauplan.
- **StoryBrand:** Der Bruch macht dich zum glaubwürdigen Guide — weil du selbst durch ein Tal bist, das dein Kunde jetzt betritt.
- **Contrast Storytelling:** Der Bruch ist der Motor der Kontrast-Erzählung, aber ehrlicher — nicht nur "Vorher/Nachher", sondern "Ich musste sterben, um Nachher zu werden".
- **Nancy Duartes "Was ist / Was sein könnte":** Der Bruch ist der Moment, an dem das "Was ist" für dich persönlich unhaltbar wurde.

## Anwendungs-Räume

- **LinkedIn-Post:** In 900–1400 Zeichen ist genau EINE Bruch-Station erzählbar. Nicht alle 6. Wähle EINEN Beat als Zentrum.
- **YouTube-Long-Form:** 10–15 Min reichen für 3–4 Beats mit Fleisch. Oder: 1 Athlet/Founder, alle 6 Beats.
- **Keynote:** Perfektes Framework für 45–60 Min — der ganze Bogen mit 3 Bruch-Momenten (eigener, historischer, Publikums-Übertragung).
- **Skill v1:** Der Skill hilft dem User genau EINEN Bruch aus seinem Leben zu identifizieren, zu strukturieren und in eine Story zu bauen. Das ist das MVP.

## Was noch fehlt (für v1.0 des Frameworks)

- 3 klar zerlegte Beispiel-Storys (siehe `06_Case_Studies_&_Beispiele/breaking_yourself_beispiele.md`)
- Marco'sche Version aus seinem eigenen Leben (kommt aus `07_Marco_Personal_Storys/rohmaterial.md`, Set B)
- Der Skill-Prompt, der Nutzer durch die 6 Beats führt (Aufgabe für `05_Skill_für_Verkauf/`)

## Terminologie-Vorschläge (Marco entscheidet)

Das Framework braucht einen Namen mit Wiedererkennung. Kandidaten:

- **The Art of Breaking Yourself** — direkt aus dem Video, englisch, geht auch für internationale Positionierung
- **Der Bruch als Bauplan** — deutsch, technisch, seriös
- **GOAT-Bruch-Loop** — passt zur Inner-GOAT-Welt, spielerisch
- **Story Break Method** — verkäuflich, klingt nach Produkt

Empfehlung: **"The Art of Breaking Yourself"** als thematisches Dach + **"Bruch-Bauplan"** als methodischer Name. Beides parallel führen, bis eines dominant wird.
