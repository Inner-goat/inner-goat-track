# Storytelling References — Index

Wann du welche Datei lesen sollst. Nicht alle auf einmal — nur die, die zum aktuellen Modus passen.

## Kern-Frameworks (Modus 1–4, Basis-Handwerk)

| Datei | Wann lesen |
|---|---|
| `frameworks.md` | Immer wenn du zwischen Frameworks entscheidest (StoryBrand, Heldenreise, Pixar Spine, ABT, PAS, Duarte, Freytag, In Media Res, Contrast, 3-Akt, Kishotenketsu, 5 Cs, Sparklines, Story Circle) |
| `hooks.md` | Wenn der User einen Hook / Opener / erste LinkedIn-Zeile braucht — 10 Hook-Typen mit Beispielen und Do/Don't |
| `heldenreise-kurve.md` | Wenn User die klassische Heldenreise verstehen oder anwenden will (12 Stufen, reduziert auf 7 Beats) |
| `die-12-plots.md` | Wenn du dem User zeigen musst, welcher der 12 archetypischen Plots seine Story ist |
| `six-senses.md` | Wenn eine Story flach wirkt — mit sinnlichen Ankern (Sehen, Hören, Riechen, Schmecken, Tasten + inneres Sechstes) füllen |
| `reliving-vs-reporting.md` | Wenn der User "berichtet" statt "erlebbar macht" — die zentrale Umbau-Regel |

## Signature-Thema: The Art of Breaking Yourself (Modus 4)

| Datei | Wann lesen |
|---|---|
| `bruch-bauplan.md` | Der 4-Auslöser × 6-Beats-Kern. Immer im Bruch-Modus lesen. |
| `art-of-breaking-yourself.md` | Signature-Thema-Übersicht, warum es differenziert |
| `beispiele.md` | 9 zerlegte Bruch-Storys (Zanardi, Anderson, Kramer, Jobs, Messner, Blakely, Oprah, Jordan, Frankl) als Referenzen |
| `marcos-breaking-story.md` | Marcos eigene Bruch-Story (August 2006 Kinderfoto → Skiunfall 7 Monate später → 20-Jahre-Bogen); nutze als Beispiel für Founder-Bruch-Storys |

## Positionierung & Kontext

| Datei | Wann lesen |
|---|---|
| `content-regeln.md` | **PFLICHT bei jedem Post.** Konzept + Anekdote. Keine erfundenen Ich-Storys. Historisch als Default. |
| `schreibstil.md` | **PFLICHT.** Ton, Deutsch/Du, keine Emojis in Sales-Kontext, Vokabular, "Kurz und klar." |
| `relevanz.md` | Wenn eine Story rhetorisch stimmt aber niemanden erreicht — Relevanz-Diagnose |
| `der-richtige-zeitpunkt.md` | Wann welche Art Story raus soll (Kontext-Timing) |
| `olivenbaum-essenz.md` | Die "Essenz" einer Person / Marke / Botschaft finden (Marcos Kern-Methode für Positionierungs-Storys) |
| `karten-set.md` | Storytelling-Karten-Set — als spielerisches Werkzeug für Story-Findung |

## Vertiefung / Lebensrahmen

| Datei | Wann lesen |
|---|---|
| `storytelling-als-lebensveraenderung.md` | Wenn ein User verstehen will, warum Storytelling MEHR ist als Marketing — die Lebens-Ebene |
| `lebe-deine-geschichte.md` | Verbindung zwischen der eigenen gelebten Story und der erzählten Story — Authentizitäts-Kern |
| `academy-storytelling-kommunikation.md` | Academy-Modul "Storytelling & Kommunikation" — voller Rahmen für strukturierte Trainings |

## Anwendungsbeispiele

| Datei | Wann lesen |
|---|---|
| `linkedin-post-sammlung.md` | Als Anschauungs-Bibliothek — welche Post-Typen für welchen Zweck gebaut wurden |

## Lade-Reihenfolge (Empfehlung)

Wenn eine User-Anfrage kommt und du unsicher bist:
1. Immer zuerst `content-regeln.md` + `schreibstil.md` präsent haben (Ton + Wahrheits-Regel).
2. Dann Modus wählen und passendes Framework aus `frameworks.md`.
3. Bei Bruch-Story: `bruch-bauplan.md` + `beispiele.md`.
4. Bei Hook-Bedarf: `hooks.md`.
5. Wenn Story flach: `six-senses.md` + `reliving-vs-reporting.md`.
6. Wenn Positionierung / Essenz gesucht: `olivenbaum-essenz.md` + `relevanz.md`.
