# Hook-Bibliothek

Ein Hook hat einen einzigen Job: **den Daumen stoppen**. Alles andere kommt danach.

Regel: **Pro Post 5 Hook-Varianten generieren, dann die beste nehmen.** (Für Massenproduktion: `anthropic-skills:hook-creator` — liefert 10 aus 5 Frameworks.)

Jede Kategorie hier hat: **Trigger**, **Formel**, **3 Beispiele**.

---

## 1. Contrarian / Provokation

**Trigger:** Kollektive Annahme wird zerlegt.
**Formel:** "Alle sagen X. Falsch. In Wahrheit Y."

- "Storytelling verkauft nicht. Wahrheit verkauft. Storytelling macht Wahrheit hörbar."
- "Dein LinkedIn-Post floppt nicht wegen des Algorithmus. Er floppt, weil er nach Pressetext klingt."
- "Ich habe 47 Founder-Pitches gesehen. 42 hatten keine einzige Story. Das ist kein Zufall — das ist die Regel."

---

## 2. In Media Res / Szene

**Trigger:** Neugier durch offene Szene.
**Formel:** Konkreter Moment, keine Erklärung.

- "Es war 03:14 Uhr. Der Kunde weinte am Telefon."
- "Ich stand vor 400 Leuten und hatte die erste Folie vergessen."
- "Sie warf mir den Vertrag über den Tisch und sagte: 'Beweise es.'"

---

## 3. Specific Number / Konkretion

**Trigger:** Präzision signalisiert Wahrheit.
**Formel:** Zahl + Fakt, der weh tut oder wow macht.

- "27.000 Euro. So viel hat mich EIN einziger Satz gekostet."
- "In 6 Wochen 41.000 organische LinkedIn-Impressionen — ohne Ads, ohne Tricks. Nur mit einer Regel."
- "9 von 10 Founder erzählen ihre Story falsch. Hier ist Regel #1."

---

## 4. Confession / Vulnerability

**Trigger:** Authentizität durch Selbstoffenbarung.
**Formel:** "Ich muss was gestehen…"

- "Ich habe 6 Monate lang geposted, ohne dass irgendwer etwas zurückgeschrieben hat."
- "Das Peinlichste, was mir als Berater passiert ist: Ich habe meiner Frau geraten, was ich mir selbst nie zugetraut hätte."
- "Ich hasse den Satz 'Storytelling ist eine Superpower'. Weil er nicht stimmt."

---

## 5. Question Hook

**Trigger:** Frage zwingt zur inneren Antwort.
**Formel:** Konkrete, unbequeme Frage.

- "Wann hast du zuletzt eine Geschichte erzählt, an die du dich am nächsten Tag noch selbst erinnert hast?"
- "Warum verkaufen Apple-Keynotes und deine Pitchdecks nicht?"
- "Was ist der Unterschied zwischen einer Anekdote und einer Story?"

---

## 6. Listicle / "Ich habe X ausprobiert"

**Trigger:** Klarer Nutzen versprochen.
**Formel:** "Ich habe X getestet. Das habe ich gelernt."

- "Ich habe 100 der viralsten LinkedIn-Posts der Woche zerlegt. 87 nutzen dieselben 3 Hooks."
- "Ich habe 30 Tage lang jeden Morgen eine Story handschriftlich aufgeschrieben. Das hat sich verändert:"
- "Ich habe unser Sales-Deck von 47 auf 9 Folien gekürzt. Umsatz verdoppelt. Der Grund:"

---

## 7. Metaphor / Analogie

**Trigger:** Bild schlägt Argument.
**Formel:** Unerwarteter Vergleich.

- "Ein Pitch ohne Story ist wie Kaffee ohne Wasser: technisch möglich, aber niemand will das trinken."
- "Deine Founder-Story ist ein Trojanisches Pferd. Wenn sie kein Pferd hat, kommt sie nicht rein."
- "Storytelling ist wie Krafttraining. Nur wer es schmerzhaft macht, wird stark."

---

## 8. Pattern Interrupt / Absurd

**Trigger:** Erwartung wird gebrochen.
**Formel:** Erste Zeile passt nicht zum Thema.

- "Mein 8-jähriger Neffe hat mir das Erklären beigebracht."
- "Ein Frisör hat mir beigebracht, wie man B2B verkauft."
- "Die beste Storytelling-Lektion habe ich in einer Klinik-Warteschlange gelernt."

---

## 9. Prophecy / Zukunft

**Trigger:** Angst / Aufmerksamkeit vor kommender Veränderung.
**Formel:** "In 12 Monaten wird X — und die meisten sind nicht bereit."

- "In 12 Monaten hat jeder Founder einen KI-Ghostwriter. Nur der mit eigener Story wird gehört."
- "2027 ist Reichweite tot. Vertrauen ist die einzige Währung."

---

## 10. Reverse / Umkehrung eines Zitats

**Trigger:** Bekannter Satz wird auf den Kopf gestellt.
**Formel:** Bekannter Spruch → Umgekehrt.

- "'Show, don't tell' ist falsch. Tell, damit sie sehen wollen."
- "'Content is king' — Nein. Kontext ist König. Content ist der Höfling."

---

## Do's

- Erste Zeile MAX 8 Wörter (LinkedIn kürzt nach ~200 Zeichen).
- Zweite Zeile muss die erste vertiefen, nicht auflösen.
- Keine Klammern, keine Emojis in Zeile 1 (Marcos Ton).
- Konkrete Zahlen schlagen Adjektive.

## Don'ts

- "Wir freuen uns…"
- "Heute möchte ich mit euch teilen…"
- "In der heutigen schnelllebigen Zeit…"
- Rhetorische Fragen ohne Substanz.
- Emojis als Ersatz für Kraft im Wort.
