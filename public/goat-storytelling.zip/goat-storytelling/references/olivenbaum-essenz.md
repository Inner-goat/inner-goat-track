---
type: konzept
tags: [storytelling, prinzip, identität, olivenbaum-essenz]
quelle: Marcos Storytelling-Diktat (08.07.2026) — Storytelling-Karten
erstellt: 2026-07-08
---

# Olivenbaum-Essenz

Die Olivenbaum-Essenz beschreibt Marcos Grundüberzeugung, dass Storytelling immer bei der **Identität** beginnt: Es geht darum, herauszustellen, wer jemand im Inneren ist. Storytelling ist das, was du im Inneren hast — du musst es erst *in dir* spüren, bevor du es nach außen tragen kannst.

## Kernidee

> "Es geht darum, die Identität von jemandem herauszustellen. Storytelling ist das, was du im Inneren hast. Dafür musst du erst einmal merken, was in dir drin ist, um das Innere nach außen zu tragen." — Marco

Storytelling ist kein rhetorischer Aufsatz, den man von außen aufträgt. Es ist die **Essenz** eines Menschen, die nach außen gebracht wird — wie der Kern eines Olivenbaums, der Öl gibt. Zuerst kommt das Spüren nach innen, dann das Tragen nach außen. Diese Reihenfolge ist nicht umkehrbar: Wer nach außen erzählt, ohne nach innen gespürt zu haben, produziert Fassade statt Identität.

Zwei Bewegungen, in fester Reihenfolge:

1. **Nach innen spüren** — merken, was wirklich in dir drin ist: deine Identität, dein Kern, deine Wahrheit.
2. **Nach außen tragen** — dieses Innere in eine Geschichte übersetzen, die andere erreicht.

## Wie es funktioniert / Anwendung

- **Erst Identität, dann Technik.** Bevor Framework, Hook oder Struktur überhaupt sinnvoll werden, muss klar sein, *wer* hier erzählt und *was* seine innere Essenz ist.
- **Selbst-Kontakt als Voraussetzung.** Die Frage ist nicht "Welche Geschichte klingt gut?", sondern "Was ist wirklich in mir?". Was du nicht in dir gespürt hast, kannst du nicht glaubwürdig nach außen tragen.
- **Anwendbar auch auf andere.** Als Storyteller/Guide für andere heißt das: die Identität des Gegenübers herausstellen — nicht ihm eine fremde Story überstülpen.

## Beispiel

Ein Founder, der nur Produkt-Features aufzählt, trägt nichts von innen nach außen — er berichtet von außen nach außen. Die Olivenbaum-Essenz verlangt: *Was ist der Kern, aus dem heraus du dieses Produkt überhaupt baust?* Erst wenn dieser Kern spürbar ist, wird aus einem Pitch eine Identität. Genau hier setzt auch [[Der Bruch als Bauplan]] an: Der Bruch ist oft der Moment, in dem die innere Essenz freigelegt wird.

## Für Buch/Artikel

Die Olivenbaum-Essenz ist der Auftakt jedes Storytelling-Kapitels: *"Bevor du erzählst, spüre, was du in dir trägst."* Sie verbindet sich direkt mit [[Lebe deine Geschichte]] (man muss die eigene Geschichte erst leben) und mit [[Storytelling als Lebensveränderung]] (nur wer weiß, wer er im Inneren ist, weiß, wo er als Charakter steht). Für Marcos Positionierung ist sie die Brücke zwischen Storytelling-Handwerk und Identitätsarbeit.

## Verwandte Konzepte

- [[Lebe deine Geschichte]] — man muss das Innere erst leben, um es tragen zu können.
- [[Storytelling als Lebensveränderung]] — Identität zu kennen heißt zu wissen, wo man als Charakter steht.
- [[Der Bruch als Bauplan]] — der Bruch legt die innere Essenz frei.
- [[Reliving vs. Reporting]] — nur aus der inneren Essenz heraus lässt sich wieder-erleben statt berichten.
- [[Marcos eigene Breaking Story]] — Marcos eigenes Innen, nach außen getragen.
- [[Art of Breaking Yourself]] — Signature-Thema; Identität durch Bruch.

## Fußnote (Terminologie)

Marco nannte dieses Konzept zunächst versehentlich **"Alle-Liebenbaum-Methode"** bzw. "Liebenbaum". Der korrekte, verbindliche Name ist **"Olivenbaum-Essenz"**. Frühere Erwähnungen unter dem Fehl-Namen meinen dieses Konzept.

---

Zurück zu [[Storytelling Wissen]].
