---
type: konzept
tags: [storytelling, framework, six-senses, sinne, emotion, immersion]
quelle: Marcos Storytelling-Diktat (08.07.2026) — Storytelling-Karten; extern recherchierter Kontext getrennt gekennzeichnet
erstellt: 2026-07-08
---

# Six Senses Framework

Das Six Senses Framework (auch "6 Senses Framework") ist Marcos Modell für sinnliche Immersion: **Storytelling ist, wenn man alle 5 Sinne PLUS Emotionen anspricht.** Die entscheidende Selbst-Frage beim Erzählen: *Was hast du gefühlt und gerochen, während du die Geschichte erzählst?*

## Kernidee

> "Storytelling ist es, wenn man alle 5 Sinne plus Emotionen anspricht. Denk mal drüber nach, was du gefühlt und gerochen hast, während du sie erzählst." — Marco

Die fünf physischen Sinne — **Sehen, Hören, Tasten/Fühlen, Schmecken, Riechen** — sind das Vehikel. Die **Emotion** ist der sechste "Sinn": das Ziel und der Kleber, der die Szene im Zuhörer verankert. Eine Geschichte, die nur Fakten transportiert, bleibt außen. Eine Geschichte, die Sinne und Gefühl anspricht, wird *erlebt*.

Marcos Prüf-Frage ist bewusst konkret: nicht "war es emotional?", sondern **"was hast du gefühlt und gerochen?"** — Geruch, weil er der am stärksten unterschätzte und zugleich am tiefsten mit Erinnerung verbundene Sinn ist.

## Die 6 Senses

1. **Sehen** — Bilder, Licht, Farben, Bewegung.
2. **Hören** — Geräusche, Stimmen, Stille, wörtliche Rede.
3. **Tasten / Fühlen** — Textur, Temperatur, Körperempfinden.
4. **Schmecken** — Geschmack auf der Zunge, oft übersehen.
5. **Riechen** — Geruch als stärkster Erinnerungs-Trigger.
6. **Emotion** — das Gefühl, das durch die fünf Sinne entsteht und die Szene festklebt.

## Wie es funktioniert / Anwendung

- **Sinne bewusst dosieren, nicht alle gleichzeitig.** Eine dichte Szene braucht 2–3 präzise Sinnesanker, nicht eine Checkliste von fünf.
- **Vom Abstrakten ins Konkrete.** Statt "ich war nervös" → was du gesehen, gehört, gerochen hast, während du nervös warst.
- **Geruch und Fühlen zuerst prüfen.** Weil sie am häufigsten fehlen und am stärksten haften — genau Marcos Frage "was hast du gefühlt und gerochen?".
- **Emotion als Ziel, nicht als Etikett.** Emotion wird über die Sinne *ausgelöst*, nicht behauptet ("Es war so traurig").

## Beispiel

Statt: *"Ich stand vor 400 Leuten und war nervös."*
Mit Six Senses: *"Das Bühnenlicht war heiß im Nacken, der Teppich roch nach Staub und altem Kaffee, mein Mund war trocken — und dann war da diese Stille, in der 400 Menschen auf meinen ersten Satz warteten."*
Dieselbe Szene, aber jetzt *erlebbar*: siehe [[Reliving vs. Reporting]].

## Für Buch/Artikel

Das Six Senses Framework ist das Werkzeug, das aus [[Reliving vs. Reporting]] Praxis macht: Um wieder-zu-erleben statt zu berichten, geht man durch die sechs Sinne. Für ein Kapitel eignet sich die Übung: eine eigene Szene nehmen und für jeden der sechs Sinne einen konkreten Anker notieren — danach nur die drei stärksten behalten.

## 📎 Kontext (extern recherchiert)

*Marcos Definition steht im Zentrum. Folgendes ist externes Fundierungswissen, klar getrennt.*

- **[HINWEIS]** Ein kanonisches, feststehendes "Six Senses Framework" mit genau diesem Namen existiert in der Fach-Storytelling-Literatur **nicht**. Der **Name** ist Marcos eigene Prägung — anschlussfähig, aber kein zitierbarer Fachterminus.
- **[ETABLIERT]** *Sensorisches Erzählen (sensory writing)*: die fünf physischen Sinne bewusst ansprechen, um Immersion zu erzeugen. Klassisches Handwerkskredo: "show, don't tell", konkret statt abstrakt, Sinne dosieren/variieren.
- **[ETABLIERT / wissenschaftlich]** Neurokognitive Fundierung: Sinnesreiche Beschreibungen aktivieren den sensorischen Cortex, verstärken emotionale und kognitive Verarbeitung und können Spiegelneuronen (mirror neurons) anregen → mehr Empathie. Sinnesreize sind eng an Gedächtnis und Emotion gekoppelt.
- **[VERBREITET]** Emotion als "sechster Sinn": mehrere Praktiker-Quellen behandeln Emotion bewusst als sechstes Element zusätzlich zu den fünf Sinnen. Gängige Technik: abstrakte Emotionen über die fünf Sinne greifbar machen (z. B. "Hass sieht aus wie rohes Fleisch, riecht wie faule Eier, fühlt sich an wie Stacheldraht").
- **[EINORDNUNG]** Andockbare, tatsächlich benennbare Konzepte: "sensory writing / sensory language", "show don't tell", "sense-based storytelling".

## Verwandte Konzepte

- [[Reliving vs. Reporting]] — Six Senses ist das Werkzeug des Wieder-Erlebens.
- [[Relevanz]] — Sinnlichkeit trägt nur, wenn die Geschichte relevant ist.
- [[Olivenbaum-Essenz]] — das innere Gefühl, das nach außen getragen wird.
- [[Hook-Bibliothek]] — sinnliche Anker als Hook-Technik.
- [[Kern-Frameworks]] — Six Senses als Fleisch auf jedem Struktur-Skelett.

---

Zurück zu [[Storytelling Wissen]].
