---
type: konzept
tags: [storytelling, plots, frameworks, storybuilder-cards, plot-deck]
quelle: Storybuilder-Cards App (cards.json, Deck 2 "PLOT") + Marcos Diktat
erstellt: 2026-07-08
---

# Die 12 Plots

Jede Geschichte folgt einem Urmuster. Die **12 Plots** sind das PLOT-Deck (Deck Nr. 2, Icon ⚡) der [[Storybuilder Cards]] — 12 archetypische Story-Formen, in die du deinen Inhalt gießen kannst. Untertitel des Decks: *"Welche Form soll deine Geschichte annehmen?"*

## Worum es geht

Das Plot-Deck gibt dir 12 dramaturgische Skelette. Du wählst die Form, die zu deiner Quelle passt — oder du lässt dich überraschen, was passiert, wenn du eine ungewohnte Form wählst. Ein Plot ist das **dramaturgische Skelett** einer Geschichte; das Fleisch (Details, Zitate, sinnliche Anker) kommt aus deiner echten Erfahrung. Siehe auch [[Kern-Frameworks]] und [[Die Heldenreise-Kurve]].

Marcos Auftrag aus dem Diktat war ausdrücklich: *"Alle 12 Plots von den Karten aufarbeiten."* Diese Notiz erledigt das vollständig.

## Wie es funktioniert / Anwendung

Im [[Storybuilder Cards|6-Kategorien-Kartenset]] ist der Plot die **zweite** Karte (Kategorie "Grundidee — Plot-Strukturen", Leitfrage: *"Weißt du, welche Art Geschichte du brauchst?"*). Du legst pro Story genau eine Plot-Karte. In der Grund-Story-Formel der Story-DNA (3 Ps + Pitch + Heldenreise) wird bevorzugt der erste Plot ("Der Drache und die Stadt") operationalisiert (Wer ist der Drache? Die Mauer? Die Bewohner?).

Jede der folgenden 12 Karten hat im Datenfile zusätzlich: 3 vertiefende Langfragen, eine Muster-Story (Beispiel) und einen Bild-Prompt für die Kartengrafik. Hier die Kern-Definition, Bedeutung und Leitfrage jedes Plots.

---

### 1. Der Drache und die Stadt

Der **David-gegen-Goliath-Plot**. Du oder dein Held steht einer überwältigenden Macht gegenüber (System, Konkurrent, Branchenlogik). Funktioniert, weil jeder dem Underdog zujubelt; der Gegner muss real und groß wirken.

**Leitfrage:** "Was ist der übermächtige Gegner, gegen den du antrittst?"

### 2. Die Rebellion

Der **Rebellions-Plot**. Du brichst mit einem ungeschriebenen Gesetz deiner Branche oder deines Umfelds. Polarisiert und schafft klare Position → Wahrnehmung. Wichtig: echte Rebellion, nicht inszenierte Kontroverse.

**Leitfrage:** "Gegen welche Regel oder welchen Konsens stellst du dich – und warum?"

### 3. Die Suche

Der **Quest-Plot**. Du gehst los, um etwas jenseits deines Horizonts zu finden. Hat Bewegung (Stationen, Verbündete, Hindernisse), besonders geeignet für Lern-Storys.

**Leitfrage:** "Wonach hast du gesucht – und was hast du dafür auf dich genommen?"

### 4. Die Heldenrüstung

Der **Transformations-Plot**. Nicht das Endergebnis, sondern der Weg; jedes Rüstungsteil = Lektion, Werkzeug oder schmerzhafte Erfahrung. Die Rüstung darf Risse haben. (Enge Verwandtschaft zu [[Der Bruch als Bauplan]] und [[Art of Breaking Yourself]].)

**Leitfrage:** "Wie bist du von der Person, die du warst, zu der geworden, die du heute bist?"

### 5. Verbotene Liebe

Der **Tabu-Plot**. Eine tiefe Bindung, die andere nicht verstehen (zu Beruf, Projekt, Idee, Mensch) – nicht zwingend romantisch. Zeigt Mut, zu dem zu stehen, was man wirklich will.

**Leitfrage:** "Wofür brennst du, obwohl es 'unvernünftig' wäre?"

### 6. Coming of Age

Der **Reife-Plot**. Der Moment, in dem du eine Stufe überschreitest und nicht mehr zurück kannst (Mitarbeiter→Unternehmer, Mitläufer→Anführer, Performer→Mentor).

**Leitfrage:** "Wann bist du erwachsen geworden – im echten Sinn, nicht biologisch?"

### 7. Die Versuchung

Der **Versuchungs-Plot**. Eine Wegkreuzung, an der du Nein gesagt hast, obwohl Ja einfacher gewesen wäre. Zeigt deine Werte, ohne zu predigen; die Versuchung muss echt verlockend gewesen sein.

**Leitfrage:** "Welches verlockende Angebot hast du abgelehnt – und warum?"

### 8. Der Underdog

Der **Außenseiter-Plot**. Du wirst übersehen, belächelt oder nicht ernst genommen – und genau das wird dein Vorteil. Hochemotional, impliziter Mutmacher.

**Leitfrage:** "Wo hat dich niemand auf dem Schirm gehabt – und du hast trotzdem geliefert?"

### 9. Die Rache

Der **Vergeltungs-Plot**. Braucht Reife: als "Erfolg um zu beweisen" wirkt es kindisch; als ehrlichen Antrieb inklusive Schattenseite anerkannt, wird es stark. Viele Founder-Storys haben einen Rache-Kern.

**Leitfrage:** "Wem oder was hast du es 'gezeigt' – und was hat dich dazu getrieben?"

### 10. Das Rätsel

Der **Mystery-Plot**. Du stellst eine Frage und zögerst die Antwort hinaus (stark für LinkedIn). Die Auflösung muss halten, was die Frage verspricht. (Vgl. den Question-Hook in der [[Hook-Bibliothek]].)

**Leitfrage:** "Welche Frage hat dich beschäftigt, deren Antwort sich erst spät offenbart hat?"

### 11. Die Allianz

Der **Bündnis-Plot**. Co-Founderschaft, Mentoring, Team-Dynamik oder eine entscheidende Begegnung. Zeigt, dass du nicht alles allein gemacht hast; den Partner würdigen.

**Leitfrage:** "Mit wem hast du dich verbündet – und was wurde dadurch möglich?"

### 12. Die Entdeckung

Der **Heureka-Plot**. Ein Erkenntnis-Moment, der etwas Neues ans Licht bringt (Methoden-Storys, Branchen-Insights, persönliche Einsichten). Die Entdeckung muss kontraintuitiv sein.

**Leitfrage:** "Was hast du gefunden, was vorher niemand gesehen hat – oder was du selbst übersehen hast?"

---

## Vollständigkeit

Alle **12 von 12** Plots wurden mit Name, Reihenfolge (1–12), Bedeutung und Leitfrage gefunden und aufgearbeitet. Nichts fehlt.

## Für Buch/Artikel

- Das Plot-Deck ist das dramaturgische Rückgrat jeder Marco-Story. Für ein Buch-Kapitel eignet sich die Struktur "Ein Plot pro Unterkapitel" — jeder der 12 ###-Abschnitte oben kann zu einer Einzelnotiz und später zu einem eigenständigen Kapitel-Baustein werden.
- Starker Aufhänger: Die Plots sind nicht als Genre-Schubladen gedacht, sondern als **Experimentierfeld** — dieselbe wahre Begebenheit fühlt sich als "Rache" völlig anders an als als "Entdeckung". Genau da entsteht Positionierung.
- Founder-Kontext: Marcos Beobachtung "viele Founder-Storys haben einen Rache-Kern" (Plot 9) ist ein ehrlicher, unbequemer Hebel, den kaum jemand ausspricht.

## Verwandte Konzepte

- [[Storybuilder Cards]] — die App, in der die 12 Plots als Deck 2 leben
- [[Kern-Frameworks]] — Heldenreise, Story Circle, 3-Akt u.a. als übergeordnete Skelette
- [[Die Heldenreise-Kurve]] — warum Social Media heute bei 80 % einsteigt
- [[Der Bruch als Bauplan]] · [[Art of Breaking Yourself]] — enger Bezug zu Plot 4 (Heldenrüstung)
- [[Hook-Bibliothek]] — passende Openings je Plot
- [[Relevanz]] — jeder Plot braucht einen Grund, warum du ihn erzählst
- [[Storytelling Wissen]] · [[Inner GOAT Academy]]
