# Breaking-Yourself — Fallbank

Reale Storys, zerlegt nach den 6 Beats aus `01_Frameworks/der_bruch_als_bauplan.md`.

Prinzip: **Beispiele sind kein Schmuck, sie sind Beweis.** Jede Behauptung im Framework wird durch mindestens eine dieser Storys geerdet.

---

## Kategorie A — Körperlicher Bruch

### 1. Alex Zanardi (F1-Pilot → Paralympic-Goldmedaillengewinner Handbike)

- **Vorher-Selbst:** F1-Pilot, CART-Champion 1997/98, oben angekommen.
- **Auslöser:** 15. September 2001, Lausitzring. Auf der letzten Runde verliert er Kontrolle, sein Auto wird von einem anderen mit 300 km/h getroffen. Beide Beine ab.
- **Weigerung:** —
- **Der Riss:** Die Ärzte geben ihn zeitweise auf. Sein Herz stoppt sieben Mal.
- **Motivationsverschiebung:** Nicht mehr "schneller sein als andere". Sondern: *herausfinden, was Menschen können, wenn sie eigentlich nichts mehr können sollten.*
- **Neue Handlungsebene:** Zurück in einen umgebauten F1-Wagen und beendet symbolisch die 13 Runden, die er nie fahren durfte. Wechselt zum Handbike, holt 4× Paralympic-Gold (London 2012, Rio 2016).

**Warum diese Story funktioniert:** Der Bruch ist so absolut, dass die Neugier riesig ist. Und die Motivationsverschiebung ist präzise benennbar — nicht "Resilienz", sondern eine neue Frage.

---

### 2. Patrick Anderson (Kanada, gilt als bester Rollstuhl-Basketballer aller Zeiten)

- **Vorher-Selbst:** 9-jähriger Junge in Ontario, sportbegeistert.
- **Auslöser:** 1988, ein betrunkener Fahrer erfasst ihn. Beide Beine oberhalb des Knies amputiert.
- **Weigerung:** —
- **Der Riss:** Das "gehende Kind" endet mit 9. Das Selbstbild eines Athleten muss von Grund auf neu gebaut werden.
- **Motivationsverschiebung:** Anderson beschreibt in Interviews, dass er nie einen "Comeback"-Weg gegangen ist — er hat NEU angefangen. Nicht die Sportart wechseln, sondern die Art, Sport zu denken.
- **Neue Handlungsebene:** 4× Paralympic-Medaillengewinner (3× Gold), gewinnt mit Team Canada 2000, 2004, 2012. Wird international als "the greatest wheelchair basketball player of all time" bezeichnet.

**Anmerkung Marco:** Falls das die Story aus dem Video war — hier ist sie strukturiert. Wenn Video-Athlet ein anderer war, sag mir wer, ich baue seine Struktur.

---

### 3. Bo Kramer (Niederlande, Rollstuhl-Basketball, Weltmeisterin)

- **Vorher-Selbst:** 13-jährige mit Basketball-Talent.
- **Auslöser:** Knochenkrebs mit 13. Ein Bein wird amputiert.
- **Weigerung:** Beschreibt in Interviews die Phase, in der sie den Sport aufgeben wollte.
- **Der Riss:** Erkenntnis, dass "der Krebs sie zwar geschlagen hat, aber nicht besiegen wird".
- **Motivationsverschiebung:** Vom "kranken Mädchen" zur "Athletin mit einer anderen Ausrüstung".
- **Neue Handlungsebene:** Weltmeisterin 2018, Paralympics 2021 & 2024, MVP der WM.

---

## Kategorie B — Moralischer Bruch

### 4. Steve Jobs (gefeuert bei Apple 1985)

- **Vorher-Selbst:** 30 Jahre alt, Mitgründer von Apple, gerade nach dem Macintosh-Launch. Öffentlichkeitsdarling.
- **Auslöser:** Der eigene CEO (John Sculley, den Jobs selbst geholt hatte) und der Aufsichtsrat entmachten ihn und werfen ihn raus.
- **Weigerung:** Erste Monate in Depression. Dachte laut Eigenaussage über Selbstmord nach.
- **Der Riss:** Erkenntnis, dass er nicht mehr "der Apple-Gründer" ist — sondern ein 30-Jähriger, dessen Identität weggenommen wurde.
- **Motivationsverschiebung:** Nicht mehr "Beweisen, dass ich der Beste bin". Sondern: *aus Neugier bauen, ohne den Druck, ein Genie zu sein.* Diese Phase produziert NeXT und Pixar.
- **Neue Handlungsebene:** Kehrt 1997 zu Apple zurück. Und macht das, was Apple berühmt macht — iPod, iPhone, iPad — erst nach dem Bruch.

**Zitat, das die Motivationsverschiebung einfängt (Stanford 2005):**
> "Getting fired from Apple was the best thing that could have ever happened to me. The heaviness of being successful was replaced by the lightness of being a beginner again."

---

### 5. Reinhold Messner (verlor Bruder am Nanga Parbat)

- **Vorher-Selbst:** Zwei junge Brüder, gemeinsam auf jeden Berg. Reinhold + Günther Messner.
- **Auslöser:** 1970, Nanga Parbat. Günther stirbt beim Abstieg. Reinhold überlebt schwer verletzt (verliert 7 Zehen).
- **Weigerung:** Fast alle sagen: hör auf. Sein Vater sagt es. Die Öffentlichkeit sagt es.
- **Der Riss:** Er entscheidet, das Gegenteil zu tun. Nicht aufhören — kompromissloser weitermachen. "Alpinismus mit fair means".
- **Motivationsverschiebung:** Nicht mehr "bezwingen". Sondern: *am Berg das Menschsein an seine Grenze bringen.*
- **Neue Handlungsebene:** Als erster Mensch alle 14 Achttausender ohne Sauerstoff. Ohne diesen Bruch — nach eigenen Aussagen — undenkbar.

---

## Kategorie C — Erwartungs-Bruch

### 6. Sara Blakely (Spanx-Gründerin)

- **Vorher-Selbst:** 27 Jahre alt, verkauft Faxgeräte in Florida von Tür zu Tür. Weinend jeden Morgen im Auto.
- **Auslöser:** Sie schneidet die Füße aus einer Strumpfhose, um unter einer weißen Hose keine Ränder zu haben. Erkennt: "Millionen Frauen wollen das."
- **Weigerung:** Rechtsanwälte lachen sie aus. Textilhersteller lachen sie aus. Männer in der Branche lachen sie aus.
- **Der Riss:** Sie kündigt den Fax-Job. 5.000 Dollar Ersparnisse. Kein Plan B.
- **Motivationsverschiebung:** Nicht mehr "Ich muss verkaufen, was mir jemand anderes gibt". Sondern: *ich muss verkaufen, was ich selbst brauche, und ich vertraue, dass andere es auch brauchen.*
- **Neue Handlungsebene:** Spanx wird Milliarden wert. Blakely wird jüngste Selfmade-Milliardärin.

---

### 7. Oprah Winfrey (frühe Ablehnung)

- **Vorher-Selbst:** Junge TV-Reporterin, gefeuert weil "nicht fürs Fernsehen geeignet".
- **Auslöser:** Wiederholte Ablehnungen. Kindheitstrauma (Missbrauch), das öffentlich später zum Thema wird.
- **Der Riss:** Erkenntnis, dass die "Fernseh-Anforderungen" der 80er ihr nie passen werden. Sie muss ein anderes Fernsehen erfinden.
- **Motivationsverschiebung:** Nicht mehr "Ich muss ins Fernsehen reinpassen". Sondern: *ich muss ein Fernsehen bauen, in das ich reinpasse.*
- **Neue Handlungsebene:** The Oprah Winfrey Show. 25 Jahre Nummer 1. Neuerfindung des Talkshow-Formats.

---

## Kategorie D — "Nicht-genug"-Bruch

### 8. Michael Jordan (Highschool-Cut)

- **Vorher-Selbst:** 15-jähriger Basketballer, überzeugt, in das Varsity-Team zu kommen.
- **Auslöser:** Wird nicht ins Team gewählt — sein bester Freund schon. Er sieht die Liste ohne seinen Namen.
- **Weigerung:** Weint zuhause in seinem Zimmer stundenlang. Seine Mutter beschreibt es später als "the worst day of his young life".
- **Der Riss:** Entscheidung: das darf nie wieder passieren.
- **Motivationsverschiebung:** Nicht mehr "spielen weil ich es liebe". Sondern (aus MJs Doku *The Last Dance*): *jede Ablehnung, jede Kritik, jedes "Nein" wird zu Brennstoff. Ich sammle sie.*
- **Neue Handlungsebene:** 6 NBA-Titel. 5× MVP. "I've missed more than 9000 shots…" — der berühmte Werbespot.

---

### 9. Viktor Frankl (Auschwitz-Überlebender, "Man's Search for Meaning")

- **Vorher-Selbst:** Wiener Psychiater, gerade eine Karriere im Aufbau.
- **Auslöser:** Deportation. Verliert Frau, Eltern, Bruder in den Lagern.
- **Der Riss:** Alles ist weg. Familie, Manuskripte, Identität als Arzt.
- **Motivationsverschiebung:** Nicht mehr "Karriere machen". Sondern: *verstehen, was einen Menschen im Lager überleben lässt — und diese Antwort weitergeben.*
- **Neue Handlungsebene:** "…trotzdem Ja zum Leben sagen" (dt. Titel) / "Man's Search for Meaning". Meistgelesenes Sinn-Buch des 20. Jahrhunderts. Gründet die Logotherapie.

---

## Wie diese Bank benutzen

- **Für jeden LinkedIn-Post:** eine Story pro Post. Nicht zwei. Konzentration.
- **Für YouTube-Long-Form:** 1 Athlet/Founder tief zerlegen ODER 3 kurze Storys um EIN Konzept clustern.
- **Für den Skill:** die Bank wird zum Trainings-Material für das LLM (Beispiele, an denen der Nutzer erkennt, wie sein eigener Bruch strukturiert wäre).

**Was noch fehlt:** Bank wächst mit jeder gefundenen Story. Neue Kandidaten: Nelson Mandela (27 Jahre Gefängnis = kollektiver Bruch), Malala Yousafzai, Bethany Hamilton (Surferin, Hai-Attacke), Nick Vujicic, Elon Musk (2008-Kollaps), Jack Ma (10× abgelehnt).
