---
type: playbook
tags: [marco, schreibstil, tonalitaet, content]
erstellt: 2026-07-08
---

# Schreibstil

Übergreifende Tonalität für alles, was in Marcos Namen geschrieben wird — von LinkedIn-DMs bis Storytelling-Posts. Die Detail-Regeln stehen in [[Outreach-Stil LinkedIn]] und [[Storytelling-Content-Regeln]].

## Grundton

- **"Moin" statt "Hi"/"Hey"/"Hallo"** — der typische Marco-Opener, besonders im Outreach.
- **Direkt und niedrigschwellig**: kein Pitchen, keine harten CTAs wie „Bock auf Call?". Stattdessen weiche Einladungen („Lass uns gerne austauschen").
- **Kurze Sätze. Punkte statt Kommas.** Leicht informell, aber nie schnoddrig.
- **Keine Emojis** in Direct-Outreach — kein 🐐, keine ✨, trotz GOAT-Branding bewusst zurückhaltend.
- **Signoff: "LG, Marco"** — deutsches „Liebe Grüße", abgekürzt.
- **Deutsch** ist die Standardsprache ([[Marco Maiworm]] ist deutschsprachig).

## Selbstpositionierung

- Immer **"Founder bei [[Inner GOAT]]"** — NICHT „Co-Founder", auch wenn Marco das auf WhatsApp manchmal selbst so sagt. Im Cold-Outreach positioniert er sich als Founder solo.
- Im Content positioniert er sich als **Storytelling-Experte**, nicht als Selbstinszenierer — siehe [[Storytelling-Content-Regeln]].

## Ehrlichkeit als Stil-Grundsatz

- **Nichts über Marco erfinden.** Keine erfundenen Ich-Storys, die real klingen. Hypothesen und Analogien nur klar markiert („Stell dir vor…"). Details in [[Storytelling-Content-Regeln]] und [[Art of Breaking Yourself]].
- Personalisierung ist echt: Im Outreach wird ein **konkretes Zitat** aus dem Profil/Intro der Zielperson verwendet — zeigt, dass gelesen wurde, kein Copy-Paste.

## Wohin für Details

| Anwendungsfall | Notiz |
|---|---|
| LinkedIn-Connects & DMs an Leads | [[Outreach-Stil LinkedIn]] |
| Posts & Videos (Aufbau, Anekdoten-Quellen) | [[Storytelling-Content-Regeln]] |
| Signature-Thema & Framework | [[Art of Breaking Yourself]] |
| Wissensbasis Storytelling | [[Storytelling Wissen]] |
