---
type: playbook
tags: [content, linkedin, social-media, posting, hooks, storytelling, ki-prompt, founder-workspace]
quelle: Notion
erstellt: 2026-07-08
---

# Content-Templates (Social / LinkedIn)

Sieben erprobte Posting-Frameworks für LinkedIn/Instagram/Facebook plus Hook-Bibliothek, Storytelling-Struktur, Bio-Templates und ein KI-Prompt, der Posts nach DIR statt nach KI klingen lässt. Jedes Template hat eine klare Funktion im Funnel — von Filter (Wer passt zu mir?) bis Trust (Wer bin ich?). Ergänzt die vault-eigene [[Hook-Bibliothek]] und [[LinkedIn-Post-Sammlung]]; bindet an die [[Storytelling-Content-Regeln]].

## Kontext & Anlass

Stammt aus der Notion-Seite "✍️ Content-Templates (Social / LinkedIn)" im Inner GOAT Founder Workspace 2.0. Nutzung: pro Woche 1–2 Templates wählen, Platzhalter mit Avatar-Kontext ([[Sales Foundation]]) füllen, Post im **Social Media Planner** (Tracker im laufenden Notion) einplanen und dort Engagement tracken.

## Die 7 Posting-Frameworks

### 1. "Wir passen nicht zueinander" (Pre-Filter)
Sortiert direkt aus, wer NICHT Kunde ist → erhöht DM-Qualität.
> Wir passen nicht zueinander, wenn: • Du [Grund 1] • Du [Grund 2] • Du [Grund 3]. Die [Kundentypen], denen wir geholfen haben, [Transformation] zu erreichen, sind [Eigenschaften], die bereit sind, [Zeit/Aufwand] zu investieren. Klingt das nach dir? Schick mir eine PN mit dem Wort [CODEWORT].

### 2. "Quick Win" (Lead-Magnet mit Zeitdruck)
Aktiviert Hot Leads, die JETZT etwas wollen.
> Ich suche bis [Datum] [Anzahl] [Zielgruppe], die [Ziel] innerhalb [Zeitrahmen] erreichen wollen — ohne [Schmerzpunkt]. Willst du mehr Infos? Schick mir eine DM mit dem Wort [CODEWORT].

### 3. "Schmerzpunkt" (Empathie & Verbindung)
Eigene Tiefen teilen, Pain normalisieren, zum Gespräch einladen — authentisch, nicht jammernd.
> Eine Sache, mit der ich als [Rolle] gerungen habe, ist [Schmerzpunkt]. Die Höhenflüge sind berauschend, aber die Tiefs können schrecklich sein. Schlaflose Nächte: • [Symptom 1–3]. Aber das ist der Preis: Die Kosten für [Nutzen 1–3] sind [Symptom 1–3]. Ein wilder Ritt, aber ich würde es für kein Geld ändern. Hast du damit auch zu kämpfen? Mein Posteingang ist offen.

### 4. "Dein Prozess" (Methode zeigen)
Beweist Expertise, leitet zum DM-CTA über.
> Hier ist der exakte Prozess, den ich mit Kunden durchlaufe, um [Transformation] zu erreichen. [Angebotsname] ist [Dauer], das Unternehmern hilft, [Transformation] zu erreichen — in [X] Schritten: 1. [Schritt] 2. [Schritt] 3. [Schritt]. (Optional: Resultate auf [Website/Case Study/YouTube].) Wenn du mehr [Ergebnis] willst, schreib mir eine PN.

### 5. "Bewunderer" (Netzwerk / Trust through Association)
Beziehungen aufbauen durch ehrliche Würdigung anderer.
> Manche Menschen haben einfach [Eigenschaft]. [Name] ist einer davon. Als ich [Name] das erste Mal [Kontext] kennenlernte, wusste ich sofort [warum du ihn bewunderst]. Jeder, der ihn kennt, weiß, dass er: • [Eigenschaft 1–3]. Danke, [Name], für [Einfluss].

### 6. "Anfänger vs. Profi" (Education & Reframe)
Zeigt den Sprung — positioniert dich implizit als Profi, deine Methode als Brücke.
> [Thema]-Anfänger: ❌ [Punkt 1–3]. [Thema]-Profi: ✅ [Punkt 1–3]. [Zusammenfassender Satz — was den Unterschied ausmacht.]

### 7. "Die Vorstellung" (Re-Introduction)
Nach Posting-Pause / Profil-Update / Quartalsstart; setzt Positionierung neu.
> Liebes Netzwerk, es ist wieder eine Weile her! Ich bin [Name]. [3 Attribute]. Ich ermögliche es [Zielgruppe], [Transformation]. [Methode] individuell angepasst ist, was ich am besten kann. Meine Mission: [positiven Einfluss stärken]. Das bedeutet: ✅ [Vorteil 1–3]. Wie ich das mache? 🚀 [Differenziator 1–3]. Erzähl mir von dir — woran arbeitest du gerade?

## Bio-Templates (LinkedIn-Profil / Website)

- **Variante 1 — sachlich-strategisch:** *"I am an open-minded and empathic person with a passion for [Feld]. I think strategically, solution- and customer-oriented … Privately, you will find me [privater Anker]."*
- **Variante 2 — energetisch-motivierend:** längerer, emoji-reicher "Are you ready to take your business to the next level?"-Text (siehe Notion-Original für Vollversion).

## KI-Prompt: LinkedIn-Coach (klingt nach DIR)

System-Prompt für ChatGPT/Claude/Gemini — als erste Nachricht einfügen; die KI fragt dann nach dem Thema und liefert einen ~200-Wörter-Post. Kernbaustein für Marcos Content — deckt sich mit den [[Storytelling-Content-Regeln]].

```text
Du bist mein LinkedIn Coach. Du schreibst Texte, die nach mir klingen, nicht nach KI.

DEINE AUFGABE
Ich gebe dir ein Thema, eine Situation oder einen Rohgedanken. Du baust daraus einen LinkedIn Post von ca. 200 Wörtern.

HARTE STILREGELN
Keine Bindestriche. Weder als Gedankenstrich noch in zusammengesetzten Wörtern. Komposita auseinanderschreiben (Online Kurs, LinkedIn Post). Wo ein Strich stünde: Punkt, Komma oder neuer Satz.
Keine Emojis. Nirgends, auch nicht im Hook.
Kein Stakkato. Nicht jeder Satz auf eigener Zeile. Absätze bestehen aus mehreren zusammenhängenden Sätzen.
Keine KI Floskeln: "tauchen wir ein", "in der heutigen schnelllebigen Welt", "hier ist die Sache", "die unbequeme Wahrheit", "plot twist", "letztendlich", "zusammenfassend".
Keine Antithesen: Kein "Nicht X, sondern Y" als Stilmittel.
Keine Trios: Maximal 2 parallele Sätze mit gleichem Anfang.
Keine Buzzwords: Kein "Game-Changer", "Disruptiv", "Mindset", "Synergien", "Deep Dive".
Keine leere Struktur: Einleitung plus 3 Punkte plus Fazit ist verboten, wenn nichts Echtes drin steht.
Keine simulierte Empathie: Kein "Ich verstehe deine Schmerzen", "Wir alle kennen das".

SO SCHREIBE ICH STATTDESSEN
Lange Sätze dominieren, kurze nur als bewusster Akzent. Sehr gutes Deutsch, keine Anglizismen wo das deutsche Wort sauberer ist. Provokante Aussagen, die zur Diskussion einladen. Nie Preise oder Zahlen erfinden. Nie Dialoge, Zitate oder Szenen erfinden. Wenn du dir bei einem Fakt nicht sicher bist, frag mich. Am Ende steht ein Positionierungspunch oder eine Frage, die wirklich Reichweite zieht. Mindestens drei Hashtags inline im Fließtext.

JETZT STARTE
Frag mich zuerst: Über welches Thema oder Erlebnis soll der Post gehen?
```

**Warum er funktioniert:** definiert die Rolle statt nur der Aufgabe · verbietet KI-Floskeln und LinkedIn-KI-Marker (Stakkato, Antithesen, leere Struktur) explizit · gibt den eigenen Stil positiv vor · zwingt zur Rückfrage statt erfundener Fakten. Anpassbar: Wortzahl, Plattform, Hashtag-Anzahl, eigene No-Go-Wörter, Schwerpunktthemen.

## Hook-Bibliothek

> Die erste Zeile entscheidet, ob der Post zu Ende gelesen wird. (Ausführliche vault-eigene Sammlung: [[Hook-Bibliothek]].)

- **20 allgemeine Hooks** (Education/Filter) — z.B. *"Niemand spricht darüber: [Problem], aber es betrifft [Zielgruppe]."* · *"90% der [Zielgruppe] machen diesen Fehler bei [Thema]."* · *"Was ich gerne früher über [Thema] gewusst hätte."* · *"[Anzahl] brutale Wahrheiten über [Thema], die dir keiner gesagt hat."*
- **15 Storytelling-Hooks** — persönlich, emotional, z.B. *"Ich erinnere mich noch genau an den Moment, als ich realisierte, dass [Problem] mein größtes Hindernis war."* · *"Viele erzählen dir nur die Erfolgsgeschichten. Heute erzähle ich, wie ich bei [Thema] komplett gescheitert bin."*
- **10 Expertenpost-Hooks** (nach Post-Typ): How-to · Fehler-Post · Mini-Analyse · Framework-Post · Mythbusting · Vergleich · Case Study · Quick-Tipp · Insight · Warning.

## Storytelling-Vorlage (6-Schritte-Struktur)

Für LinkedIn-Posts, E-Mails, Skript-Eröffnungen. Deckt sich mit dem vault-eigenen Storytelling-Wissen ([[Der Bruch als Bauplan]], [[Die Heldenreise-Kurve]]):

1. **Hook** — Emotion/Neugier ("Für viele klingt es wie ein Albtraum — für mich war es Realität: …").
2. **Einstiegssituation** — Setting, erste Erfolge/Herausforderungen, aber "irgendwas läuft schief".
3. **Konflikt** — trotz Mühe kein Vorankommen, andere ziehen vorbei.
4. **Wendepunkt** — die Erkenntnis: [Fehler/Denkweise] hinderte; neue Strategie angewandt.
5. **Ergebnis** — nicht über Nacht, aber innerhalb [Zeitraum] drehte sich alles.
6. **Takeaway** — Impuls an den Leser: "Hör auf zu kämpfen, wo ein Perspektivwechsel nötig ist."

Zusätzlich das Vulnerability-Format **"Mach nicht die gleichen Fehler wie ich"** (Fehler schildern → Weg raus → Impuls zur Handlung).

## Wochen-Rhythmus (Startpunkt, nicht sklavisch)

| Tag | Post-Typ | Hook-Quelle |
| --- | --- | --- |
| Mo | Education / Framework | Allgemeine Hooks #1/#6/#10 |
| Di | Story / Vulnerability | Storytelling-Hooks #1/#5/#9 |
| Mi | Quick-Tipp | Expertenpost #8 |
| Do | Mythbusting / Provokation | Allgemeine Hooks #5/#11 |
| Fr | Insight / Reflexion | Expertenpost #9 |
| Sa | Case Study | Expertenpost #7 |
| So | Bewunderer / Community | Framework #5 |

## Anwendung

- Templates mit Avatar-Painpoints aus [[Sales Foundation]] füllen.
- Für Cold-DMs/Outreach gilt zusätzlich der [[Outreach-Stil LinkedIn]].
- Content-Substanz und Ich-Story-Verbot: [[Storytelling-Content-Regeln]].
- Vertieft in der [[Inner GOAT Academy]] (Reiter 3 — Modul 2 Content).

## Verwandte Notizen

- [[Hook-Bibliothek]]
- [[LinkedIn-Post-Sammlung]]
- [[Storytelling-Content-Regeln]]
- [[Sales Foundation]]
- [[Akquise & Skript-Bibliothek]]
- [[Outreach-Stil LinkedIn]]
- [[Inner GOAT Academy]]
