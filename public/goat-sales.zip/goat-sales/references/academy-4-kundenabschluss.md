---
type: wissen
tags: [academy, sales, kundenabschluss, verkauf, sales-call, discovery-call, skripte, einwandbehandlung]
reiter: Reiter 3 – Sales, Marketing & Personal Branding
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 4 – Kundenabschluss

Dieses Modul der [[Inner GOAT Academy]] behandelt den kompletten Verkaufsprozess vom ersten Gespräch bis zum Abschluss. Der Kern ist eine **Zwei-Call-Strategie**: Zuerst ein Kennenlern-/Discovery-Call (Vertrauen aufbauen, Problembewusstsein wecken), dann ein separater Sales-Call (Weg zur Lösung zeigen, abschließen). Beide Calls sind psychologisch fundiert aufgebaut und werden über zwei ausgearbeitete Leitfäden/Skripte gefahren, die man an das eigene Wording anpasst — aber nicht in Struktur oder Reihenfolge verändert.

Durchgehende Bilder des Moduls: **Pain Island → Dream Island** (dein Angebot ist die Brücke), die **4 Säulen des Vertrauens** (Thermostat-Modell), **Show, don't tell** und **Doubt and Check** (Menschen lügen). Verwandt mit dem Storytelling-Fundus siehe [[Storytelling Wissen]]; das Pain-Island-/Dream-Island-Muster ist eng verwandt mit [[Der Bruch als Bauplan]] und dem Rebirth-Plot aus [[Die 12 Plots]], und die Frage, ob der Kunde sich wiederfindet, hängt an [[Relevanz]].

---

## 01 · Einführung

Rahmen-Video für das gesamte Coaching. Kernbotschaft: Das System funktioniert — wenn du es Schritt für Schritt durcharbeitest und deine Einstellung stimmt. Videos in Reihenfolge schauen, keine Übersprünge, Dinge sofort umsetzen statt nur konsumieren („kein Netflix"). Auch bekannte Inhalte können neue Nuancen enthalten; deine Einstellung entscheidet, was du mitnimmst.

**Fahrplan — 5 Phasen zur Wunschsituation:**
1. **Klarheit** schaffen (Business und Lebensbereiche)
2. **Systeme etablieren** (Grundlage für Umsetzung)
3. **Blockaden aufdecken** (was hält dich individuell)
4. **Blockaden auflösen**
5. **Umsetzen & maximieren**

Beweis: über 100 Kunden haben das System durchlaufen, fünf- bis sechsstellige Monatsumsätze mit mehr Zeit und Lebensqualität. Verwandtes Mindset-Prinzip: schrittweise vorgehen, „think smaller, not bigger".

## 02 · Aufbau und Skripte

Führt die **Zwei-Call-Strategie** ein — das strategische Fundament des Moduls.

- **Call 1 — Kennenlern-/Discovery-Call:** Vertrauen aufbauen, Expertise zeigen („Show, don't tell"). Kein Verkauf.
- **Call 2 — Sales-Call:** Der eigentliche Abschluss, psychologisch aufgebaut.

Warum nicht im ersten Call verkaufen: Erst Vertrauen, dann Entscheidung. Druck im ersten Call schadet mehr als er nützt.

**Umgang mit den Leitfäden:** Nicht Wort für Wort ablesen — aber Struktur und Kernfragen an den richtigen Stellen einhalten. Am Anfang Leitfaden im Split Screen neben dem Call halten. Leitfaden mehrfach lesen, vor dem Spiegel üben, als Sprachmemo aufnehmen und das eigene natürliche Wording einbauen. Ziel: Der Leitfaden sitzt so sicher, dass du „nachts um drei geweckt" die richtige Antwort parat hast. Prinzip: Wissen ist Potenzial, Umsetzung ist Momentum — Fortschritt entsteht nur durch Iteration.

## 03 · Dein Auftritt in Calls

Dein **Setting im Call ist wie Handtücher im Hotel** — es wird nicht bemerkt, wenn es gut ist, aber sofort, wenn es fehlt. Es geht nicht um Oberflächlichkeit, sondern um das Eliminieren von Reibungspunkten, die dich Sales kosten. Vertrauen ist zentral, also willst du vertrauenswürdig rüberkommen.

**Checkliste:**
- **Tonalität** — klares Mikrofon, keine Hintergrundgeräusche (kein Café/Airport, wo man nur die anderen versteht)
- **Licht** — Softbox oder gutes natürliches Licht, klar erkennbar, nicht im Dunkeln
- **Hintergrund** — aufgeräumt, kein virtueller Hintergrund; Bonus: Zertifikate / markenrelevante Elemente sichtbar
- **Kleidung** — „Kragen-Gesetz" (Polo, Rollkragen, Sakko), passend zur Zielgruppe (nicht zu förmlich, nicht zu locker)
- **Selbsttest** — Würdest du bei dir selbst kaufen, so wie du gerade im Call sitzt?

Faustregel: Schau dir die größten Experten deiner Branche an — wie treten die auf? Das ist der erwartete Standard. Verwandtes Branding-Prinzip: Wahrnehmung schlägt Wahrheit — wenn du nicht definierst, wie man dich sehen soll, tut es ein anderer.

## 04 · 4 Säulen des Vertrauens

Vertrauen ist die wichtigste Ressource im Verkauf (Analogie: Starbucks/McDonald's/Mercedes — bekannte Marken bekommen Vertrauen durch viele Berührungspunkte). Vertrauen beruht auf vier Säulen, die man sich wie **Thermostate** vorstellt: Alle vier müssen von kalt zu heiß werden, damit gekauft wird.

**Die 4 Säulen:**
1. **Vertrauen in dich** — als Person und Verkäufer (Auftreten, Sicherheit)
2. **Vertrauen in deine Firma/Brand** — was hat die Person gehört/gesehen?
3. **Vertrauen in die Dienstleistung/das Produkt** — glaubt sie, dass es ihr Problem löst?
4. **Vertrauen in sich selbst** — Zeit, Ressourcen, Selbstvertrauen, in die Umsetzung zu kommen?

**Ferrari-Beispiel:** Sind drei Säulen heiß, schließt selbst ein mittelmäßiger Verkäufer ab. Bleibt eine Säule kalt (schlechter Verkäufer, kein Geld/Zutrauen, verrufenes Produkt, misstrautes Ergebnis), sinkt die Kaufwahrscheinlichkeit — egal wie stark die anderen sind.

**Praxis:** Wenn jemand zögert, frage dich: Welche Säule ist noch nicht heiß? Beispiel: Wer schon 20.000 € mit Ads verbrannt hat, hat kein Vertrauen mehr in Ads (Säule 3) — dort muss zuerst Vertrauen aufgebaut werden. Verwandt: People buy from people — emotionale Resonanz aktiviert Mirror Neurons.

## 05 · Verständnis Kennenlerncall

Die **Psychologie hinter dem Discovery Call**. Aufgabe: den potenziellen Kunden von der Ausgangssituation über Problembewusstsein zu Lösungsbewusstsein führen.

**Drei Stufen:**
1. **Ausgangssituation** — die Person weiß noch nicht, dass sie ein Problem hat; sie ist im Call, um „Mehrwert" zu bekommen
2. **Problembewusstsein** — durch gezielte Fragen erkennt sie ihre Herausforderung (meist eine ganze Kette von Problemen)
3. **Lösungsbewusstsein** — sie versteht, dass es eine bessere Möglichkeit gibt

**Was du im Call NICHT tust:** Preis nennen, direkt closen, das ganze Business umkrempeln. Fragt jemand nach dem Preis, framest du auf den Sales-Call („dann schaue ich mir deine Situation genau an und mache dir ein passendes Angebot").

**Was du stattdessen tust:** Eine Lösung für ein spezifisches Problem zeigen, Expertise durch Mehrwert beweisen (Show, don't tell), am Ende einen **Cliffhanger** setzen, der Lust auf den Sales-Call macht (Netflix-Analogie). Führe die Person durch Fragen zur **Selbsterkenntnis** — nicht belehren („du brauchst keinen Trainingsplan"), sondern Aha-Momente erzeugen (z. B. „Wie viele Kalorien isst du?").

**Dopamin-Prinzip:** Ein Aha-Moment schüttet Dopamin aus — die Person verbindet dieses Glücksgefühl mit dir und will mehr. Dein Angebot ist später die Brücke von **Pain Island** zu **Dream Island**.

## 06 · Kennenlerncall

Das **vollständige Skript für den Kennenlerncall** plus ausführliches Transkript. Ablauf in 8 Schritten:

1. **Kurzer Smalltalk** — Eis brechen, kurz halten (Zeit respektieren).
2. **Kunde vorstellen lassen & Infos sammeln** — Kontrolle behalten (wir stellen die Fragen), Werte heraushören (Geld/Umsatz vs. Freiheit vs. Erfüllung), erste Rückfragen stellen. Prinzip „Be water" — sich an die Persönlichkeit anpassen (introvertiert/extrovertiert), aber nicht verstellen.
3. **Du stellst dich vor (Positionierung)** — kurz, an die Werte des Gegenübers angepasst, Expertenstatus/„Daseinsberechtigung" zeigen. Beispiel-Pitch (Nils, Performance-Psychologie) wird geliefert und individuell angepasst.
4. **Agenda setzen** — zwei Varianten:
   - **A (klares Beratungsgespräch):** Frame setzen — „Ich verkaufe heute nichts. Wenn du am Ende mehr willst, machen wir einen 2. Call." Sehr wichtiger Part.
   - **B (Austauschgespräch):** Über Fokus-Fragen und 1–2 sichere Pain Points der Zielgruppe („investieren viel, ohne Erfolg" / „blockiert, schieben auf") Problembewusstsein aufbauen; mit Reverse Psychology nachfragen.
5. **Mehrwert geben** — zu EINER Herausforderung, nicht das ganze Business lösen; Aha-Momente erzeugen, hier darfst du mehr reden.
6. **Cliffhanger & Sales-Call setten** — drei Fragen: „Hat dir das geholfen?" (klares JA einholen, sonst mehr Mehrwert geben) → „Stell dir vor, wir arbeiten X Monate zusammen — wie wirkt sich das aus?" → „Kannst du dir grundsätzlich vorstellen, dass wir zusammenarbeiten, um Ziel XYZ zu erreichen?" Bei JA sofort Termin; bei NEIN mit Nebeltechnik/Einwandbehandlung nachfragen.
7. **Termin festlegen** — innerhalb 2–3 Tagen („Infos noch frisch"), Ablauf des Sales-Calls entspannt framen (Pain Island → Dream Island).
8. **Optional** — auf Content/Kundenstimmen verweisen, offene Fragen klären.

**Prinzip „Jeder Call zählt":** Nach jedem Call die Aussagen des Kunden in den Kundenavatar übertragen — bessere Zielgruppenkenntnis, besseres Marketing, positive Aufwärtsspirale. Verwandt: Der Pitch passiert Monate vorher — in Auftreten und geteiltem Content.

## 07 · Qualifizierung und Disqualifizierung

**Qualifizieren ohne plumpe Abfrage** (nicht „Wie viel Umsatz? Wie viel auf dem Konto?"). Da der erste Call über Zoom läuft, kann man spielerisch qualifizieren.

**Qualifizierungssignale (subtil erfragt):**
- Vollzeit vs. Nebenjob → Ernsthaftigkeit/Commitment (Beispiel: „nebenbei Unternehmensberater" → Macher, wahrscheinlich zahlungsfähig)
- Lifestyle-Aussagen und Reaktionen auf indirekte Fragen (z. B. über Standort/Mieten in Zürich) → Werte und finanzielle Lage, ohne Druck

**Disqualifizieren — wann:** Person nicht in der Zielgruppe, respektloses Verhalten (ständiges Unterbrechen, Umdrehen der Gesprächsdynamik), fehlende Mittel, oder du kannst mit deinem Angebot nicht wirklich helfen. Deine wichtigste Ressource ist Zeit: Zwei früh beendete Calls sparen z. B. 70 Minuten für Akquise oder Umsatzbringendes.

**Graceful beenden (Ehrlichkeit siegt):**
> „Wir arbeiten eigentlich nur mit Leuten in Situation X. Du bist gerade in Situation Y — da können wir dir leider nicht weiterhelfen. Ergibt das für dich Sinn?"

Bei respektlosem Umdrehen (jemand fängt an, DICH zu qualifizieren) darfst du das offen ansprechen und das Gespräch beenden. **Wichtigster Gedanke:** Du hilfst der Person am meisten, wenn sie Kunde wird — deshalb ist dein Angebot eine Kette gelöster Probleme (Pain Island → Dream Island in vielen Schritten), nicht ein 15-Minuten-Fix. Verwandtes Prinzip: Fokus als Leverage.

## 08 · Wichtige Tipps im Sales

Sales = **Menschen verstehen**, lesen, Bedürfnisse herausfinden, ein Gespräch bewusst steuern — die Person im Gespräch besser kennen, als sie sich selbst.

**Doubt and Check — Zweifle und überprüfe:** Potenzielle Kunden stellen sich besser dar, erfinden Ausreden, verschweigen Details. Aufgabe: durch gezieltes Nachfragen die echte Situation verstehen.

**Gewohnheiten statt Disziplin:** Erfolgreiche Menschen handeln aus Gewohnheiten, nicht aus ständiger Willenskraft. Wird Sales zur Routine, musst du dich nicht täglich neu motivieren.

**Klein anfangen & dranbleiben:** Nicht alles auf einmal ändern (häufigster Grund fürs Scheitern) — einen klaren Fokus als Routine etablieren. Kleine, konsequente Schritte schlagen kurzfristige Intensität.

## 09 · Deep Dive Salescall

Psychologie und Aufbau des Sales-Calls, das Herzstück des Verkaufsprozesses. Wiederholt das **Pain Island → Dream Island**-Modell: Der Kunde steht auf Pain Island (zu wenig Leads/Zeit, zu viel Körperfett etc.) oder sieht eine schönere Insel; dein **Angebot ist die Brücke** (Kanu, Steg, Privatjet — verschiedene Wege, die meisten wollen Komfort und zahlen dafür). Verkauf = die Lücke zwischen Ist und Wunsch schließen (gilt auch für Dating, Freundschaft, Bewerbungsgespräche).

**Warum nach System verkaufen (3 Gründe):**
1. **Skalierbar** — an Mitarbeiter weitergebbar (individuell geht nicht)
2. **Besser durch Wiederholung** — Iteration; Golf-Analogie: erst nach 100+ Schlägen spürst du den Unterschied zwischen den Schlägern
3. **Zahlen kennen** — Conversion-Kette (Leads → Discovery → Sales → Abschluss) erlaubt fundierte Investitionen

Ohne System: keine Klarheit, keine Sicherheit, kein ausgestrahltes Vertrauen. Das Skript ist wie eine **To-do-Liste / Malen nach Zahlen** — Schritt für Schritt abarbeiten, bei Abschweifen freundlich zurückholen. **Autofahren-Prinzip:** von bewusster zu unbewusster Kompetenz durch Wiederholung. Warnung: Strategien nicht vermischen (Kunde wechselte funktionierende Zwei-Call- gegen One-Call-Strategie → keine Abschlüsse mehr).

**Die drei häufigsten Einwände:**
1. „Nicht interessiert" → herausfinden, was dahintersteckt (Nutzen nicht verstanden / Preis / Zeit)
2. „Erst in 3 Monaten" → in Kontakt bleiben, echte Gründe verstehen
3. „Habe schon einen Anbieter" → differenzieren, spezifische Vorteile zeigen

## 10 · Skript Salescall

Das **vollständige Sales-Skript** (12 Schritte + Einwandbehandlung) plus Transkript. Grundprinzip aus dem Transkript: Echter Verkauf = **Vertrauen aufbauen** durch Authentizität, Kompetenz und Fokus auf die Interessen des anderen. Reihenfolge und Kernfragen unbedingt einhalten; nur Wording anpassen.

1. **Agenda setzen** — Ablauf ankündigen (Fragen → Ziel/Referenzrahmen → ggf. Lösung erklären → gemeinsam entscheiden), mit „Klingt nach einem Plan?" ein klares JA holen (Micro-Commitment). Tonalität am Frageende anheben, dann Ruhe. Lässt sich jemand nicht führen: disqualifizieren.
2. **Öffnen & erste Infos** — „Was hast du aus unserem letzten Call mitgenommen?" — Kunde reden lassen, Standing aufbauen.
3. **Bedarfsergründung** (4 Stufen): konkrete Engpass-Frage → Vertiefung („Was liegt dir noch auf dem Herzen?") → primäres Kaufmotiv identifizieren (Begriffe mit Interpretationsspielraum hinterfragen) → Auswirkungsfragen / **Pain Digging** („Was macht das mit dir?").
4. **Wunschzustand** — konkrete Ziel-Frage + Future Pacing mit Auswirkungsfragen.
5. **Selbstkontrolle lösen** — Ist- und Wunsch-Situation spiegeln (die Lücke kreieren), zur Selbsterkenntnis führen („Warum bist du noch nicht da?"), Dringlichkeit einholen („Warum jetzt und nicht in 3 Monaten?").
6. **Die perfekte Lösung** — Kunde beschreiben lassen, wie ideale Zusammenarbeit aussieht; Werte-Technik + Micro-Commitment.
7. **Bedarfserweckung mit offener Checkliste** (optional) — weitere Nutzenargumente andocken.
8. **Kaufbereitschaftstest / provisorischer Vorabschluss** — „Angenommen ich erfülle das alles — bist du dann an Bord?"
9. **Individuelle Angebotspräsentation** — Säulen vorstellen, das Wichtigste zuerst, nach jeder Säule Fragen klären.
10. **Kaufbereitschaftstest & Vorabschluss** — moralischer Vorvertrag → Reverse Psychology (Kunde verkauft sich selbst) → „Nicht mehr ob, sondern wie, korrekt?"
11. **Endgültiger Abschluss** — Investition nennen (Raten- vs. Einmalzahlung), „Welche Option ist für dich die beste?"
12. **After Sale** — **MUND HALTEN**, nur noch Daten aufnehmen (Name, Anschrift, Kontodaten), Onboarding-Termin.

**Einwandbehandlung:** Schalentechnik („Gibt es neben X noch einen Grund?"), Klarheitstechnik, Wertetechnik, Voraussetzungstechnik („Angenommen wir gewährleisten X — legen wir dann los?"). Verwandt: People buy from people.

## 11 · Skript an dich anpassen

Kurz-Video zur Anpassung. Das Skript ist **kein Wort-für-Wort-Manuskript, sondern ein Gerüst**.

- **Bleibt gleich:** Reihenfolge der Schritte, die psychologisch fundierten Fragen, die Übergänge.
- **Passt du an:** Wortwahl und Sprachstil (formell vs. locker je Zielgruppe), branchenspezifische Beispiele, eigene Geschichten/Anekdoten.

**Übungsmethoden:** mehrfach laut lesen und „drüber schlafen"; Passagen als Sprachmemo aufnehmen und die eigenen natürlichen Worte übernehmen; mit anderen Teilnehmenden im Rollenspiel üben; vor dem Spiegel trainieren. Ziel: klingt wie ein Gespräch, nicht wie ein Vortrag — so sicher, dass es „wie aus der Pistole geschossen" kommt.

## 12 · Verstehe deinen Kunden

Vertieft das **primäre Kaufmotiv**. Jeder Kauf hat einen tiefer liegenden Grund (Beispiel Brille: nicht das Aussehen, sondern „den Schmerz loswerden, wieder in die Ferne sehen"). Aufgabe im Sales-Call: dieses echte Motiv herausfinden und das Angebot daran ausrichten.

**Häufige primäre Kaufmotive:** Zeit, Individualität (persönliche Betreuung statt Fließband), Anerkennung, Fear of Missing Out, Schmerz loswerden.

**Wie erkennen:** Zuhören, was die Person immer wieder erwähnt; Worte mit Interpretationsspielraum hinterfragen; Wording im Gespräch zunehmend aufs erkannte Motiv anpassen — dadurch fühlt die Person sich gesehen und bekommt Bestätigung. Ein guter Verkäufer hört zu, statt 80 % zu reden. Kein Druck machen, wenn das Motiv nicht sofort klar ist.

**Scoping:** Verkaufe genau das, was der Kunde braucht — nicht das komplette Produkt. Vorteile: höhere Abschlusswahrscheinlichkeit, zufriedenere Kunden, schnellere Ergebnisse, bessere Basis für Folgeprojekte. Verwandt: Menschen kaufen Bedeutungen, nicht Produkte (Self-Reference Effect).

## 13 · Individuelle Angebotspräsentation

Warum die Präsentation individuell sein muss. **Sales = Menschen das geben, was sie *wollen*; deine Dienstleistung ist das, was sie *brauchen*** — beides muss sich treffen (Fitness-Beispiel: Kunde will Trainingsplan, braucht Ernährung → über den Trainingsplan „abholen", in der Zusammenarbeit erziehen; nie moralwidrig etwas völlig anderes verkaufen).

**Der Kernpunkt:** Bei gleicher Standard-Präsentation verlierst du eigentlich kaufbereite Leute, weil dein Angebot nicht wie „genau das Richtige" klingt. Deshalb vor der Präsentation fragen: „Wie sieht für dich die perfekte Zusammenarbeit aus, damit du zu 100 % dein Ziel erreichst?"

**In der Praxis:**
1. Herausfinden, was am wichtigsten ist (Zeit, Individualität, Ergebnis …)
2. Beim Vorstellen der Säulen zuerst das präsentieren, was dem Kunden am wichtigsten ist (das Erste wirkt am wertvollsten)
3. Die Sprache des Kunden verwenden (seine Worte aufgreifen — „Individualität", „gemeinsam aufbauen")
4. Fragen, was an früheren Zusammenarbeiten nicht gefiel → genau das besser machen (starkes Verkaufsargument)

**Wichtig:** Nur die *Vorstellung* ist individuell — das Angebot bleibt gleich. Ziel: „Das ist genau das, was ich brauche" statt „Das klingt gut."

## 14 · Menschen lügen

Wichtiges Mindset-/Technik-Video. **Menschen lügen** — nicht aus böser Absicht, sondern um Unangenehmem auszuweichen (kein Vertrauen, kein Geld, Ego). Deshalb: alle Aussagen zunächst anzweifeln — **Doubt and Check** — in Chat, Discovery- und Sales-Call.

**Häufige „Lügen":** „Ich habe das schon alles ausprobiert", „Ich habe kein Geld", „Ich habe keine Zeit", „Ich arbeite schon mit einem Coach".

**Ruhig bleiben, nicht destabilisieren lassen:** Wenn jemand sagt, er habe schon einen Kurs/Coach — cool bleiben und hinterfragen („Was genau hast du gemacht?"). Wäre es gut gewesen, hätte die Person Ergebnisse. 

**„Dann mach doch genauso weiter"-Technik:** Sagt jemand, er mache schon alles richtig, kurz zustimmen und ruhig-rhetorisch „Dann mach doch genauso weiter" — die meisten knicken ein, weil sie selbst wissen, dass es nicht funktioniert, und du kannst weiter qualifizieren.

**Bei Einwänden hinterfragen:** „Kein Geld" → „Was genau heißt kein Geld?" (Rücklagen aus vorherigem Job?); „Keine Zeit" → nachfragen. Ziel: ruhig bleiben, mehr Informationen gewinnen, weiter qualifizieren.

## 15 · Es darf langweilig sein

Mindset-Video: **Wiederholung als Weg zur Meisterschaft**. Aus dem Leistungssport (Jugend-Bundesliga Handball): dieselben Spielzüge tausende Male — genau das bringt zum Ziel. Gilt für Marketing (ähnliche Posts), Business und besonders Sales.

**Was „Langeweile" im Sales bedeutet (positiv):** Du kennst die Antwort, bevor du die Frage stellst (die Person schon gelesen); du fühlst dich in jedem Call sicher; du kannst das System weitergeben. Das Unbehagen bei Routine ist ein Zeichen von Fortschritt.

**Die Zahlen kennen:** Nach 100 Discovery- und 100 Sales-Calls kennst du deine Conversion Rate und kannst Investitionen planen („X Calls = Y Umsatz" → Agentur für 3.000 €/Monat rechnet sich über Return on Invest). Fazit: Routine ist kein Feind, sondern die Grundlage für skalierbaren Erfolg. Verwandt: schrittweise vorgehen — Meisterschaft entsteht durch Wiederholung.

## 16 · Menschen lieben es zu kaufen

**Lass den Kunden sich selbst verkaufen** — nicht überreden. Das Paradox: Je weniger du zu verkaufen versuchst, desto mehr verkaufst du.

**Drei Prinzipien:**
1. **Kompetenz zeigen, nicht behaupten** — nicht „Ich bin Experte" sagen, sondern durch wertvolle Inhalte beweisen (Show, don't tell)
2. **Vertrauen aufbauen, bevor du verkaufst** — über Zeit konsistenter, werthaltiger Content; Menschen kaufen von Menschen, denen sie vertrauen
3. **Die richtigen Menschen zur richtigen Zeit erreichen** — nicht alle sind jetzt kaufbereit; konstante Sichtbarkeit sorgt dafür, dass der richtige Content den richtigen Menschen im richtigen Moment trifft

Verwandt: Menschen kaufen Bedeutungen, nicht Produkte — auf LinkedIn gewinnt der Klare, nicht der Lauteste.

## 17 · Nächste Schritte

Abschluss- und Umsetzungs-Video. Sofort umsetzen:

1. **Discovery-Call-Skript anpassen** — alle Fragen einbauen, die du brauchst, um das Problem zu vergrößern und Lösungsbewusstsein zu wecken; im B2B zusätzlich alle Fragen, um ein gutes Angebot zu entwerfen; im B2C (z. B. Hochzeitsfotografie) die für deine Zielgruppe relevanten Fragen
2. **Sales-Call-Skript anpassen** — Wording und branchenspezifische Formulierungen; Struktur bleibt, Sprache wird deine
3. **Erste Calls einplanen** — konkretes 30-Tage-Ziel (z. B. 5 Discovery Calls)

**Geld-Mindset als Fundament:** Geld ist neutral — weder gut noch böse, es zählt, was du damit machst. Wer seinen Kunden wirklich hilft, verdient das Recht, dafür bezahlt zu werden. Geld ist dein Freund, nicht dein Feind. Verwandtes Prinzip: der nächste Schritt ist immer nur einer — nicht alle auf einmal.
