---
type: wissen
tags: [academy, sales, akquise, linkedin, kundengewinnung, personal-branding]
reiter: Reiter 3 – Sales, Marketing & Personal Branding
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 3 – Kundenakquise

Dieses Modul der [[Inner GOAT Academy]] zeigt, wie man über LinkedIn **systematisch und planbar** neue Kundenanfragen generiert und diese Kontakte Schritt für Schritt in Kunden verwandelt. Der rote Faden: Verkaufen ist kein Zufall, sondern ein **System** — von der Vernetzungsnachricht bis zur Überweisung. Kern ist eine **Zwei-Call-Strategie** (erst Mehrwert im Kennenlerngespräch, dann Verkauf) und ein durchgängiges Nachrichten-Framework: **Erstnachricht → Situationsfragen → Mehrwert → Pitch**.

Das Modul baut auf Modul 2 (Content + Nachrichten) auf und behandelt die zweite von drei Unternehmens-Säulen: **Angebot → Leadmaschine → Sales-Gespräche**. Leitprinzip ist [[Der Bruch als Bauplan|schrittweises Vorgehen]] und Konstanz statt Hoffnungsmarketing. Siehe auch [[Storytelling Wissen]] und [[Relevanz]] (Symptomebene statt Ursachenebene).

---

## 01 · Einführung

Auftakt und Landkarte des Moduls. Nachdem Modul 2 gezeigt hat, wie man über LinkedIn Leads generiert, geht es hier darum, die Calls und Gespräche zu führen und zum Abschluss zu bringen.

**Kernbotschaft:** Modul 2 und 3 sind **ein System**, kein getrennter Ablauf — alles baut aufeinander auf.

**Zwei-Call-Strategie:**
- **Call 1 — Kennenlerngespräch:** Kein Verkauf. Du gibst Mehrwert, löst ein kleines Problem, zeigst Kompetenz (**Show, Don't Tell**). Oft kommt die Person danach von selbst auf eine Zusammenarbeit zu sprechen.
- **Call 2 — Sales-/Beratungsgespräch:** Erst hier wird das Angebot vorgestellt.

Die im Modul gelieferten Anleitungen sind **keine starren Skripte zum Ablesen**, sondern psychologisch aufgebaute Prinzipien in einer Reihenfolge. Videos der Reihe nach schauen.

---

## 02 · Verkaufen durch System

Substanzielle Grundlagen-Lektion. Warum Verkaufen auf einem System basieren muss — statt auf Hoffnung.

**Die 3 Säulen jedes (Dienstleistungs-)Unternehmens:**
1. **Angebot** — löst ein konkretes Problem deiner Zielgruppe.
2. **Leadmaschine** — konstante, planbare Leadgenerierung (hier: über LinkedIn).
3. **Sales-Gespräche** — die Fähigkeit, Leads in Kunden zu verwandeln.

Ein gutes Angebot bringt nichts ohne Leads, und viele Leads bringen nichts, wenn man nicht verkaufen kann (Vertrauen, Preis).

**Kein Hoffnungsmarketing, kein Hoffnungsvertrieb:** Nicht einfach posten und hoffen, nicht planlos Nachrichten schreiben. Wir wollen **Planbarkeit, Sicherheit, Vertrauen** — das Gefühl, „ich drücke auf den Knopf, und X Kunden kommen rein". Prokrastination entsteht meist aus Unklarheit.

**Erfolg über zwei Hebel:** Content (Aufmerksamkeit + Vertrauen) und Nachrichten (aktiver Kontakt, ohne cringe/aufdringlich zu sein). Die wichtigste Fähigkeit als Selbstständiger: **den eigenen Kalender füllen**. Gerade am Anfang sind ~80 % der Zeit Marketing und Vertrieb.

**Die Zahlen hinter der Planbarkeit (konservativ gerechnet):**
- 50 Nachrichten → ~10 Chats → ~4 Kennenlern-Calls → ~1 Kunde (bei 25 % Abschluss).
- Skaliert: 100 Nachrichten → 20 Chats → 10 Beratungen → 4 Kunden usw.

**Reverse Engineering (Beispiel 200.000 € Jahresumsatz):**
- Angebot 4.000 € → 50 Kunden nötig.
- Bei 50 % Abschluss → 100 Sales Calls.
- Bei 1 von 4 → 400 Kennenlern-Calls.
- Bei 10 % Nachricht-zu-Call → ~4.000 Nachrichten/Jahr.
- Auf 300 Arbeitstage → **~13,3 Nachrichten/Tag** für 200.000 € (ohne Upsells, Verlängerungen, Customer Lifetime Value).

Merksatz: Wer nicht bereit ist, 13 Nachrichten am Tag zu schreiben, hat 200.000 € auch nicht verdient. [[Der Bruch als Bauplan|Fokus als Leverage]] — konsequente kleine Schritte schlagen 200 ungeplante Aktivitäten.

---

## 03 · Phasen der Akquise

Verortung im System und die Psychologie des Vertrauens.

**Die Basis vom Verkaufen ist Vertrauen.** Vergleich Markenvertrauen (Mercedes, McDonald's, Starbucks): Vertrautheit entsteht durch viele Kontaktpunkte. Ähnlich wie beim Dating — nach mehreren „Blickkontakten" spricht man mit ganz anderem Selbstvertrauen an.

**Kontaktpunkte / Thermostat (kalt → warm):**
- 0 Kontaktpunkte = kalt (direkter Pitch in der ersten Nachricht funktioniert nicht mehr).
- 1–3 indirekte Kontaktpunkte (Posts gelesen) → wärmer.
- ~7 Kontaktpunkte → Call möglich, Vertrauen vorhanden.

Typischer Verlauf: Willkommensnachricht → Profilbesuch → Likes & Comments → Nachrichten → Discovery Call → Verkauf. Es geht aber auch verdichtet (Willkommensnachricht + 3–5 Nachrichten → direkt Verkaufscall). Gilt analog für Instagram, TikTok, Netzwerk und Cold Calling.

**Die 4 Phasen (Vogelperspektive):**
1. **Erstnachricht**
2. **Situationsfragen** (2–4) — Fragen, durch die wir mehr über die aktuelle Situation des Prospekts erfahren, um mit unserem Angebot zu helfen.
3. **Mehrwert** im Chat
4. **Pitch** auf den Termin

Alles **Schritt für Schritt** — nicht in der ersten Nachricht pitchen, nicht im Chat verkaufen, nicht im Quali-Call verkaufen. Wirkhebel: [[Relevanz|Social Proof, Autorität, Gleichheit]].

---

## 04 · Erstnachrichten

Ausführliche Praxis-Lektion mit vielen echten Chat-Beispielen.

**Was wir NICHT tun:**
- Kein Angebot im Chat pitchen, nicht im Chat verkaufen, nicht mit der Tür ins Haus fallen (funktioniert auf LinkedIn nicht mehr).
- Keine ewig zu beantwortenden Fragen („Was ist deine tiefere Motivation?").
- Keine Fragen, die nicht zum Ziel führen.

**Leitprinzip:** *Verschicke keine Nachrichten, die du selbst nicht bekommen wollen würdest.* Wer gegen die eigenen Werte handelt, sabotiert sich selbst. (Ausnahme: bewusste Wachstumszone.)

**Die 7 Szenarien für Erstnachrichten:**
1. Vernetzungsanfrage erhalten
2. Like unter einem Beitrag
3. Kommentar unter einem Beitrag (eigenem oder fremdem)
4. Häufiger Profilbesucher
5. Kalter Kontakt, der schon im Netzwerk ist
6. Du versendest selbst eine Vernetzungsanfrage
7. Aufhänger wie Event (z. B. Zielgruppe nimmt bei Zielgruppen-Besitzpartner/Konkurrenz teil)

**Psychologie (People Buy From People):** Die meisten wollen sofort etwas *nehmen*. Wir **geben zuerst** — ein Kompliment, echtes Interesse, Aufmerksamkeit (Profil, Beiträge, Website, Testimonials als Aufhänger). Das erhöht die Antwortwahrscheinlichkeit und bringt uns direkt in den Chat, wo wir die Situationsfrage vorbereiten.

**Wichtige Fakten:** ~99 % der LinkedIn-Nutzer sind stille Mitleser — diese erreicht man nur durch aktives Anschreiben. Ziel der Erstnachricht ist **nicht** verkaufen und **nicht** Bedarf checken, sondern **eine Antwort bekommen** und Kontakt herstellen. Mix aus Inbound und Outbound; Inbound steigt mit Vertrauen und guten Posts. Im Vertrieb wollen wir die **Kontrolle übernehmen** — also selbst zuerst schreiben statt nur annehmen.

Beispielhafte Formulierung: „Hey [Name], vielen Dank für deine Anfrage, was verschafft mir die Ehre? Liebe Grüße nach [Stadt]." Eine solche Rückfrage liefert oft eine perfekte Vorlage für die nächste Situationsfrage.

---

## 05 · Weiterführende Nachrichten

Überleitung von den Erstnachrichten zum Termin. Vorwiegend Video-Einordnung; das Begleitdokument fasst die Grundprinzipien.

**Ziel:** einen Termin vereinbaren (Kennenlern- oder Sales-Call).

**Die 4 Phasen im Chat (Wiederholung):** Erstnachricht → Situationsfragen (2–4) → Mehrwert → Pitch.

**Grundprinzipien:**
- Nie in der ersten oder zweiten Nachricht pitchen.
- Keine ewig zu beantwortenden Fragen.
- Immer Bezug zur Antwort der Person nehmen (echter Austausch, kein Verhör).
- Im System bleiben — jeder Schritt hat seinen Platz.

Häufiges Problem: Man connectet und schreibt, findet aber nicht die Kurve zum eigenen Thema. Die folgenden Lektionen (Pitch, Bedarfserweckung, Loom) liefern die konkreten Werkzeuge dafür. Jede weiterführende Nachricht ist ein Kontaktpunkt, der Vertrauen aufbaut.

---

## 06 · Pitch

Kurze, klare Praxis-Lektion mit Beispielen. Ziel der Pitch-Nachricht: **einen Call terminieren** (Discovery-/Kennenlern-Call).

**Aufbau der Pitch-Nachricht:**
1. Kurzer **Mehrwert** (1–2 Sätze) als Überleitung.
2. **Vorschlag:** „Wenn du magst, können wir gerne mal dazu zoomen."
3. **Zwei Zeitoptionen:** einmal vormittags, einmal nachmittags an zwei verschiedenen Tagen — vermeidet Hin-und-Her und Terminkonflikte.
4. **Bestätigung vorwegnehmen:** „Freue mich drauf" — setzt den Termin psychologisch als bereits vereinbart.

**Optional bei Kaltkontakten / Business-Anfang:** Einwand direkt wegnehmen — „Keine Sorge, ist kein Verkaufsgespräch, rein ein Mehrwertcall."

**Ton:** locker und menschlich (wie man auch privat schreibt), aber professionell.

**Firmen/mehrere Entscheider:** Calendly-Link oder Telefonnummer kann sinnvoll sein. Für Einzelkontakte eher individuell terminieren (Calendly nervt durch zusätzliche Klicks). Ein guter Pitch fühlt sich nicht wie ein Pitch an — er ist die logische Fortsetzung des aufgebauten Vertrauens.

---

## 07 · Bedarfserweckung im Chat

Werkzeug für Chats, die stocken oder leere Antworten liefern („danke für die Blumen") und wo kein offensichtlicher Aufhänger für Situationsfragen da ist.

**Voraussetzung:** Zielgruppe gut kennen und **spezifische, wahrscheinliche Probleme** targetieren.

**Aufbau der Nachricht (3 Ebenen):**
1. **Einstieg** — Bezug zu einer Gruppe: „Viele Unternehmer, mit denen ich spreche …", „Viele meiner Kunden …", „Ich erkenne immer wieder …".
2. **Problem targetieren** — ein spezifisches, wahrscheinliches Problem der Zielgruppe.
3. **Geschlossene Frage** — „Geht dir das ähnlich?", „Hast du dich damit schon mal befasst?", „Kommt das bei dir auch vor?"

**Beispiele:**
- Für LinkedIn-Dienstleister: „Viele Unternehmer, mit denen ich spreche, wollen sich auf ihr Kerngeschäft fokussieren und haben keine Lust, selbst LinkedIn-Beiträge zu schreiben. Geht dir das ähnlich?"
- Für Finanzberater (GmbH-Inhaber): „Viele meiner Kunden mit einer GmbH wollen ihre Mitarbeiter langfristig halten, haben sich aber noch nicht damit befasst, wie man bei gleichem Bruttogehalt bis zu X € mehr netto erwirtschaftet. Hast du dich damit schon mal auseinandergesetzt?"
- Reverse Psychology (Webdesigner/Copywriter): eine gute Website loben und unterstellen, dass sie „mit Sicherheit planbar Anfragen bringt" — und schauen, ob sich die Person öffnet.

**Wichtig:** Am effektivsten nach **3–4 vorherigen Nachrichten**, wenn schon etwas Vertrauen besteht. Prinzip: [[Relevanz|Menschen kaufen Bedeutungen]] — Bedarfserweckung macht einen vorher unsichtbaren Schmerz sichtbar.

---

## 08 · Loom Strategie

Akquise mit personalisierten Videos (Loom = kostenlose Screen-Recording-Software, bis 5 Min. gratis).

**Für wen geeignet:** alle, deren Arbeit man direkt sehen kann — Webdesigner, Copywriter, Branding-Experten, Social-Media-Agenturen, Performance-Ads-Spezialisten (**offensichtliches Bedürfnis**). Weniger geeignet für nicht-offensichtliche Bedürfnisse (Mindset, Fitness, Finanz-/Versicherungsberatung), weil man den Status nicht sehen/ansprechen kann.

**Ablauf-Varianten (je tiefer der Einstieg, desto weniger Vertrauen und niedrigere Antwortrate):**
- Standard: Erstnachricht → Situationsfrage → Loom-Video (Mehrwert + Pitch).
- Verkürzt: Erstnachricht → Loom-Video.
- Direkt: nur Loom-Video nach Vernetzung.

**Aufbau des Videos (max. ~3 Min.):**
1. **Einstieg** — „Bevor ich dir eine ewig lange Nachricht schicke, zeig ich dir kurz, was mir aufgefallen ist." Bei Kaltkontakt Einwand wegnehmen: „Du denkst jetzt vermutlich, der nächste Copywriter/Webdesigner, der was verkaufen will — keine Sorge, mir ist nur folgende Sache aufgefallen …".
2. **Mehrwert** — konkrete Auffälligkeiten auf Website/Post/Funnel/Ads zeigen; Problembewusstsein erzeugen (was funktioniert nicht, warum ist das wichtig, welche Konsequenz).
3. **Pitch** — „Mir sind noch weitere Punkte aufgefallen. Lass uns die Tage mal zoomen, dann gebe ich dir detaillierteres Feedback."

**Mindset beim Aufnehmen:**
- **Expertenstatus** ausstrahlen, ruhig/direkt/klar artikulieren, nicht stark emotional.
- Innere Haltung: **„Ich will dich, aber ich brauche dich nicht."** — nicht bedürftig, aber auch nicht alles schlechtreden. Gutes Mittelmaß.
- **Overdeliver** im Mehrwertteil (nicht zurückhalten aus Angst, „zu viel zu geben") — aber kein 30-Min.-Komplettkonzept.

**Empfehlung:** Erst 5 Übungsvideos aufnehmen (Tonalität/Vertrauenswürdigkeit prüfen), bevor man live geht. Prinzip: [[Relevanz|Wahrnehmung schlägt Wahrheit]] — das Video prägt das Expertenbild, bevor man sich persönlich kennt. Tool: [loom.com](http://loom.com).

---

## 09 · Follow-Up

Wie man am Ball bleibt, wenn keine Antwort kommt. Bewusst **simpel** gehalten.

**Wann Follow-Up:**
- Keine Antwort auf eine Nachricht (nach ~2–3 Tagen).
- Nach einem Kennenlerngespräch (3–6 Monate später).
- Nach einem Sales Call ohne sofortige Entscheidung.

**Formulierung:**
- „Hey, kleiner Reminder — freue mich auf eine nette Antwort von dir."
- „Hey, ist mit Sicherheit viel los bei dir — ich freue mich über eine Antwort."

**Nach einem gemeinsamen Gespräch:** Person ins System (CRM/Trello) legen mit Follow-Up-Datum. In 3–6 Monaten mit einem Aufhänger aus dem letzten Gespräch wieder anschreiben („Du hattest erwähnt, dass X eine Herausforderung ist — wie läuft das gerade?").

**Wichtig:** LinkedIn ist auch ein **Zahlenspiel**. Nicht jede Person antwortet — das hat nichts mit dir als Person zu tun. Ein Follow-Up ist kein Druck, sondern der nächste kleine Schritt im Vertrauensaufbau.

---

## 10 · Tracking Sheet

Video-Lektion (Transkript folgt); im Kern ein Vorlagen-/Tool-Video. Kernaussage: **Was du nicht misst, kannst du nicht verbessern.**

**Was getrackt wird:**
- Anzahl versendeter Erstnachrichten
- Anzahl erhaltener Antworten (Antwortrate)
- Anzahl vereinbarter Kennenlerngespräche
- Anzahl Sales Calls / Beratungsgespräche
- Anzahl gewonnener Kunden

**Warum tracken:** Erkennen, welche Nachrichten funktionieren; Engpässe im System identifizieren (z. B. viele Chats, aber wenige Calls); **Planbarkeit** herstellen (wie viele Nachrichten pro Kunde). Das Template wird im Video gezeigt und steht als Vorlage bereit.

---

## 11 · Akquise kann hart sein

Mindset-Lektion. Ehrliche Ansage: **Akquise kann hart sein** — besonders die ersten 30–40 Chats. Ablehnung, Nicht-Antworten und ins Leere laufende Nachrichten sind normal.

**Kernerkenntnisse:**
- Die ersten 30–40 Chats sind die härteste Phase — aber die **Lernkurve ist hier am steilsten** (Zielgruppe einstellen, Nachrichten testen, mit LinkedIn warm werden).
- Ab Nachricht ~40–50 beginnt der Hebel zu greifen; wer durchhält, findet sein funktionierendes Muster.
- Der **Punkt des maximalen Widerstandes** („Komm, das bringt doch nichts") ist kein Signal zum Aufhören, sondern der Wendepunkt — genau hier entscheidet sich, wer Ergebnisse bekommt.
- Ablehnung ist kein persönliches Versagen.
- **Konstanz und Disziplin** — nicht Talent oder Glück — unterscheiden erfolgreiche von nicht-erfolgreichen Unternehmern.

Analogien: Schuhe binden, Surfen lernen — anfangs schwer und frustrierend, später selbstverständlich. Persönliche Anekdote: tagelang gegrübelt, welche Nachricht funktioniert — dann plötzlich 8 Kennenlerngespräche in einer Woche. Merkformel: **Je mehr du dich damit befasst, desto schneller kommen die Resultate.** Passt zu [[Der Bruch als Bauplan]]: der Widerstand als Durchgangspunkt, nicht als Endstation.

---

## 12 · LinkedIn Routine

Wie man den ganzen Prozess in eine tägliche Routine gießt — sonst verliert man sich im Scrollen. Empfehlung: LinkedIn morgens als **erste Tätigkeit**.

**Die 4 täglichen Kernaktionen (~30–90 Min., morgens):**
1. **Offene Nachrichten beantworten** — höchste Priorität (Termine legen, Bestätigungen einholen).
2. **~5 qualitative Kommentare** bei Creators/Unternehmen der Zielgruppe — kein „Starker Beitrag!", sondern echter Mehrwert, damit andere aufmerksam werden und aufs Profil kommen.
3. **10–20 Vernetzungen** pro Tag — Netzwerk kontinuierlich ausbauen.
4. **5–20 Erstnachrichten** schreiben — **der wichtigste Punkt**. Nicht bloß posten und hoffen.

**Wochentaktik (Posts):** Samstagvormittag 2–3 Stunden blocken, 3–4 Beiträge schreiben und vorplanen. Empfehlung: **Mo/Mi/Fr, ~7:30–9:00 Uhr** (LinkedIn erlaubt Vorplanung).

**Nachmittags:** 30-Minuten-Blocker für Rückmeldungen auf die Erstnachrichten vom Morgen.

**Tipp:** Solange der Kalender nicht voll mit Kennenlerngesprächen ist, mehr Zeit auf LinkedIn in Akquise investieren. Wer morgens keine Zeit hat, kann die Routine auch abends fahren. [[Der Bruch als Bauplan|Schrittweise, einfache tägliche Schritte.]]

---

## 13 · Postings

Umfangreiche Content-Lektion mit klaren Learnings (bewusst pragmatisch: Copywriting ist wichtig, aber nicht der größte Hebel zur Kundengewinnung).

**Ziele von Postings:**
- Vertrauen und Expertenwahrnehmung aufbauen.
- Inbound-Anfragen generieren.
- Outbound-Nachrichten via Kommentare/Likes vorbereiten (Reichweite ist nützlich — aber nicht durch Hate/unmoralische Posts erkaufen).
- **Problembewusstsein triggern:** den Prospekt aus „alles ist super" herausholen, indem man Probleme/Wünsche sichtbar macht, die er selbst noch nicht auf dem Schirm hat (Blindspot). Ziel: Person kommt in Bewegung.

**Die wichtigsten Learnings:**
1. **Ein 5-Jähriger muss es verstehen** — keine Fachbegriffe (MSCI World, kognitive Dissonanz, Programmier-Details). Komplexität runterbrechen.
2. **Symptomebene statt Ursachenebene** — nicht „Wie Glaubenssätze entstehen", sondern die realen Gedanken/Emotionen/Verhaltensweisen der Zielgruppe: „Woher kommt mein nächster Kunde?", „Ich will mit Akquise niemandem auf die Nerven gehen." Ein Arzt denkt nicht „Wie komme ich an Kunden?", sondern „Ich arbeite 10 Std./Tag, keine Zeit für meine Kinder." → Symptomebene je Zielgruppe herausfinden. Siehe [[Relevanz]].
3. **Kundenavatar ist die beste Ideenquelle** — Was hast du zuletzt mit einem Kunden besprochen? Was war sein Denkfehler? Was hat er danach besser gemacht? Ideen sofort aufschreiben (Trello/Notion).
4. **Nutze beide Gehirnsysteme** — 20 Min. intensiv über Zielgruppe/Problem nachdenken, dann Sport/Spaziergang. Das Unterbewusstsein arbeitet weiter; die besten Impulse kommen unterwegs.
5. **So viel wie nötig, so wenig wie möglich** — keine langen Absätze; alles streichen, was die Kernaussage nicht stützt (Füllwörter, Unverständliches, Interpretationsspielraum).
6. **Done is better than perfect** — niemand erinnert sich in 10 Minuten an deinen Post. Raushauen, aus dem Feedback lernen, iterieren („Ergebnis → Erkenntnis → Anpassung"). Perfektionsdruck rausnehmen.

**Formate:** Text mit Bild (empfohlen; kein 2.500-€-Shooting nötig, iPhone reicht am Anfang), Video (starkes Vertrauen/Mehrwert), Karussell (via Canva). Am Anfang das Format wählen, das am leichtesten fällt. Hooks (die ersten zwei Zeilen) entscheiden — Pattern Interrupt. Siehe [[Storytelling Wissen]] und [[Die 12 Plots]].

---

## 14 · Nachrichten Framework — Kundengewinnung

Konkretes Framework für **Finanzberater im B2C-Bereich** (Zielgruppe: Führungskräfte, Ingenieure, IT, Young Professionals — keine Unternehmer). Herausforderung: Diese Leute posten kaum, es fehlt der inhaltliche Aufhänger. Lösung: **Bezug auf die Berufserfahrung** nehmen. Im Optimalfall ist die Zielgruppe der eigene (frühere) Beruf.

**Das Framework (4 Schritte):**

**Schritt 1 — Erstnachricht (nach Vernetzungsannahme):** „Hey [Name], bin gerade auf dein Profil gestoßen und habe gesehen, du bist schon länger im Bereich [X] tätig. Was hat bei dir das Interesse an der Branche geweckt? Liebe Grüße nach [Stadt]." Ziel: lockere Interessensfrage, die fast jeder beantwortet.

**Schritt 2 — Situationsfragen (je nach Antwort):**
- *Best Case* (Person stellt Rückfrage): Bezug + Kompliment → kurz erklären, warum du in die Finanzbranche gewechselt bist → Situationsfrage („Beschäftigst du dich privat auch mit Finanzen/Rente/Immobilien?").
- *Neutral Case* (keine Rückfrage): gleiches Vorgehen, mit Feingefühl echten Austausch herstellen (nicht Situationsfrage „raushauen").
- *Hat schon Berater:* Reverse Psychology — „Gut, dass du dich beraten lässt. War das ein unabhängiger Makler, der dir mehrere Angebote vorgelegt hat, sodass du die besten Konditionen wählen konntest?" (Ziel: Bedarf/Zweifel kreieren.)

**Schritt 3 — Mehrwert:** Problem aufdecken und Neugier wecken. Beispiel: Halbeinkünfteverfahren erklären (50 % der Gewinne steuerfrei, kann fünfstellige Beträge ausmachen) — geht auch als Privatperson, was die meisten nicht wissen.

**Schritt 4 — Pitch:** Kennenlerngespräch anbieten, ohne Druck: „Kein Verkaufsgespräch — reiner Mehrwert, dein Zeitinvest wird gering sein."

Die Lektion zeigt einen **kompletten echten Chat-Verlauf** (Alexander / IT-Consultant), inkl. Reminder nach Nicht-Antwort, bis zum vereinbarten Termin. **Wichtig:** nicht 1:1 kopieren, mit eigenem Wording anpassen, immer Follow-ups schicken.

---

## 15 · Nachrichten Framework — Partnergewinnung

Framework für **Finanzberater zur Partnergewinnung (Branchenkenner)** — Zielgruppe: Menschen in Bank/Versicherung, deren Wechsel-/Selbstständigkeitsbereitschaft man aufdecken will. Gleiche Grundstruktur (Erstnachricht → Situationsfragen → Mehrwert → Pitch). Optimal, aber nicht zwingend: du kommst selbst aus Bank/Versicherung.

**Das Framework:**

**Schritt 1 — Erstnachricht (nach Vernetzungsannahme):** „Hey [Name], bin gerade auf dein Profil gestoßen. Du bist seit x Jahren bei [Bank/Versicherung] im Bereich [X] tätig. Was hat bei dir das Interesse an der Branche geweckt?" Bei eigenem Anknüpfungspunkt erwähnen. Alternativ auf den Werdegang eingehen („Wie kam es, dass du nach dem dualen Studium in der Bank weitergemacht hast — gutes Angebot bekommen oder gar nicht umgeschaut?").

**Schritt 2 — Situationsfragen zur Zufriedenheit:**
- War der Job von Anfang an dein Plan, oder bist du reingerutscht?
- Hast du dir vorher auch andere Möglichkeiten angeschaut / schaust du dich manchmal nach Alternativen um?
- Hast du schon mal mit dem Gedanken gespielt, dich selbständig zu machen?
- (direkter) Bist du gerade auf einer 12 von 10 zufrieden — oder gibt es Dinge, die du dir anders wünschen würdest?

**Schritt 3 — Bedarf herausfinden:** Bei Interesse vertiefen und schnell zum Pitch. Bei keinem Interesse: **Follow-Up** (in 3–6 Monaten erneut melden).

**Schritt 4 — Pitch:** nur bei Bedarf — lockeres Kennenlerngespräch, ohne Druck.

**Wichtig:** Nicht jeder ist für den Vertrieb / die Selbstständigkeit gemacht — Qualifizierung spart Zeit. Diese Lektion ist der „soft"-Weg; Lektion 16 zeigt den direkten Weg.

---

## 16 · Nachrichten Framework — Partnergewinnung Direct Approach

Alternatives, direkteres Framework für Partnergewinnung (Branchenkenner). **Abweichung vom Standard-Modell:** keine Situationsfragen — nur **Mehrwert + Pitch**, direkt nach der Vernetzungsannahme. Ziel: **hohe Quantität** (ggf. automatisierbar, aber am Anfang händisch testen; LinkedIn sieht Automatisierung ungern).

**Pitch-Variante 1 (Einkommens-Fokus):** „Hey [Name], wir haben gerade in [Stadt] unser neues Office eröffnet und bauen unser Team aus. Wir wollen Leute, die gut mit Menschen können und unabhängig das Beste für ihre Kunden rausholen wollen. Das durchschnittliche Einkommen eines selbstständigen, unabhängigen Maklers liegt bei rund [hohe Summe, z. B. 8.000 €+]/Monat — ohne ekelige Kaltakquise. Ich kann mir vorstellen, dass du mit deiner Erfahrung gut ins Team passt und die Summe schnell übertriffst. Lass mich kurz wissen, ob das für dich interessant ist."

**Pitch-Variante 2 (Pain-Point-Fokus):** Drei typische Schmerzen der Zielgruppe adressieren — (1) keine individuelle Beratung möglich, Kunde nicht im Fokus; (2) eingeschränktes Produktportfolio; (3) Abhängigkeit vom Vorgesetzten bei Beförderung — kontrastiert mit den Vorteilen der Selbständigkeit (echter Mehrwert für den Kunden, Kunden gehören dem Berater, ~90 % der Provisionen). Abschluss: offene Frage nach Grundinteresse. Bei anderer Zielgruppe (z. B. Bank statt Versicherung) Symptomatiken/Vorteile anpassen.

**Bei Ablehnung:** nachfragen, was den aktuellen Job so gut macht, dann Bedarfs-Erweckungsfrage: „Alles klar — das Thema [9.000 €]/Monat ist für dich gerade dann nicht interessant?" bzw. konkrete Aussagen hinterfragen („Was genau meinst du damit, dass die Verdienstmöglichkeiten besser sein könnten?").

**Wichtig:** Nachrichten sind grobe Vorgaben mit psychologischem Aufbau — mit eigenem Wording anpassen, vor Versand Feedback einholen. Prinzip: **Wissen ist Potenzial, Umsetzung ist Momentum** — Fortschritt entsteht durch Iteration.

---

## 17 · Nächste Schritte

Abschluss-Lektion (Transkript folgt). Kernbotschaft: Nach Modul 3 sind alle Werkzeuge für systematische LinkedIn-Akquise da — **jetzt zählt konsequente Umsetzung**.

**Nächste Schritte:**
- **LinkedIn-Routine etablieren** — täglich die 4 Kernaktionen (Nachrichten beantworten, Kommentare, Vernetzungen, Erstnachrichten), morgens 30–90 Min.
- **Framework wählen und starten** — Kundengewinnung (B2C), Partnergewinnung Branchenkenner oder Direct Approach. Für einen Einstieg entscheiden und sofort starten.
- **Erste 30–40 Chats durchziehen** — die härteste, aber lernintensivste Phase. Dranbleiben.
- **Postings regelmäßig veröffentlichen** — Mo/Mi/Fr, auf Symptomebene der Zielgruppe.
- **Community nutzen** — Chat-Verläufe teilen, Feedback einholen, Vorlagen optimieren.
- **In Modul 4 weitermachen** — baut auf diesem Modul auf.

Merksatz: **Du brauchst kein perfektes Setup. Du brauchst Umsetzung.** ([[Der Bruch als Bauplan|Think smaller, not bigger.]])
