---
type: wissen
tags: [academy, sales, einwandbehandlung, vertrauensaufbau, closing, salestraining]
reiter: Reiter 3 – Sales, Marketing & Personal Branding
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 5 – Salestraining

Das Salestraining ist das Herzstück des Verkaufs-Wissens der [[Inner GOAT Academy]]. Es dreht sich um einen einzigen roten Faden: **Sales ist Vertrauensaufbau.** Jeder Einwand ist kein Angriff, sondern ein Hinweis darauf, wo einer Person noch Vertrauen fehlt — in dich als Anbieter, in dein Angebot/den Prozess oder in sich selbst.

Das Modul baut in drei Schichten auf:
1. **Fundament & Diagnose** (Lektion 1–4): Salesdreieck, Einwände als Normalzustand, Verkaufszone, das Grundprinzip Vertrauen.
2. **Das Einwände-Framework** (Lektion 5–15): Ein universelles 7-Schritte-Framework zum Glaubenssätze-Drehen plus durchdeklinierte Antworten auf die häufigsten konkreten Einwände (Kein Geld, Nacht drüber schlafen, Partner, Entscheidung, Coach, später starten, Zeit, schlechte Erfahrungen, Garantie).
3. **Prinzipien & Handwerk** (Lektion 16–26): Skript anpassen, im gleichen Boot sitzen, Sicherheit ausstrahlen, Skalafragen, Kontrolle halten, Probleme adressieren, die 7 Bedingungen für einen Close, Verkaufsregeln (nie Angebot verschicken, immer Folgetermin) und die Umsetzung.

Verwandte Wissensbasis: [[Storytelling Wissen]]. Da Sales hier durchgängig auf Bedeutung, Vertrauen und die richtige innere Haltung setzt, verzahnt sich das Modul eng mit Storytelling-Konzepten wie [[Relevanz]] (der Schmerz muss real und bewusst sein) und der Idee, Menschen dort abzuholen, wo sie im eigenen Wandel stehen ([[Der Bruch als Bauplan]]).

---

## 01 · Einführung & das Salesdreieck

Das zentrale Diagnose-Modell des Moduls. Ein Abschluss kommt nur zustande, wenn **drei Säulen des Vertrauens** erfüllt sind:

1. **Vertrauen in die Person** — der Prospekt muss dir als Mensch vertrauen (integer, kompetent, hilfreich).
2. **Vertrauen in das Angebot** — die Person muss glauben, dass Programm/Dienstleistung/Produkt ihr Problem wirklich löst.
3. **Vertrauen in sich selbst** — die am häufigsten unterschätzte Säule. Die Person muss glauben, dass *sie* die Ergebnisse erreichen kann.

**Merksatz:** Wenn kein Abschluss zustande kommt, fehlt Vertrauen in einer dieser drei Säulen. Deine Aufgabe ist Diagnose: herausfinden, welche Säule noch nicht voll ist — und gezielt daran arbeiten. Das nimmt Druck raus: Einwände sind nicht bedrohlich, sondern ein Hinweis.

**Diagnose-Tabelle:**
| Säule | Typische Aussage | Deine Reaktion |
|---|---|---|
| Person | "Ich kenne dich noch nicht gut genug…" | Social Proof, Referenzen, mehr Touchpoints |
| Angebot | "Ich weiß nicht, ob das funktioniert…" | Case Studies, Kundenergebnisse, Mechanismus erklären |
| Sich selbst | "Ich glaube schon, aber ob ich das schaffe…" | Ähnliche Erfolgsgeschichten, Hindernisse gemeinsam analysieren |

Alles wird mit Übung besser — in Gespräche mit Neugier statt Druck gehen.

---

## 02 · Einwände werden kommen

Mentale Vorbereitung. Einwände kommen so sicher wie Zähneputzen vor dem Schlafen oder Duschen nach dem Sport — sie sind der Normalfall, nichts Schlechtes.

**Das Boxer-Mindset:** Ein Boxer steht nie mit parallelen Beinen — sonst wirft ihn schon ein kleiner Stups um. Genauso gehst du in Gespräche: gewappnet und offen für alles. Es kann alles passieren (Tränen, Testfragen, Beleidigungen, Herzensgeschichten, plötzliche weitere Entscheider, Lügen). Nichts bringt dich aus der Fassung, weil du nicht auf einen perfekten Ablauf fixiert bist.

**Merksatz:** Kaum ein Salesprozess läuft perfekt — das ist kein Problem, sondern der Normalfall. Deine Stärke ist, mit allem ruhig umzugehen. (Deshalb macht man auch Marketing: um vorab Vertrauen aufzubauen.)

---

## 03 · Die Verkaufszone

Eines der relevantesten Prinzipien. Ein Prospekt kauft nur in der **optimalen Verkaufszone** (Mitte eines Schiebereglers). Deine Aufgabe: einschätzen, wo die Person steht, und sie in die Mitte bringen.

- **⬅️ Zu schwer (links):** "Wie soll das bei mir klappen?", "Hatte schon schlechte Erfahrungen", "Ich weiß nicht, ob ich das umsetze". → **Leichter machen:** Sicherheit geben. *"Ich bin ehrlich, das haben schon ganz andere geschafft, die noch weniger Vorwissen und eine deutlich schlechtere Ausgangssituation hatten. Das wird gar kein Problem. Vertraue mir."*
- **✅ Verkaufszone (Mitte):** neugierig, offen, sieht Wert, hat Vertrauen → halten und Abschluss führen.
- **➡️ Zu einfach (rechts):** "Das bekomme ich auch alleine hin", "Dafür brauche ich keinen Coach", "Gibt's auf YouTube". → **Schwerer machen:** Detailfragen stellen, die die Person nicht beantworten kann (Wissenslücken aufdecken). Beispiel Finanzberater: *"Zahlst du die vollen 25% Kapitalertragssteuer oder nutzt du die Halbeinkünftebesteuerung mit 13%?"*

**Skalafragen mit bewusster Übertreibung:** *"Mit deinen Ergebnissen bist du auf einer absoluten 12 von 10, dass du das nie wieder als Problem hast?"* → Person sagt 8–9 → "Was fehlt bis zur 10?" → diese Lücke dramatisieren, um die Person kaufbereiter zu machen.

**Merksatz:** Lass die Verkaufszone in jedem Call mitlaufen (Discovery, Sales, Follow-up, Partnergewinnung). Verzahnt mit [[Relevanz]]: Der Schmerz muss spürbar sein, damit Handlungsdruck entsteht.

---

## 04 · Das wichtigste Grundprinzip

Reframing der Einwandbehandlung: Das Wort selbst ist irreführend ("ich gegen dich"). Richtig ist: **Einwandbehandlung = Vertrauensaufbau.** Es geht nie in einen Konflikt.

Es gibt nur **drei (+1) Gründe**, warum eine Person nicht kauft (echte Zahlungsunfähigkeit ausgenommen):
1. **Kein Vertrauen in den Prozess/das Angebot** — nicht überzeugt, dass es zum Ziel führt.
2. **Kein Vertrauen in dich als Anbieter** — Skepsis, "der nächste Verkäufer/Scammer", schlechte Erfahrungen.
3. **Kein Vertrauen in sich selbst** — häufig bei Leuten, die frisch im Business sind oder noch keine Erfolge haben.
4. *(B2B-Zusatz)* **Kein Vertrauen in die Firma** — relevant bei Vertrieb/Teamaufbau, hier ausgeklammert.

Vertrauen kann mehrstufig verteilt sein. Ziel: alle drei Säulen auf 10/10 maximieren.

**Dein Vorgehen:** 1. Identifiziere (durch Fragen, nicht Annahmen), 2. Isoliere ("Das heißt, dir fehlt gerade das Vertrauen, dass…"), 3. Bau gezielt Vertrauen auf, 4. Prüfe alle Säulen.

**Merksatz:** Es ist nicht "Ich muss eine Nacht drüber schlafen" — es ist: Irgendwo fehlt Vertrauen. Finde heraus, welches, und bau es auf.

---

## 05 · Das Einwände-Framework

Die zentrale Framework-Lektion (mit ausführlichem Begleitdokument als Master-Sheet für alle Einwände). Voraussetzung: Sales-Script und Discovery-Call-Script beherrschen.

**Allgemeiner Vorgang der Einwandbehandlung (6 Schritte):**
1. Person abholen
2. Einwand isolieren
3. Skalafrage stellen
4. Bestätigung einholen
5. Glaubenssatz ändern & Vertrauen aufbauen
6. Den Sack zumachen

**Das universelle 7-Schritte-Framework (Glaubenssätze drehen):**
1. **Always agree first** — "Verstehe, was du meinst."
2. **Person öffnen** — "Bist du offen dafür, dass ich dir nach 200 Klienten mal meine Gedanken teile?"
3. **Neutralen Boden schaffen** — "Das ist übrigens komplett unabhängig davon, ob du das mit uns oder jemand anderem machst."
4. **Durch Logik erklären** — Alltagsbeispiel/Analogie parat haben.
5. **Bestätigungsfrage** — "Macht Sinn, richtig oder richtig?"
6. **Abschlussfrage** (meist nur beim Closen) — "Dann starten wir also in die Zusammenarbeit?"
7. **Gutes Gefühl geben** (beim Close) — "Perfekt — willkommen in der Familie!"

Das Master-Sheet enthält vollständige Vorlagen zu allen Einwänden (kompakte Version — die Detail-Videos folgen als eigene Lektionen):

- **Kein Geld:** Ob-Frage stellen ("Ist es die Frage *ob* wir zusammenarbeiten — oder bist du auf 12/10, musst aber schauen *wie* du es finanziell hinbekommst?"). Meist Vertrauensthema. Bei echtem Geldthema Finanz-Infos sammeln und Realitäts-Check rechnen.
- **Nacht drüber schlafen:** "Du kannst auch 17 Nächte drüber schlafen — die fehlenden Informationen bekommst du hier im Gespräch."
- **Mit Partner sprechen:** "Rein theoretisch, deinen Partner gäbe es nicht — würdest du es jetzt machen?"
- **Kein Coach/Mentor:** Weltmeister-Analogie (Zeit > Geld).
- **Keine Entscheidung:** Fallschirmsprung-Analogie (17 Fallschirme, Komfortzone).
- **Später starten:** Oktoberfest-Analogie (man plant Monate vorher).
- **Keine Zeit:** Prioritäten-Frame.
- **Schlechte Erfahrungen:** Autounfall-Analogie + herausarbeiten, was konkret schlecht war.

**Nächster Step:** Baue die 3–5 häufigsten Einwände ans Ende deines Sales-Skripts ein.

---

## 06 · Glaubensätze drehen

Vertieft Schritt 5 des Frameworks — das mächtige Werkzeug, mit dem du jeden Glaubenssatz drehst. Die ersten drei Schritte sind **immer gleich**, nur Schritt 4 (die Analogie) ist individuell.

Kernpunkte aus dem Transkript:
- **Schritt 2 (öffnen)** gibt psychologisch Trust ("nach X Klienten, die wir betreut haben") und öffnet die Person, überhaupt etwas anzunehmen.
- **Schritt 3 (neutraler Boden)** nimmt den "Hardcore-Closer"-Eindruck: Die Person spürt, dir geht es nicht nur ums Geld. Das unterscheidet den guten vom unangenehmen Vertriebler.
- Der Fehler schlechter Vertriebler: direkt GEGEN den Einwand gehen ("Ja, aber es bringt nichts, eine Nacht drüber zu schlafen…") → wirkt wie "straight in die Fresse". Wir sind aber **mit** der Person, im selben Boot.
- Alles aus einem ruhigen, vertrauensvollen, sicherheitsgebenden State — tiefe, wellenartige Tonalität.
- Wenn die Person bei "Macht das Sinn?" mit "ja, aber…" antwortet: Glaubenssatz ist noch nicht gedreht → ruhig in die nächste Schleife.

**Merksatz:** Die ersten 3 Schritte sind immer gleich. Nur Schritt 4 ist individuell. Framework auswendig lernen und täglich trainieren.

---

## 07 · Einwand: Kein Geld

Der ausführlichste Einwand-Deep-Dive, als Entscheidungsbaum aufgebaut. **Wichtigste Erkenntnis:** In den allermeisten Fällen ist "kein Geld" kein Geld-, sondern ein Vertrauensthema (es gab Fälle mit 40.000 € auf dem Konto, die "kein Geld" sagten).

**Schritt 1 – Die Ob-Frage:** *"Kann ich verstehen. Gib mir kurz Feedback: Ist es bei dir noch die Frage, ob wir zusammenarbeiten — oder bist du auf einer absoluten 12 von 10, aber musst schauen, wie du es finanziell hinbekommst?"*

- **Pfad A – Vertrauensproblem** (Person zögert): Einwand isolieren → **Schalentechnik** ("Gibt es sonst noch Punkte, die uns abhalten?") → 3 Säulen durchgehen (die drei mit Humor benennen: Person/"Scammer nach Panama", Angebot, sich selbst/"Schneeflöckchen im Sommer") → Skalafrage → Bestätigung → Glaubenssatz drehen (hier: Support-Argument + Autounfall-Analogie) → Sack zumachen.
- **Pfad B – Echtes Geldthema** (Person klar auf 12/10): Finanz-Infos sammeln (Einnahmen, Ausgaben, Kontostand privat + Unternehmen, ETF/Aktien/Krypto, unterstützende Eltern). Dann Realitäts-Check: *"Du bist monatlich bei 0 und hast 10.000 € Rücklagen. Investierst du über 3 Monate 5.000 €, hast du danach noch 5.000 € Rücklagen — richtig?"* → Bei vorhandenem Geld: die drei Säulen prüfen (meist kommt dann doch ein Vertrauenspunkt zum Vorschein). Bei fehlendem Geld: individuellen Zahlungsplan finden.

Es ist ein Baukastensystem — man springt zwischen Geld- und Vertrauenspfad hin und her.

---

## 08 · Einwand: Ich muss eine Nacht drüber schlafen

**Erkenntnis:** Fast niemand muss wirklich eine Nacht drüber schlafen — dahinter steckt fehlendes Vertrauen. Grundprinzip: Menschen fühlen sich *erleichtert*, wenn sie eine Entscheidung getroffen haben.

**Schritt 1 – Abholen / Druck rausnehmen:** *"Ich bin ehrlich, du kannst eine oder 17 Nächte drüber schlafen. Am Ende geht es nicht darum, dass ich hier einen Close habe, sondern dass du Klarheit hast. Warum du dich schwer tust: dir fehlen noch Informationen — und die bekommst du hier im Gespräch, nicht in 67 Nächten. Selbst wenn du 'nein' sagst, ist das völlig okay. Lass uns 3 Minuten auf die fehlenden Infos eingehen — passt das?"*

Danach Standard-Framework: 3 Säulen durchgehen, um zu identifizieren, wo der Einwand herkommt → Skalafrage auf die schwächste Säule → Bestätigung → Glaubenssatz drehen → Sack zumachen.

**Merksatz:** Der Einwand ist ein Vorhang — dahinter steckt immer eine der drei Säulen. Öffne den Vorhang, bevor du reagierst.

---

## 09 · Einwand: Ich muss mit meinem Partner sprechen

**Schritt 1 – Rein-theoretische Frage:** *"Völlig fein. Rein theoretisch — deinen Partner gäbe es nicht: Würdest du das jetzt machen? Bist du auf 10/10?"*

- **"So 100% bin ich mir noch nicht"** → Partner ist nur Ausrede, Vertrauensproblem → 3 Säulen aufbauen, dann Abschluss (dann muss die Person oft gar nicht mehr mit dem Partner sprechen).
- **"Ja, aber ich hab's versprochen, vorher zu fragen"** → echtes Partner-Thema → Schritt 2: *"Was machst du, wenn dein Partner sagt, er will nicht — lässt du dich zurückhalten oder machst du es trotzdem?"*
  - **"Dann mache ich es nicht"** → fehlendes Selbstvertrauen: *"Du lässt dich gerade verunsichern. Wenn deine Partnerin sagt, der Himmel ist grün, obwohl du ihn blau siehst, würdest du an dir zweifeln. Wir müssen ERST bei dir Sicherheit aufbauen."* → 3 Säulen.
  - **"Ich mache es auf jeden Fall"** → Deal closen, Partner zum Onboarding-Call einladen. Wenn nicht möglich: erwartete Partner-Einwände sammeln und gemeinsam die Einwandbehandlung üben.

**Merksatz:** Fast immer steckt fehlendes Selbstvertrauen dahinter — baue das zuerst auf, dann erübrigt sich der Partner-Einwand oft.

---

## 10 · Einwand: Ich kann keine Entscheidung treffen

Kommt meist ganz am Ende des Calls. Direkt zu Schritt 5 (Glaubenssatz drehen) über die **Fallschirmsprung-Analogie.**

Zunächst alle 3 Säulen nochmal auf 10/10 bestätigen (Support ✓, Inhalte ✓, Persönlichkeit ✓). Ist eine Säule drunter → zurück zum Vertrauensaufbau. Sind alle bei 10 → nur die Komfortzone hält die Person ab (und nur dort findet Wachstum statt).

**Die Analogie:** *"Wir sind die letzten 60 Minuten zusammen hochgefahren und sitzen an der Kante für einen Tandemsprung. Alternative 1: Du springst nicht, fährst runter, kommst nach Hause — deine Familie fragt, wie es war, und du musst sagen, du hast es nicht gemacht. Alternative 2: Wir springen gemeinsam. Auch wenn es maximal außerhalb der Komfortzone ist — ich garantiere dir, wir haben 17 Fallschirme auf dem Rücken, dir passiert nichts. Ich stehe mit meinem Namen dafür ein, dass du Ergebnisse siehst. Aber dafür musst du jetzt den Abzug drücken."*

**Merksatz:** Nicht entscheiden können = Komfortzone, nicht echter Zweifel. Gib Sicherheit — du hast 17 Fallschirme.

---

## 11 · Einwand: Ich brauche keinen Coach / Mentor / Dienstleister

Klarer Glaubenssatz, den man zuerst drehen muss — direkt zu Schritt 5 über die **Weltmeister-Analogie.**

**Kern (Schritt 4):** *"Was ist deine Lieblingssportart? Wer ist der/die Beste? Hat diese Person — die Beste auf dem Planeten — einen Trainer? Warum, obwohl sie schon die Beste ist? Genau — weil sie verstanden hat, dass Zeit einen höheren Wert hat als Geld. Was hat für dich mehr Wert — deine Zeit, die du nur einmal hast und nie zurückbekommst? Oder dein Geld, wovon es unlimitiert gibt?"*

Die Person verkauft es sich selbst. Abschluss: *"Kannst du mir versprechen, das auf gar keinen Fall alleine herausfinden zu wollen?"* + gutes Gefühl: *"Wenn du eine Sache aus dem Call mitnimmst, dann diese — sie wird dein Leben für immer verändern."*

**Merksatz:** Zeit > Geld. Wer das versteht, hat keinen Grund mehr, es allein zu versuchen (Opportunitätskosten).

---

## 12 · Einwand: Ich möchte später starten

Einer der einfachsten Einwände. Erst Standard-Framework (abholen, isolieren, Skalafrage, Bestätigung), dann die **Oktoberfest-Analogie.**

**Kern:** *"Das Oktoberfest beginnt am 21. September. Die setzen sich ja nicht am 20. hin und überlegen, wie viel Bier sie brauchen und wo die Zelte hinkommen — sie planen das Monate vorher. Genauso ist es bei [deiner Dienstleistung]. Das Letzte, was du willst, ist die wichtigste Aufgabe im Business noch weiter nach vorne zu schieben. Am besten hättest du schon gestern angefangen. Sonst sitzt du in 3 Monaten immer noch da und brauchst dann noch die Startphase — das wollen wir zu 100% vermeiden, oder?"*

Auf Nischen anpassbar (Neukundengewinnung, Finanzen/Rentenlücke, Fitness). Bei Finanzen sogar als Kompromiss möglich: klein starten, in 3 Monaten größeren Plan machen.

**Merksatz:** Der beste Zeitpunkt war gestern. Der zweitbeste ist heute.

---

## 13 · Einwand: Keine Zeit

**Erkenntnis:** Nie direkt sagen "Du brauchst nur X Stunden" — erst fragen, wie viel Zeit wirklich da ist.

**Schritt 1:** *"Sag mir kurz — wie viele Stunden hast du pro Woche zur Verfügung?"*
- Realistische Zahl (5–10h): *"Wir hatten schon einige, die deutlich weniger Zeit hatten. Bei dir ist es eher eine Sache von Prioritäten."*
- Sehr wenig (1–2h, "Elon-Musk-mäßig busy"): einschätzen, ob die Person überhaupt geeignet ist.

**Schritt 2 – Prioritäts-Frame:** Erläutern, warum dein Angebot jetzt Priorität hat → "Würdest du mir da zustimmen?" → Sack zumachen oder weiter zum Vertrauensaufbau.

**Schritt 3 – Verstecktes Vertrauensproblem:** *"Vielleicht liege ich falsch, aber ich habe das Gefühl, du bist noch nicht auf 10/10, dass du das unbedingt willst — vielleicht steckt noch was anderes dahinter?"* → 3 Säulen. Bonus bei Begleitangeboten: zeigen, dass die Person nach der Zusammenarbeit deutlich mehr Zeit spart.

**Merksatz:** "Keine Zeit" = meistens "keine Priorität" = oft fehlendes Vertrauen oder zu wenig Schmerz.

---

## 14 · Einwand: Schlechte Erfahrungen gemacht

**Erkenntnis:** Nicht trösten — genau herausarbeiten, WAS schlecht war, dann zeigen, was bei euch anders ist.

**Schritt 1 – Tief analysieren:** Was genau hat nicht funktioniert? Woran lag es (Anbieter/Prozess/Support)? Was hättest du dir gewünscht? Was brauchst du, um jetzt zu starten? → Daraus sammeln, was du der Person konkret anders geben kannst.

**⚠️ Vorsicht-Signal:** Wenn die Person NUR auf andere zeigt ("alle waren kacke"), prüfen, ob eigene Mitverantwortung anerkannt wird — das Letzte, was du willst, ist ein Kunde, der immer nur dir die Schuld gibt.

**Schritt 2 – Framework + Autounfall-Analogie:** *"Dass du eine schlechte Erfahrung gemacht hast, sollte nicht heißen, dass du nie wieder in ein Coaching investierst. Wenn dir jemand auffährt, fährst du dann kein Auto mehr? Stell dir vor, dann hast du noch einen Bahnunfall und musst in Zukunft nur noch mit der Kutsche fahren. Gerade bei uns bekommst du 110% Support, sodass du gar nicht drum herumkommst, Ergebnisse zu sehen."*

**Schritt 3 – Individuell zeigen, was anders ist:** Nutze, was du in Schritt 1 herausgearbeitet hast — spezifisch, nicht vage.

---

## 15 · Einwand: Garantie

Nachträglich ergänzter Einwand (aus einem Live-Sales-Training). **Erkenntnis:** Erfolg IST eine logische Konsequenz — wenn die richtigen Dinge in der richtigen Reihenfolge mit Beständigkeit umgesetzt werden. Das ist deine "Garantie" (keine Geld-zurück-Garantie).

**Die Gym-Analogie (universeller erster Teil):** *"Im gewissen Sinne hast du eine Garantie. Wenn du mit Ernährungsplan, Trainingsplan und Regeneration ins Training gehst und das umsetzt, wirst du entweder abnehmen oder Muskeln aufbauen — logische Konsequenz."*

**Dann individuelle Ergänzung:**
- **Business/Neukundengewinnung:** Richtige Positionierung + Content + täglich mit X Leuten in Verbindung + funktionierendes Chat-/Sales-Framework, konsequent umgesetzt → Erfolg logisch.
- **Finanzen/ETF:** Regelmäßig in die 2.000 größten Firmen (~7% p.a.) investieren → es kann nicht passieren, dass du weniger hast; einziges Restrisiko: "Alien-Invasion und die Welt geht unter — dann haben wir andere Probleme."
- **Webdesign:** Leute googeln Physiotherapie, deine optimierte Website erscheint → früher oder später Kontaktaufnahme, logische Konsequenz.

---

## 16 · Das Skript anpassen

Übergangs-/Umsetzungslektion. **Aufgabe:** Baue die 3–5 häufigsten Einwände ans Ende deines Sales-Scripts ein.

**Baukastensystem:** Schritte 1–3 (Agree, öffnen, neutraler Boden) und 5–7 (Bestätigung, Abschluss, gutes Gefühl) sind immer gleich; nur Schritt 4 (die Analogie) ist individuell.

**So passt du an:** Top-Einwände identifizieren → Vorlagen als Basis nehmen → in deine Sprache umformulieren (Sinn bleibt, Füllwörter/Tonalität dürfen individuell sein) → einfügen (nach dem Angebot, vor dem Close).

**Achtung:** Skript kennen ≠ automatisch Sales. Alle Prinzipien müssen berücksichtigt werden (Vertrauen, Verkaufszone, Sicherheit, gleiches Boot). Übung ist Pflicht: Roleplay mit Geschäftspartner, in die Sales-Trainings/Calls kommen, Feedback einholen.

**Merksatz:** Sales ist wie Fitness — Wissen allein reicht nicht, es braucht Wiederholung, Feedback und echte Calls.

---

## 17 · Im gleichen Boot sitzen

Grundprinzip. Der größte Fehler der meisten Vertriebler: die andere Person *überzeugen* wollen — das drängt sie in die Ecke und macht Sales "verrufen".

**Zwei Typen:**
| Typ | Verhalten | Wirkung |
|---|---|---|
| ❌ Der Überzeuger | redet 80%, bringt ständig Argumente, kämpft gegen Einwände | unsympathisch, erzeugt Widerstand |
| ✅ Der Fragende | redet 20%, stellt Fragen, lässt den Prospekt sich selbst verkaufen | sympathisch, Vertrauen entsteht |

**Innere Einstellung:** Die Entscheidung wird immer *gemeinsam* getroffen, weil du das Beste für den Gegenüber willst. Das bedeutet NICHT: sich kleiner machen oder alles bestätigen (kein Ja-Sager). Es bedeutet: klar zeigen, wo es langgeht — aber mit dem Gefühl "Ich mache das nicht für den Sale, sondern weil es das Beste für dich ist". (Im DACH-Raum gilt Verkaufen oft als negativ — aber Verkaufen ist etwas Geiles, wenn die Absicht positiv ist.)

**Druck abbauen** (wenn hitzige Gegeneinander-Energie entsteht): *"Vielleicht liege ich falsch, aber ich merke gerade eine sehr intensive Energie. Lass uns kurz so tun, als wären wir nicht in einem Verkaufsgespräch — denn eigentlich sitzen wir im gleichen Boot: Du willst, dass dein Business wächst, und ich will das auch, weil du dann ein zufriedener Client bist. Wir rudern in die gleiche Richtung. Macht das Sinn?"*

**Dating-Parallele:** Wer hinterherrennt, verliert das Interesse des Gegenübers. Verzahnt mit [[Der Bruch als Bauplan]]: echte menschliche Verbindung statt Druck.

**Merksatz:** Sales ist kein Ich-gegen-Du, sondern immer ein Miteinander.

---

## 18 · So strahlst du Sicherheit aus

Grundlegendes Prinzip: **immer mit 100% Sicherheit kommunizieren.** Menschen glauben dir, wenn Sicherheit unter deinen Worten liegt — oft ist das *Wie* wichtiger als das *Was*. Statt hektisch, laut und im Konjunktiv ("könnte", "vielleicht") → ruhig, gelassen, tiefe Tonalität, kurze klare Sätze. Vor jedem Call 1–2 Minuten in den Sicherheits-/Vertrauensmodus gehen.

| Situation | ❌ Unsicher | ✅ Sicher |
|---|---|---|
| "Bekommen wir das wirklich hin?" | "Ich glaube, das könnte klappen…" (+ Info-Flut) | "Ja, safe bekommen wir das hin." — und schweigen |
| Preis genannt, Person schreckt zurück | nervös rechtfertigen | ruhig bleiben, Stille halten, Person zurückkommen lassen |
| Stil | hektisch, hohe Stimme, Konjunktiv | ruhig, tiefe Tonalität |

**Preis-Learning:** Die Zurück-Reaktion beim Preis ("oh, das ist viel Geld") ist völlig normal — Unterbewusstsein bei Geld/Entscheidung/Wachstumssprung. Nicht darauf reagieren, ruhig bleiben, dann Vertrauensaufbau beginnen.

**Wichtig:** Sicherheit heißt nie lügen. Nichts verkaufen, was nicht hält — jede Lüge fliegt auf und bindet Stress.

**Merksatz:** Menschen glauben dir, wenn du mit Sicherheit kommunizierst.

---

## 19 · Skalafragen

Mächtiges Tool für Klarheit und Kontrolle. Immer eine Skala von 1–10 — macht das Schwammige messbar, sammelt Argumente ein und zeigt Kaufbereitschaft.

**Vorteile:** Klarheit schaffen, Argumente nicht verlieren, Kontrolle halten, Kaufbereitschaft messen.

**Technik der bewussten Übertreibung:**
- Person soll NICHT 10 sagen (z. B. bestehende Strategie): *"Mit der Strategie bist du auf einer absoluten 12 von 10 — willst das nie wieder ändern und empfiehlst es sogar deinen Kindern?"* → Person sagt 8–9 → "Was fehlt bis zur 10?"
- Person soll NICHT 1 sagen (z. B. Vertrauen in dich): *"Wenn 1 heißt, ihr seid die allerletzte Firma und du willst hier raus…"* → Person sagt 5–6 → "Was fehlt bis zur 10?" → Vertrauen aufbauen.

**Ablauf:** aktuellen Zustand skalieren → fehlende Punkte sammeln ("Welche 3 Dinge fehlen bis zur 10?") → jeden Punkt einzeln adressieren → nachprüfen. Einsetzbar in jeder Phase.

**Merksatz:** Eine Zahl sagt mehr als tausend Worte — Skalafragen machen das Unsichtbare sichtbar.

---

## 20 · Kontrolle zurückgewinnen

Löst das Anfängerproblem endlos langer Calls (2 Std. statt 30–45 Min.). **Regel:** Einen Prospekt NUR unterbrechen, wenn er in die falsche Richtung läuft — NIEMALS, wenn er sich gerade selbst verkauft.

**Taktik in 4 Schritten:**
1. **Vornamen ansprechen** — "Max, Max…"
2. **Loben** — "Das ist super hilfreich, was du gerade sagst."
3. **Transition** — "Ich habe aber zu einem Punkt noch eine kleine Nachfrage."
4. **Frage im gleichen Atemzug** (freundlich wiederholen / nächste Skript-Frage) — "Spezifisch im letzten Monat, sag mir nur eine Zahl: Wie viel Ad-Spend hast du ausgegeben?"

Dieselbe Frage darf man mehrmals stellen — bleibt freundlich. Mindset: Fragen wiederholen ist nicht unhöflich, es respektiert die Zeit beider und wirkt professionell → höhere Closing-Rate.

---

## 21 · Probleme adressieren

Kritische Skill: störende Faktoren ansprechen, bevor sie sich durch den ganzen Call ziehen.

**6 Szenarien:** Prospekt fährt Auto, isst, klickt herum, ist unhöflich, du spürst unangenehme Spannung, oder du merkst diffus "etwas stimmt nicht".

**Fall 1 (unaufmerksam/isst/fährt):** *"Hey [Name], ich habe gerade das Gefühl, ich habe nicht deine 100%ige Aufmerksamkeit. Unser Call ist kein Nebenbei-Gespräch — wir treffen heute eine Entscheidung, die dein Leben nachhaltig verändern soll. Dafür ist deine volle Aufmerksamkeit fundamental. Siehst du das genauso?"* → 99% sind sofort da. Fährt die Person noch länger als 10 Min.: Call verschieben.

**Fall 2 (Spannung/etwas stimmt nicht):** *"Hey [Name], es kann sein, dass ich komplett falsch liege, aber ich habe gerade das Gefühl, dass [Gefühl beschreiben]. Stimmt das oder liege ich falsch?"* — Der Zusatz "es kann sein, dass ich falsch liege" nimmt psychologisch die Spannung und gibt der Person einen Ausweg. Deine Wahrnehmung ist nicht die Wahrheit, nur Wahrnehmung — aber ansprechen ist entscheidend.

Die 1%, die auf die Barrikaden gehen, sind ohnehin nicht die Wunschkunden. Prinzip gilt fürs ganze Leben (Beziehungen).

---

## 22 · Wichtige Bedingungen die erfüllt sein müssen

Mentale Checkliste — **7 Bedingungen**, die für einen Close erfüllt sein müssen. Sind alle erfüllt, ist die Close-Wahrscheinlichkeit extrem hoch.

| # | Bedingung | Was fehlt / zu tun |
|---|---|---|
| 1 | **Problembewusstsein** | Kein Schmerz = kein Kauf. Je größer der Schmerz, desto leichter der Verkauf. Ggf. Probleme herausarbeiten. |
| 2 | **Entscheidungsfähigkeit** | Person kann allein entscheiden — oder alle Entscheider (Partner, Geschäftspartner, Vorstand) sind im Call. |
| 3 | **Zweifel, es allein zu lösen** | Ist die Person 100% sicher, es allein zu schaffen, wird's schwer → Verkaufszone, Detailfragen. |
| 4 | **Opportunitätskosten bekannt** | Was kostet es, NICHT zu handeln? Das erhöht den Schmerz. |
| 5 | **Verlangen nach Veränderung** | "Ergeben"-Gefühl (zu weit links) → Vertrauen in sich selbst aufbauen. |
| 6 | **Finanzielle Mittel** | Kein Geld → individuelle Lösung; Geld da, aber zurückgehalten → Vertrauensproblem. |
| 7 | **Vertrauen in Methode/Angebot** | Fehlende Säule identifizieren und aufbauen. |

**Merksatz:** Ein Nicht-Close bedeutet immer: mindestens eine dieser 7 Bedingungen war nicht erfüllt. Finde heraus, welche.

---

## 23 · Verschicke niemals ein Angebot

Kurze, harte Regel: **Angebote nie per Mail verschicken** — immer live im Call präsentieren und durchgehen. "Schick mir mal ein Angebot" bedeutet in ~95% der Fälle "Ich bin noch nicht ready". Leute lügen, ignorieren Mail-Angebote und unterschreiben sie fast nie.

**Warum im Call:** Fragen sofort klären, Einwände live adressieren, Momentum und Commitment erzeugen.

**Einzige Ausnahme:** sehr große Konzerne / börsennotierte Firmen — längerer Sales-Zyklus, viele Entscheider und Genehmigungsstufen, mehrere Gespräche. Ansonsten gilt die Regel ausnahmslos.

---

## 24 · Vereinbare immer Folgetermine

Kurze, harte Regel: **immer** einen konkreten Folgetermin im Kalender eintragen — egal in welcher Phase (Opening, Setting/Discovery, Closing, Upsell, Follow-up). Nie auf "Ich schreib dir eine Mail / such mir einen Termin raus" verlassen — das ist meist die Ausstiegs-Ausrede.

**Bei Widerstand adressieren:** *"Ich habe so ein Gefühl, gib mir gerne Feedback: Ist es gerade die Frage, ob wir überhaupt einen weiteren Termin machen — oder willst du auf jeden Fall, aber es passt zeitlich gerade wirklich nicht?"* → echten Grund lösen, dann Termin setzen.

**Warum:** Verbindlichkeit, Momentum, weniger Ausfälle (Menschen halten sich eher an Kalendereinträge als an vage Zusagen). Verzahnt mit Lektion 23: Ein Folgetermin ist der definierte nächste Schritt.

---

## 25 · Aussagen überhören

Eine der wichtigsten emotionalen Skills: nicht auf jede Aussage eingehen, sich nicht in Diskussionen verlieren. **"Rein, raus"** — bestimmte Aussagen bewusst überhören.

**Aussagen, die man (zunächst) überhört:**
1. **"Ich treffe heute keine Entscheidung"** — Schutzmechanismus, weitermachen.
2. **"Ich habe eh kein Budget"** — 80% Ausrede/Test; nur wenn ganz am Ende genannt, mit den Vorlagen darauf eingehen.
3. **"Ich schlafe immer eine Nacht drüber"** (am Anfang) — Unsicherheit/fehlendes Vertrauen; NICHT gegenargumentieren, einfach Vertrauen weiter aufbauen.
4. **"Ich hab schon mal ein Coaching gekauft, hat nichts gebracht"** — nicht verrückt machen ("ich kann auch nicht helfen"); erst mehr Infos sammeln.
5. **"Du bist auch nur ein weiterer Coach/Dienstleister"** — persönlicher Angriff/Test; nicht verteidigen ("ich bin aber anders"), cool annehmen.
6. **"Ich kann sowas eher alleine"** — keine Diskussion, überhören.

**Innere Haltung — Stand eines Boxers:** breitbeinig, für jeden Punch gewappnet, fällt nicht bei einem kleinen Schlag um. Lerne zu unterscheiden, was echter Einwand ist und was nur Rauschen — ignoriere das Rauschen, adressiere nur die echten Probleme zum richtigen Zeitpunkt.

---

## 26 · Deine nächsten Schritte

Abschluss-/Umsetzungslektion. Ein klares 4-Schritte-System:

1. **Notiere deine 3–5 häufigsten Einwände** (bekommene oder erwartete).
2. **Schreibe Schritt für Schritt runter, wie du damit umgehst** — was du fragst, was du sagst, welche Tonalität, dein konkretes Skript.
3. **Gehe jeden Einwand 3× durch** → Skript-Sicherheit (Formulierung, Tonalität, Automatisierung, natürliche Wirkung im echten Call).
4. **Geh ins nächste Sales-Training und übe die Einwände** mit echtem Feedback (Roleplay, Group Coaching, Live-Call).

**Skript-Sicherheit** ist kein "Verstellen", sondern Vorbereitung — der Pilot fliegt nicht ohne Checkliste, der Schauspieler lernt seinen Text, der Boxer trainiert seine Techniken.

**Der Game-Changer** = Kombination aus theoretischem Verständnis (dieses Modul) + schriftlicher Vorbereitung (Schritt 1–3) + echtem Training & Feedback (Schritt 4).

**Versprechen:** Konsequent umgesetzt wirst du schnell deutlich besser und bald Experte in Einwandbehandlung — höhere Closing-Rate, mehr Sicherheit. "Du hast das Wissen. Jetzt musst du es nur noch machen."
