---
type: wissen
tags: [sales, positionierung, kundenavatar, 3s-formel, founder-workspace]
quelle: Notion
erstellt: 2026-07-08
---

# Sales Foundation

Das Fundament des Sales-Systems im [[Founder Workspace V2]]: **Wen** sprichst du an (Kundenavatar), **wie** positionierst du dich (3S-Formel), **welches Angebot** machst du. Diese Grundlagen speisen alles Weitere — Skripte, Content und Pipeline. Teil des Sales-Handwerks der [[Inner GOAT Academy]].

## Kontext & Anlass

Stammt aus der Notion-Seite "🧭 Sales Foundation" im Inner GOAT Founder Workspace 2.0. Die Seite ist als Arbeits-Template mit auszufüllenden Feldern angelegt; hier ist die Methodik als Wissensnotiz festgehalten. Zwei zugehörige Datenbanken (**Kundenavatare** und **Firmen/Companies**) leben als Arbeits-Tracker weiter im laufenden Notion und werden hier nicht gespiegelt.

## Schritt 1: Positionierung (3S-Formel)

> Ohne klare Positionierung wird nie effizient verkauft. Diese Formel ist die Grundlage für alles Weitere.

Die 3S stehen für **Spezifischer Markt · Spezifisches Problem · Spezifischer Weg**.

### Spezifischer Markt (WER)

Leitfragen zur Eingrenzung der Zielgruppe:
- Welche Kunden machen am meisten Spaß?
- Für welche konntest du das beste Ergebnis liefern?
- Welche sind vom Support her am einfachsten?
- Welche waren am einfachsten im Verkauf?

### Spezifisches Problem (WAS)

- Welches Problem kannst du am besten lösen?
- Bei welchem Problem kannst du dir vorstellen, dich wirklich tief einzuarbeiten?
- Welche Probleme haben deine Klienten offensichtlich, zu denen du dir die passenden Fähigkeiten aneignen kannst?

### Spezifischer Weg (DEIN MODELL)

> Was macht dich besser als den Wettbewerb, der dieselben Probleme löst?

Sechs-Satz-Struktur zum Ausformulieren des eigenen Mechanismus:
1. **Die meisten Leute, die XYZ erreichen wollen, probieren:** …
2. **Das Problem dabei ist, dass:** …
3. **Das bedeutet am Ende des Tages:** …
4. **Stattdessen machen wir:** …
5. **Was uns erlaubt:** …
6. **Was am Ende dazu führt:** …

### Positionierungssatz

Die 3S werden zu einem Satz verdichtet. Beispiel-Struktur:

> *"Wir helfen [MARKT] dabei, durch [MODELL/METHODE] planbar [ERGEBNIS] zu erreichen."*
>
> Beispiel: *"Wir helfen Agenturen dabei, durch die NMP-Methode planbar 3-5 Neukunden pro Monat zu gewinnen."*

## Vorher / Nachher — die Transformation

Kern der Positionierung: der Sprung vom IST-Zustand (Pain Island) zum Wunschzustand (Dream Island). Beide Seiten in je 3-5 Punkten festhalten — das liefert die Nutzenargumente für Skripte und Content.

| Vorher (IST-Zustand) | Nachher (Transformation) |
| --- | --- |
| … | … |

## Schritt 2: Das Angebot

Kernparameter des Core-Offers, die vor jedem Sales Call feststehen müssen:
- **Laufzeit des Core-Offers** (Bsp.: 4 Monate)
- **Investment** (Bsp.: 5.000 € netto)
- **Ratenzahlung möglich?** (Bsp.: ja, max. 4 Raten)
- **Was passiert nach der Laufzeit?** (Bsp.: Verlängerung des Supports für 1.000 € netto/Monat)
- **Genauer Ablauf der Zusammenarbeit** aus der Vogelperspektive (5 grobe Schritte)

## Schritt 3: Kundenavatare

Avatare werden in der **Kundenavatare-Datenbank** im Notion angelegt (Tracker, hier nicht gespiegelt). **Avatar 1** ist der Haupt-Avatar; Avatar 2 und 3 sind optional für weitere Zielgruppen. Die Avatar-Painpoints werden später in Content und Skripte eingespeist (siehe KI-Prompt in [[Content-Templates (Social)]]).

## Anwendung

- Grundlage für [[Akquise & Skript-Bibliothek]] (Skripte an Avatar + Positionierung anpassen).
- Grundlage für [[Content-Templates (Social)]] (Avatar-Painpoints füttern Posts).
- Eingebettet in [[Founder Workspace V2]]; methodisch verwandt mit der [[Inner GOAT Academy]] (Reiter 3 — Sales, Marketing & Personal Branding).

## Verwandte Notizen

- [[Akquise & Skript-Bibliothek]]
- [[Content-Templates (Social)]]
- [[Inner GOAT Academy]]
- [[Founder Workspace V2]]
