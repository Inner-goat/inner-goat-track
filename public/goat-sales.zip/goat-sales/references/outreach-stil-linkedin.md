---
type: playbook
tags: [marco, outreach, linkedin, leads, vertrieb]
erstellt: 2026-07-08
---

# Outreach-Stil LinkedIn

Marcos verbindlicher Schreibstil für LinkedIn-Connect-Anfragen und DMs an Leads aus dem [[GOAT Leads CRM]] — insbesondere an FUN-Kontakte. Grundton siehe [[Schreibstil]].

## Die Bausteine (in genau dieser Reihenfolge)

1. **Opener:** „Moin [Vorname]" — kein „Hi", kein „Hey", kein „Hallo".
2. **Gemeinsamer Kontext direkt im 1. Satz:** „wir waren beide bei FUN 2026" / „wir haben beide bei X teilgenommen". Abkürzung **FUN** (nicht FU) für *Freelance Unlocked Networking*.
3. **Konkretes Zitat aus deren Intro/Profil:** „Dein Intro mit „[Originalzitat]" hat mich angesprochen." — zeigt: er hat gelesen, kein Copy-Paste.
4. **Selbstpositionierung:** „Ich bin selbst **Founder bei [[Inner GOAT]]**" — NICHT „Co-Founder", auch wenn Marco das auf WhatsApp manchmal sagt. Bei Cold-Outreach positioniert er sich als Founder solo.
5. **Kurzer Brückensatz:** „da geht's genau darum" — verbindet sein Business mit deren Interesse, ohne zu pitchen.
6. **Soft Close:** „Lass uns gerne austauschen" — niedrigschwellige Einladung, kein „Bock auf Call?".
7. **Signoff:** „LG, Marco" — deutsches „Liebe Grüße", abgekürzt.

## Formale Regeln

- **Keine Emojis** standardmäßig (kein 🐐, keine ✨) — trotz GOAT-Branding zurückhaltend in Direct-Outreach.
- **Punkte statt Kommas**, kurze Sätze, leicht informell.

## Herkunft & Anwendung

- **Why:** Marco hat den Stil explizit am Beispiel einer Nachricht an Dominik (FUN-Sheet-Kontakt) gezeigt. Die FUN-Sheet-Leads im [[GOAT Leads CRM]] sollen damit warm akquiriert werden.
- **How to apply:** Beim Generieren von Connect-Nachrichten oder Follow-ups für Leads die Bausteine oben in dieser Reihenfolge nutzen. Pro Person das konkrete Detail aus der gespeicherten FUN-Notiz zitieren.

## Beispiel-Original (Marco an Dominik)

> Moin Dominik, wir waren beide bei FUN 2026. Dein Intro mit „connecten mit Gleichgesinnten, deren Erfahrungen weiterhelfen" hat mich angesprochen. Ich bin selbst Founder bei Inner GOAT, da geht's genau darum. Lass uns gerne austauschen LG, Marco

## Verwandt

- [[Marco Maiworm]] — Personen-Notiz
- [[Schreibstil]] — übergreifende Tonalität
- [[Kampagnen-Standard]] — Standard-Aufbau der E-Mail-Kampagnen in [[GOAT Flows]]
