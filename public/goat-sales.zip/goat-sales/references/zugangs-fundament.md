# Zugangs-Fundament — Inner GOAT Sales-Basis

Die Grundlagen, die im GOAT Sales Skill hinter jeder Empfehlung stehen. **Von Inner GOAT — Marco Maiworm & Nel Steinkühler.**

Fünf Kern-Bausteine:
1. Die 4 Zugangsfragen
2. Die 3 Käufer-Ja's
3. Anlass-Verkauf (Trigger-Momente)
4. Das Lern-System für Sales-Profis
5. Zeit- und Fokusregeln (More Focus, More Sales)

---

## 1. Die 4 Zugangsfragen

**Kern-Bild:** Dein Kunde entscheidet in Sekunden, ob du seiner Zeit wert bist. Wenn du diese Sekunden nicht gewinnst, ist der Verkauf vorbei — nicht durch Absage, sondern durch **Ignoranz**.

Jede Cold-Mail, jede LinkedIn-DM, jede Kalt-Anrufs-Öffnung muss vier Filter überstehen, sonst verschwindet sie zwischen 250 anderen Nachrichten pro Tag.

| Filter | Regel | Praktische Frage |
|---|---|---|
| **1. Klar** | Halte alles einfach. Ein Schritt, ein Wort, eine Entscheidung. Komplexität ist der Feind. | *"Kann mein Kunde diese Nachricht in 10 Sekunden verstehen und in einer weiteren Sekunde entscheiden?"* |
| **2. Wertvoll ohne Termin** | Sei unverzichtbar, indem du sofort Wert lieferst. Kein "Darf ich Ihnen etwas verkaufen?", sondern relevante Insights, die er sonst nicht bekommt. | *"Was weiß ich über sein Business, das er nicht weiß — und das ich in 2 Sätzen teilen kann?"* |
| **3. Auf ihn ausgerichtet** | Richte deine Botschaft konsequent an SEINEN Prioritäten aus, nicht an deinem Produkt. | *"Sagt meine Nachricht 'ich helfe dir bei X, das gerade deine Nr. 1 ist' oder 'wir sind toll'?"* |
| **4. Docking-Punkt = Top 3** | Erkenne, was oben auf seiner Liste steht. Alles außerhalb der Top 3 wird verschoben — auch dein bestes Angebot. | *"Was steht wirklich auf seiner Top-3-Prioritätenliste — und wie docke ich exakt da an?"* |

### Anwendung im Erstkontakt

**Statt** *"Ich möchte mich vorstellen — meine Firma XY hilft Unternehmen dabei, Z…"*

**Sondern** *"Sie haben vor drei Wochen ihr [Trigger-Event] gemacht. Bei zwei Ihrer Wettbewerber führt genau dieser Schritt in den nächsten 6 Monaten zu [konkretem Problem]. Falls interessant, hier die drei Kernfehler, die man dabei macht — 90 Sekunden."*

Klar (1 Grund). Wertvoll (Insight geben). Auf ihn ausgerichtet (auf seinen Trigger). Priorisiert (nicht "wollen Sie mal reden", sondern "hier ist ein spezifischer Punkt").

---

## 2. Die 3 Käufer-Ja's

**Kern-Bild:** Jeder Kauf ist nicht *eine* Entscheidung, sondern eine Kette aus drei aufeinander aufbauenden Ja's. Wer bei Ja Nr. 3 verkauft, während Ja Nr. 1 oder 2 fehlt, verliert.

### JA 1: Zugang
*"Erlaube ich dir überhaupt Kontakt?"*
- Öffne ich deine Mail?
- Nehme ich das Telefon an?
- Akzeptiere ich das Meeting?

Wenn dieses Ja fehlt, ist alles andere theoretisch.

### JA 2: Veränderung
*"Ist mein Problem groß genug, um überhaupt was zu verändern?"*

Der **Status quo** ist der stärkste Konkurrent, nicht der Wettbewerber. Der Kunde denkt: "Läuft ja irgendwie" — und dieses Denken tötet mehr Deals als jeder Preis.

Für dieses Ja braucht der Kunde:
- Klarheit über den akuten Pain (Zahlen, konkrete Auswirkungen)
- Klarheit über die Kosten des Nichtstuns (was passiert in 3–6 Monaten ohne Änderung?)
- Emotionale Übersetzung des Pains ("wie wirkt sich das auf andere Lebensbereiche aus?")

### JA 3: Wahl
*"Bist DU / dein Angebot die richtige Wahl?"*

Erst hier kommen Preisvergleich, Referenzen, Feature-Diskussion. Die meisten Verkäufer starten hier — und verlieren.

### Diagnose-Regel

Wenn ein Deal stockt, prüfe zurückwärts:
- Bei Ja 3 stecken? → wahrscheinlich fehlt Ja 2. Zurück zur Pain-Ergründung.
- Bei Ja 2 stecken? → wahrscheinlich fehlt Ja 1. Der Kunde hört dich, aber du bist noch nicht "relevant" für ihn geworden.
- Bei Ja 1 stecken? → dein Outreach erfüllt die 4 Zugangsfragen nicht.

---

## 3. Anlass-Verkauf (Trigger-Momente)

**Kern-Bild:** Verkaufe nicht "wenn du was hast" — verkaufe **wenn beim Kunden etwas passiert**, das dein Thema akut macht. Wer den Anlass trifft, klopft an einer bereits offenen Tür.

### Typische Trigger im B2B

- Neuer CxO oder Führungswechsel
- Restrukturierung / Layoffs
- Frische Finanzierung / Übernahme / Fusion
- Q-Ergebnisse verfehlen Erwartungen
- Wettbewerber greift an
- Wichtiger Kunde weg
- Gesetzliche Änderung im Feld

### Trigger im Inner-GOAT-Feld (28–45 J. Gründer:innen, 0–150k € Umsatz)

- Frisch gegründet (< 6 Monate)
- Erster Kunde gekündigt
- Erster Mitarbeiter eingestellt
- LinkedIn-Post viral gegangen aber keine DMs → sichtbar sein reicht nicht
- Ausstieg aus dem Angestelltendasein bekanntgegeben
- Podcast/Buch veröffentlicht → Positionierung akut
- Kurs- oder Skill-Launch angekündigt
- Öffentliche Konflikt-/Klage-Kommunikation

### Wie du Trigger findest

- LinkedIn-Aktivitäten des Empfängers (letzte 30 Tage)
- Pressemitteilungen des Unternehmens
- Karriere-Änderungen von Führungskräften (LinkedIn)
- Öffentliche Statements: Podcast-Interviews, Talks, Bücher
- Nachrichten in der Branche (Google Alerts)
- Wettbewerber-Moves

### Trigger + 4 Zugangsfragen = Killer-Cold-Outreach

Ein präziser Trigger macht die 4 Zugangsfragen 10× leichter zu erfüllen — weil du automatisch klar, wertvoll, auf ihn ausgerichtet und priorisiert bist.

---

## 4. Das Lern-System für Sales-Profis

**Kern-Bild:** Verkäufer 2026 gewinnen nicht durch mehr Anrufe, sondern durch **schnelleres Lernen**. Wer in 30 Tagen die neue Branche/das neue Produkt beherrscht, gewinnt gegen die, die 6 Monate brauchen.

### Die 4 Beschleuniger

1. **Rapid Learning Mindset** — Jeden Deal, jedes Meeting, jede Absage als Lerndaten behandeln. Nach jedem Call: *"Was habe ich hier neu gelernt über meine Zielgruppe?"*
2. **Chunking** — Komplexe Themen in 20–30-Min-Wissensblöcke zerlegen. Nicht "ich muss das ganze Buch lesen", sondern "3 Prinzipien, dann Anwendung".
3. **Deliberate Practice** — Bewusste Wiederholung von schwachen Stellen. Nach jedem Discovery: welche Frage ist mir schwergefallen? Genau die morgen in 5 Übungscalls trainieren.
4. **Just-in-Time-Wissen** — Vor jedem Termin: 15 Min gezielte Recherche zum Kunden, statt 3 Std generischer Vorbereitung.

Passt zu den täglichen 6-Std-Fokuszeiten im Inner-GOAT-System.

---

## 5. Zeit- und Fokusregeln (More Focus, More Sales)

**Kern-Bild:** Die meisten Verkäufer verlieren 60–70 % ihrer Zeit an Ablenkung, Kontext-Switching und "Sales-Theater" (interne Meetings, CRM-Updates, endloses Vorbereiten). Inner-GOAT-Regel: **Deep Work + Zeitblöcke**.

### Die 5 Kern-Regeln

1. **Vor 10 Uhr kein E-Mail-Postfach** — die ersten 2 Stunden gehören der Akquise / dem wichtigsten Deal.
2. **Batching** — alle E-Mails 2×/Tag beantworten, nicht durchgehend.
3. **Zeitblöcke schützen** — 90-Min-Blocks pro Sales-Aktivität (Akquise / Discovery / Closing / Fulfillment), keine Vermischung.
4. **Nein zu Meetings ohne Agenda** — jedes Meeting ohne 3-Zeilen-Agenda vorab wird abgelehnt oder umgeplant.
5. **Wöchentliches Review** — 30 Min am Freitag: was hat gewirkt, was war Ablenkung, was verschiebe ich, was streiche ich.

### Verbindung zur Inner-GOAT-Erfolgsformel

`ERFOLG = POTENZIAL − ABLENKUNG`

Die 5 Regeln sind praktisch angewandte Ablenkungs-Minimierung. Der **Daily Standard (6 h Fokuszeit)** aus dem Work Credo ist der operative Rahmen:
- 1 h Akquise (8 Nachrichten raus)
- 1 h Marketing
- 1,5 h Calls mit potenziellen Kunden
- 2 h Fulfillment für Bestandskunden
- 0,5 h Puffer

Diese 6 h müssen **geschützt** werden — nicht mit E-Mail-Push-Notifications, nicht mit Slack, nicht mit spontanen Team-Calls.

---

## Wie diese 5 Bausteine zusammenspielen

| Ebene | Baustein | Zweck |
|---|---|---|
| **Zugang gewinnen** | 4 Zugangsfragen + Anlass-Verkauf | Wie du überhaupt Aufmerksamkeit bekommst |
| **Kunden zur Veränderung führen** | Die 3 Käufer-Ja's | Wie du Status quo aufbrichst |
| **Deals abschließen** | BANT + Discovery + 12-Schritt-Closing (siehe `marcos-akquise-bibliothek.md`) | Was du im Call/Meeting konkret sagst |
| **Nachhaltig verkaufen** | Lern-System + Fokusregeln | Wie du dein Sales-Handwerk dauerhaft hältst |

Der GOAT Sales Skill kombiniert diese Ebenen automatisch — der User muss sich nicht merken, welche Regel zu welchem Baustein gehört. Er beschreibt sein Problem, der Skill wählt die passende Ebene.
