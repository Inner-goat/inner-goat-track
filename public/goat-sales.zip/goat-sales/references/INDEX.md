# Sales References — Index

Wann du welche Datei lesen sollst. Nicht alle auf einmal — nur die, die zum aktuellen Modus passen.

## Fundament (Modus 1–5, Basis-Handwerk)

| Datei | Wann lesen |
|---|---|
| `zugangs-fundament.md` | **PFLICHT.** Die 4 Zugangsfragen, 3 Käufer-Ja's, Anlass-Verkauf, Lern-System, Fokusregeln. Kern des Skills. |
| `marcos-akquise-bibliothek.md` | Immer wenn User im Handwerk (BANT-Diagnose, Discovery-Skript, 12-Schritt-Closing, Einwandbehandlungs-Techniken) steht |
| `sales-foundation.md` | Wenn Positionierung, ICP, Angebots-Grundstruktur unklar sind — Basis für alles danach |

## Ton, Schrift, LinkedIn-Kanal

| Datei | Wann lesen |
|---|---|
| `outreach-stil-linkedin.md` | **PFLICHT bei jeder Cold-Nachricht.** Marcos exakter Ton: "Moin", FUN-Abkürzung, Founder (nicht Co-Founder), Zitat aus Intro, "Lass uns austauschen", "LG, Marco", keine Emojis |
| `schreibstil.md` | **PFLICHT.** Übergreifende Tonalität, Deutsch/Du, Vokabular |
| `content-templates-social.md` | Wenn User Social-Content zur Sales-Vorbereitung braucht (LinkedIn-Post-Templates für Vertrauens-Aufbau) |

## Academy-Reihe: Sales, Marketing & Personal Branding

Die ganze Modul-Serie (Reiter 3 der Inner GOAT Academy). Lies EIN Modul pro Anfrage — nicht alle auf einmal.

| Datei | Wann lesen |
|---|---|
| `academy-0-einfuehrung-linkedin.md` | Wenn User grundsätzlich LinkedIn als Sales-Kanal aufbaut |
| `academy-1-neukundengewinnung.md` | Grundlagen — wenn User im Sales-Denken noch am Anfang steht |
| `academy-2-content.md` | Wenn Sales über Content läuft (Trust-Aufbau, Warm-Leads) |
| `academy-3-kundenakquise.md` | Vertiefung Akquise (ergänzt `marcos-akquise-bibliothek.md`) |
| `academy-4-kundenabschluss.md` | Vertiefung Closing (ergänzt Bibliothek) |
| `academy-5-salestraining.md` | Wenn User systematisch trainieren will (Übungen, Drills) |
| `academy-6-b2b-direktakquise.md` | Vertiefung Kaltakquise B2B |

## Ergänzende Kanäle

| Datei | Wann lesen |
|---|---|
| `newsletter-strategie.md` | Wenn Sales über E-Mail-Newsletter läuft — Aufbau + Sequenzen |
| `video-guidelines.md` | Wenn User Videos in seine Sales-Kette einbaut (Mehrwert-Video, Reels als Warm-up) |

## Lade-Reihenfolge (Empfehlung)

Wenn eine User-Anfrage kommt und du unsicher bist:
1. **Immer zuerst** `zugangs-fundament.md` + `schreibstil.md` präsent haben.
2. Cold-Outreach-Fragen → `outreach-stil-linkedin.md` + `zugangs-fundament.md`.
3. Discovery / Closing / BANT / Einwand → `marcos-akquise-bibliothek.md` als Hauptquelle.
4. Wenn User weiter zurück ist (Positionierung/Angebot) → `sales-foundation.md`.
5. Bei "systemischen" Anfragen (wie baue ich mein Sales-System auf) → die passende Academy-Reihe.
