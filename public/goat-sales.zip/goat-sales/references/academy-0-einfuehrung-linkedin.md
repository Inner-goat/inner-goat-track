---
type: wissen
tags: [academy, sales, marketing, personal-branding, linkedin, kundengewinnung, positionierung, zielgruppe]
reiter: Reiter 3 – Sales, Marketing & Personal Branding
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 0 – Einführung & LinkedIn

Dieses Einstiegsmodul aus Reiter 3 – Sales, Marketing & Personal Branding der [[Inner GOAT Academy]] legt das Fundament für planbare Kundengewinnung. Kernthese: Kundengewinnung ist keine Glückssache, sondern eine planbare Kompetenz — bestehend aus zwei Säulen: einem starken Angebot und der Fähigkeit, systematisch an Leads zu kommen und zu verkaufen. Das Modul führt in die Denkweise ein (Hebel, Klarheit über Angebot und Zielgruppe), baut den Kundenavatar auf und macht dann LinkedIn zum konkreten Kanal: Profil, Banner, Slogan, Content und Akquise.

Der rote Faden ist ein psychologisch aufgebautes System — von der ersten Nachricht bis zum Abschluss. Deshalb der Hinweis im Kurs: Lektionen der Reihe nach durcharbeiten, nicht springen. Thematisch verbindet sich das Modul eng mit [[Storytelling Wissen]]: Positionierung, Wahrnehmungssteuerung und "Menschen kaufen Bedeutungen" sind Storytelling-Prinzipien im Vertriebsgewand.

---

## 01 · Willkommen

Video-Lektion (Kurseinführung). Verortet die zentrale Schmerzfrage jedes Selbstständigen: "Woher bekomme ich den nächsten Kunden?" — der Gedanke, mit dem man morgens aufsteht und abends ins Bett geht. Es fehlt die **Planbarkeit**: die Sicherheit, genau zu wissen, was zu tun ist, um am Monatsende die Umsatzziele zu erreichen (Bild der Maschine: oben etwas reinstecken, unten kommt planbar etwas heraus).

**Kernaussagen:**
- Ziel eines Unternehmens ist Profitabilität — mehr einnehmen als ausgeben, und Geld verdient man durch neue Kunden.
- Der typische Anfängerfehler: ein gutes Angebot haben (Coach, Berater, Dienstleister, Copywriter, Webdesigner, Agentur), aber nicht wissen, wie man an Kunden kommt. Ein Angebot allein reicht nicht — es braucht die **zweite Säule**: Leads generieren und verkaufen können.
- Zu wenig Zeit fließt in Marketing und Vertrieb — erstens, weil unklar ist, was zu tun ist, zweitens wegen Umsetzungsblockaden. Genau diese beiden Themen adressiert der Kurs.
- Das System ist von der ersten Nachricht bis zur letzten Frage psychologisch aufgebaut → Schritt für Schritt durcharbeiten, nichts überspringen. Prinzip: "so viel wie nötig, so wenig wie möglich" — jedes Video hat einen Sinn.
- Der Kurs zeigt, wie man mit fremden Personen (und Personen im eigenen Netzwerk) systematisch vorgeht, bis sie sagen: "Mit dir will ich zusammenarbeiten."

**Wissensaufbau (A5 — Pitch & Marke):** Die größten Deals werden nicht im Meeting entschieden, sondern Monate davor. Der eigentliche Pitch passiert in ersten lockeren Gesprächen, im Auftreten und in dem, was du online teilst — im finalen Gespräch wird nur bestätigt, was Menschen längst über dich denken. (Vgl. [[Relevanz]] und Vertrauensaufbau vor dem Verkauf.)

**Community-Aufgabe:** Im Community-Chat teilen, was am Kurs am meisten freut und welches Ergebnis man sich für die nächsten Wochen vornimmt.

---

## 02 · In Hebeln denken

Video-Lektion mit einem zentralen Prinzip für Leben und Business: **in Hebeln denken**. Es gibt drei Hebel/Ressourcen, die man im Unternehmen betätigt:

1. **Energie** — die verfügbare Kraft
2. **Zeit** — die verfügbare Zeit
3. **Geld** — das verfügbare Kapital

Diese drei Ressourcen sollen so **effektiv** (die richtigen Dinge tun — die, die ans Ziel bringen) und so **effizient** (die richtigen Dinge richtig, schnell und mit wenig Aufwand tun) wie möglich eingesetzt werden.

**Kernidee:** Bevor man irgendeine Strategie fährt, prüfen — was ist gerade der *größte Hebel*? Wo muss ich am wenigsten Energie reinstecken, um das größte Ergebnis zu produzieren? Es gibt kein pauschales "richtig oder falsch" (Instagram, LinkedIn, TikTok, YouTube, Netzwerk) — Menschen sind individuell (Glaubenssätze, Prägung), ein System funktioniert nicht für jeden.

**Beispiele aus der Praxis:**
- Ein Videograph kaufte ein Instagram-Coaching, quälte sich sechs Monate mit Personal-Brand-Aufbau (obwohl er weder gern über sich schreibt noch gern auf Instagram ist) — kaum Fortschritt, starke Prokrastination. Lösung: Er hatte bereits einen Stamm von 40–50 Unternehmen. Eine Tabelle aufgestellt, alle angerufen — fünf buchten wieder → mehrfach fünfstelliger Umsatz in *einem* Monat. Der viel größere Hebel: alte Kunden reaktivieren statt bei Null Reichweite aufbauen.
- Marco selbst investierte in einer Kurzvideo-Trend-Phase Zeit + Geld (angestellte Person zum Schneiden), nach drei Monaten kaum Ergebnis. Dieselben Ressourcen in LinkedIn gesteckt hätten einen ganz anderen Hebel gehabt.
- Ein Kunde blockierte sich, weil ihm die einfache Netzwerk-Akquise "zu leicht" vorkam ("ich muss doch Social Media machen") — ein Blind Spot, der ihn ausbremste, bis er einfach weitermachte, was funktionierte, und wieder 20 Kunden gewann. → Selbstsabotage; Übergang ins Thema Mindset.

**LinkedIn als Hebel:** LinkedIn macht Kundengewinnung planbar und gibt **Kontrolle**. Man hat nie Kontrolle über den *Output*, aber immer über den *Input*. Weg vom "Hoffnungsmarketing" (Ads, Videos, Posts auf gut Glück) hin zu Planbarkeit und Sicherheit. Die Zielgruppe ist sehr wahrscheinlich auf LinkedIn und dort direkt targetierbar.

**Reflexion vor dem Start:** Wie habe ich die letzten fünf Kunden gewonnen? Was sind meine "low-hanging fruits" (Netzwerk, Ex-Kunden, Menschen, die die Leistung dringend brauchen, Empfehlungsgeber)? Welche Tätigkeit hat *jetzt* den größten Hebel?

**Wissensaufbau (A5 — Pitch & Marke):** Fokus heißt nicht weniger tun, sondern das Richtige mit maximaler Tiefe tun. Ein überzeugendes Produkt schlägt zehn mittelmäßige, ein klarer Kanal fünf halbherzige. Fokus fühlt sich nach Verzicht an, ist aber Konzentration von Kraft.

**Community-Aufgabe:** Analysieren, wie die letzten fünf Kunden gewonnen wurden — was war der größte Hebel, was brachte am wenigsten? Erkenntnis im Chat teilen.

---

## 03 · Klarheit über Angebot und Zielgruppe

Video-Lektion (kein klassisches Business-Coaching, kein Deep Dive — gezielte Sammlung der wichtigsten Klarheits-Aspekte). Prämisse: Die meisten haben bereits Angebot, Zielgruppe und Kunden. Doch **Angebot und Zielgruppe sind die komplette Basis des Business**. Wenig Reichweite, schwankende Umsätze oder Sales-Probleme liegen meist daran, dass man die Zielgruppe nicht gut genug kennt. Fehlt hier Klarheit, prokrastiniert man (man weiß nicht, wen man ansprechen soll).

**Vier Prinzipien für eine gute Zielgruppe:**
1. **Zahlungskräftig** — kann deine Preise bezahlen (sonst: Kaufreue, Absagen, Rechnungen hinterherlaufen, Stress).
2. **Wirklich helfen können** — du musst die Leistung beherrschen (nicht zwingend selbst durchlebt, aber echte Kompetenz) und ein Angebot haben, das die Zielgruppe braucht ("kein Eis am Nordpol verkaufen").
3. **Spaß an der Zielgruppe** — sonst fällt tägliche Arbeit schwer. (Nebenaspekt: manche Anfänger meiden erfolgreiche/selbstständige Kunden aus Angst, nicht weil sie keinen Spaß hätten.)
4. **Leicht zu erreichen** — sonst kostet allein die Lead-Suche zu viel Kraft. Steh für *eine* Sache, bleib der Nische treu.

**Zwei zentrale Fehler:**
- **Fehler 1 — Nicht für eine Sache bekannt:** weil man über alles postet (Copywriter postet Morgenroutine, Fitness-Leute posten Sales-Expertise). Man will für *eine* Sache bekannt sein. Beispiele: Kurtenchinese = Copywriting; die Bauligs = Business-Aufbau (nicht Fitness/Mindset). Kein Allrounder.
- **Fehler 2 — Denken, man kenne die Zielgruppe:** einer der größten Fehler. Selbst nach 100+ Kunden lernt man die Zielgruppe immer weiter kennen. Wer glaubt, sie nach zehn Kunden zu kennen, spricht die Bedürfnisse nicht präzise an — es zeigt sich in Kleinigkeiten, Nebensätzen, Empathie und Verständnis. Zielgruppe *immer weiter* kennenlernen.

Marco selbst brauchte fast zwei Jahre bis zu einer wirklich guten Positionierung und einem guten Angebot nach außen.

**Wissensaufbau (A4 — Personal Branding):** Positionierung als Magnetismus. Du bist nicht für alle da, sondern für eine bestimmte Art Mensch mit einem bestimmten Problem. Positionierung ist keine Einschränkung, sondern macht magnetisch — sie zieht genau die Menschen an, denen du am meisten helfen kannst.

**Begleitdokument (Kundenavatar — Vorlage):** siehe Lektion 04 (identisches Arbeitsblatt in drei Teilen — Kundenavatar / Symptome / Expertenavatar).

**Community-Aufgabe:** Kundenavatar und Symptom-Liste ausfüllen, drei Erkenntnisse über die Zielgruppe teilen.

---

## 04 · Kundenavatar

Video-Lektion zum wichtigsten Arbeitsblatt im Business — dem **Kundenavatar**. Wird nach *jedem* Call und Berührungspunkt gepflegt; bei Marco umfasst die PDF mittlerweile 4–5 Seiten. Aufbau in drei Teilen:

### Teil 1 — Kundenavatar (demografische Merkmale)
Geschlecht, Alter, Beziehungsstatus/Familie, Beruf, Einkommen (klar von *Umsatz* unterscheiden), Auto (verrät oft die Selbstinszenierung: Coaches fahren fürs Marketing größere Autos; wem Außenwirkung egal ist, fährt unscheinbar), Hobbys, Bücher, Freunde, Wochengestaltung/Leben außerhalb der Arbeit, Weiterbildung, alltägliche Sorgen.

### Teil 2 — Symptome (der wichtigste Teil)
Hier die Zielgruppen-Symptomatik **1:1** aus echten Kundenaussagen notieren (in Anführungszeichen, exakt der Wortlaut). Nicht unspezifisch ("hat Versicherung"), sondern konkret. Beispiel-Ausgangssituation: *"Ich bin seit 15 Jahren beim Versicherungsberater meines Vaters versichert und habe seit 8 Jahren nicht mehr in die Dokumente geschaut."* Punkt für Punkt sammeln — die gleichen Aussagen tauchen immer wieder auf, und jede Nische spricht ihre eigene Sprache.

Leitfragen:
- Was ist meine Nische? (z. B. Physiotherapeuten, Steuerberater, IT-Unternehmen)
- **Ausgangssituation** der Zielgruppe *vor* deiner Leistung? *(wichtig)*
- **Wunschsituation** der Zielgruppe? *(wichtig)*
- Welche Gedanken macht sich der Kunde abends im Bett? *(wichtig — nicht generisch "denkt ans Business", sondern konkret, z. B. "Muss ich wirklich 1.000 € im Monat für die Krankenkasse zahlen? Wie bin ich abgesichert, wenn ich nicht mehr arbeiten kann?")*
- Welche Sorgen löst du? Wie löst deine Dienstleistung sein größtes Problem?
- Was haben Kunden 1:1 über Ängste und Wünsche gesagt? *(wichtig)*
- Welche Aspekte seines Lebens sind für die Vermarktung ausschlaggebend? Was ist passiert (oder nicht passiert), dass er das jetzige Problem hat?
- Was ist ihm in der Zusammenarbeit wichtig, welche Werte/Vorbilder, worauf ist er wütend, welche Sprache/Analogien/Metaphern benutzt er?

Die "wichtigen" Fragen speisen direkt Marketing (Posts) und Sales-Gespräche — so entsteht das Gefühl: *"Diese Person kennt mich besser als ich mich selbst."*

### Teil 3 — Expertenavatar
Nicht nur *wie ist der Kunde*, sondern *von welcher Art Experte will er beraten werden*? Wie sieht in seinen Augen der optimale Berater aus?
- Was will die Zielgruppe in ihren Augen?
- Merkmale der Big Player im Markt — und wie reagiert die Zielgruppe darauf (konservativ vs. extrovertiert, viel Persönliches, Kleidungsstil: Pulli/Hemd/Anzug)?
- Welche Anbieter im Markt sind wirklich erfolgreich und was machen sie anders? — Nicht 1:1 kopieren, aber studieren, welche Aspekte funktionieren.

**Wissensaufbau (A4 — Personal Branding):** Menschen kaufen Bedeutungen, nicht Produkte. Kommuniziere nicht, *was* du tust, sondern *was es für den anderen bedeutet*. Der **Self-Reference Effect**: Je stärker sich jemand in deiner Botschaft wiederfindet, desto höher die Resonanz. Wer seine Zielgruppe besser kennt als sie sich selbst, baut das tiefste Vertrauen auf. (Vgl. [[Relevanz]].)

**Community-Aufgabe:** Kundenavatar ausfüllen, drei durch die Übung bewusst gewordene Erkenntnisse teilen.

---

## 05 · LinkedIn Einführung

Video-Lektion (Bildschirm-Demonstration) — Grundlagen-Checkup, wie LinkedIn aufgebaut ist und funktioniert. Vor allem für LinkedIn-Neulinge relevant.

**Navigation/Aufbau:** Start (Newsfeed mit Beiträgen der gefolgten Personen, dazwischen Ads), Netzwerk (Vernetzungsanfragen, Gruppen, vorgeschlagene Personen — oft potenzielle Kunden), Jobs, Nachrichten, Mitteilungen, eigenes Profil.

**LinkedIn-Varianten:**
- **Kostenlos** — nur ~10 Vernetzungsanfragen/Woche (nach LinkedIn-Update).
- **Premium** — *empfohlen*, weil die Routine 10–20 Vernetzungen/Tag vorsieht (gerade am Anfang bei wenig Followern).
- **Sales Navigator** — kein Muss; nur sinnvoll bei spezifischer B2B-/KMU-Nische; sonst findet man die Zielgruppe auch so. Bei Bedarf persönlich besprechen.

**Wichtige Profil-Elemente (im Detail in Lektion 07/08):**
- **Banner** — muss sofort zeigen, *warum* jemand auf dem Profil bleiben soll und *mit wem* du arbeitest (Marcos Beispiel: "50 % mehr Zeit pro Woche und konstante Umsatzsteigerungen"). Erstellung z. B. in **Canva** (Vorlage "LinkedIn-Hintergrundfoto"), max. ~60 Minuten investieren. *Show don't tell* — als Designer/Brand-Experte selbst ein starkes Ding zeigen.
- **Slogan** — die ersten ~6 Wörter erscheinen überall (auch in Vorschlägen); sie müssen catchy sein und Klickneugier erzeugen. Beispiele: *"Du brauchst keinen Coach, sondern Klarheit und Umsetzung"* (Positionierung *gegen* den Coaching-Boom); ein Finanzberater-Kunde: *"Der letzte Finanzberater deines Lebens, versprochen"*. Marco wird regelmäßig auf den Slogan angesprochen → direkter Gesprächseinstieg.
- **Info-Text** — kurze Erklärung, was du machst (lesen die wenigsten).
- **Im-Fokus-Bereich** — angepinnte Top-Posts, Testimonials, Beiträge mit den typischen Zielgruppen-Fragen (z. B. "Wie komme ich an den nächsten Kunden?") → Menschen klicken, vernetzen sich, nennen den Beitrag beim Erstkontakt.
- Berufserfahrung, Ausbildung, Kenntnisse, Empfehlungen (nice-to-have; Marco nutzt eher Trustpilot).

**Zielgruppe auf LinkedIn finden — drei Wege:**
1. **Vorgeschlagene Profile** (im Netzwerk/rechte Spalte) — oft Zielgruppen-nah; Profil prüfen (selbstständig? Business?) und vernetzen.
2. **Zielgruppenbesitzpartner** — Personen/Agenturen, die *dieselbe* Zielgruppe bedienen (z. B. als Fitness-Coach für Selbstständige mit Social-Media-Agenturen vernetzen, die ebenfalls Selbstständige betreuen). Über deren Follower/Liker findet man weitere passende Leute (die "1" = bereits vernetzt, "2" = noch nicht vernetzt zeigt an, wen man noch anschreiben kann). Nicht Kunden "klauen", sondern das Netzwerk weiter erschließen.
3. **Suche** — Begriff eingeben (z. B. "Copywriter", "Psychotherapeut") → Personen, Beiträge und Services. Auch spezifische Nischen lassen sich so gut finden.

Zusatz: Vernetzungsanfragen annehmen und *sofort* mit einer freundlichen ersten Nachricht reagieren (Details in Folgemodulen).

**Wissensaufbau (A4 — Personal Branding):** Personal Branding ist Identität, keine Show. Menschen folgen dir nicht, weil du laut bist, sondern weil du klar bist — klar in dem, wofür du stehst und wogegen. Deine Story beginnt nicht auf LinkedIn, sondern in dir. (Vgl. [[Der Bruch als Bauplan]] — Identität und Haltung vor Taktik.)

**Community-Aufgabe:** Profil optimieren (Banner, klarer Slogan, gepinnte Beiträge), Screenshot für Feedback teilen.

---

## 06 · Content und Akquise

Video-Lektion zur **Meta-Perspektive** der LinkedIn-Strategie. Kundengewinnung über LinkedIn ruht auf **zwei gleichwertigen Säulen**:

1. **Content** — baut Vertrauen und Reichweite bei der Zielgruppe auf.
2. **Nachrichten** — aktiver Kontakt zur Zielgruppe, bringt **Planbarkeit**.

Das eine ist nicht besser als das andere. Der verbreitete Irrglaube: "Ich poste nur ein paar Beiträge und die Wunschkunden kommen von selbst" = **Hoffnungsmarketing**. Das kann funktionieren, ist gerade am Anfang aber selten — selbst mit 10.000–20.000 Followern kommen Leute selten direkt zu, weil Vertrauen fehlt.

**Warum Content (Non-negotiable / Basis):**
- Ein leeres Profil + Kaltnachrichten wirkt nicht vertrauenswürdig. Besucher wollen Beiträge sehen, die *ihre* Probleme ansprechen → Identifikation. Häufige Folge: "Ich fand deine Beiträge interessant, deshalb vernetze ich mich" → direkter Gesprächseinstieg.
- **99 % sind stille Mitleser** (liken/kommentieren nicht, lesen aber). Ein Beitrag mit 5.000 Impressionen und 100 Likes wurde von weit mehr potenziellen Kunden gesehen, als es aussieht.
- **Mindset-Fehler "zu viel Mehrwert verraten":** Falsch. Viel Mehrwert hat *positive* Effekte:
  1. Baut **Vertrauen** (gerade bei Finanzen/Versicherungen essenziell).
  2. Baut **Expertenstatus**.
  3. Erzeugt die Frage: "Wenn er *umsonst* so viel gibt — wie geil ist dann erst das bezahlte Angebot?"

**Warum Nachrichten (aktives To-do, fast noch wichtiger):**
- Weil die stillen Mitleser aktiv angesprochen werden müssen und Vertrauen anfangs Zeit braucht.
- Nachrichten sind **kontrollierbar**. Man kann im Leben nur zwei Dinge zu 100 % kontrollieren: seine **Handlungen** und seine **Einstellungen**. Nachrichten = kontrollierbarer Input → Planbarkeit.

**Positive Aufwärtsspirale (dritter Grund fürs Zusammenspiel):** Tägliche Vernetzungen + wöchentliche Postings + Nachrichten + Kommentare (auch unter Zielgruppenbesitzpartner-Beiträgen) ziehen Aufmerksamkeit an → Leute sehen deine Kommentare, klicken aufs Profil, folgen, schreiben (oder du schreibst) → nächster Post, nächste Vernetzung. Diese Spirale so schnell wie möglich andrehen, aus dem Zusammenspiel von **Content und Nachrichten**.

*(Hinweis: Diese Lektion ist im Quell-Notion als Auftakt zu Modul 2 — Content gelabelt; sie schlägt inhaltlich die Brücke zwischen Grundlagen und der operativen LinkedIn-Arbeit.)*

**Community-Aufgabe:** (in der Quelle nicht separat ausgewiesen — Umsetzung: Content-Basis anlegen und die Nachrichten-Routine starten).

---

## 07 · LinkedIn Profil optimieren

Video-Lektion — nach dieser Lektion kannst du dein LinkedIn-Profil selbst erstellen, sodass es wie eine **Landing Page** und ein 24/7-Vertriebler wirkt (funktioniert voll aber nur mit gutem Content). Drei essenzielle Elemente: **Banner**, **Slogan**, **Infotext** (plus optional: Trust-Elemente, Link zum Erstgespräch, verbundenes Unternehmensprofil).

### Banner
Muss klar zeigen: **wen** du ansprichst, **welches Problem** du löst, **welches Ergebnis** die Zielgruppe erreicht.

Negativbeispiel (vorher): *"Sicherheit schaffen, nachhaltig Wachstum gestalten, unabhängig, transparent, menschenorientiert"* → leere Floskeln, keine Zielgruppenansprache, kein Ergebnisversprechen, viel Interpretationsspielraum.

Positivbeispiele (nachher) mit **Formeln**:
- *"Wir unterstützen Familien mit 80.000 € plus Haushaltseinkommen, ein Mehrvermögen von über 100.000 € aufzubauen."* → greifbare Zahlen, spezifische Zielgruppe, klares Versprechen.
- **Formel:** *Ziel erreichen und Schmerz lösen für Zielzustand 1 und Zielzustand 2* — z. B. "Plan bei Kundengewinnung und Blockaden lösen für konstant steigende Umsätze und mehr Lebensqualität."
- **Formel (mit Social Proof):** *Anzahl + Zielgruppe + mit Merkmal + dabei unterstützt, Ergebnis aufzubauen, ohne Schmerz* — z. B. "Wir haben über 150 Konzernangestellte mit 60.000 € plus Gehalt unterstützt, 100.000 € Mehrvermögen aufzubauen, ohne mehr Zeit zu investieren." Plus Trust-Zahlen (Bewertung 4,9, 1.153 zufriedene Kunden) und Team-Fotos.
- **Formel:** *Wir unterstützen [Zielgruppe] dabei, [Potenzial] zu nutzen, um [Wunschzustand] zu erreichen* — z. B. "…80.000 € plus Marken, über 47 % ihres Werbebudgets effizienter zu nutzen, um planbar profitabel zu wachsen."

**Must-have:** spezifische, erkennbare Zielgruppe + gelöstes Problem + erreichbares Ergebnis. **Optional:** erspürte Schmerzen, Trust-Beweise, individueller Lösungsweg. Zielzustände müssen die sein, die die Zielgruppe *wirklich* will. Nicht krampfhaft "anders sein" — bewährte Formeln nutzen.

### Slogan (Profilbeschreibung)
Die **Hook**, die überall (auch in Vorschlägen) sichtbar ist — wichtigste Chance herauszustechen. Marcos Slogan (seit ~3 Jahren): *"Du brauchst keinen Coach, sondern Klarheit und Umsetzung — 51 plus Selbstständige und Unternehmer zu mehr Zeit, Umsatz und Lebensqualität verholfen."* Gegen-den-Markt-Positionierung + **Pattern Interrupt** ("Wer ist das, dass er so etwas behauptet?") erzeugt Aufmerksamkeit und direkte Nachrichten.

- Negativbeispiel: bloße Aufzählung von Begriffen ("ungebundener Finanzmakler, Partner, Mentor, Ehemann, Papa") → vergleichbar, leer.
- Positiv (Transformation + Storytelling + Social Proof + Emotion): "Vom Versicherungskaufmann zum ungebundenen Finanzmakler mit 100+ köpfigem Team und 3.531+ zufriedenen Kunden, zweifacher Papa."
- **Formel:** *"Du brauchst keinen [Berufsbezeichnung], sondern [tiefen Wunsch]"* + Social Proof. Weiteres Beispiel: "Du brauchst weder mehr Produkte noch eine überteuerte Agentur, was du brauchst sind Produkte, die zu Bestsellern werden" — greift zwei verbreitete **Fehlannahmen** der Amazon-Seller-Zielgruppe auf.

### Infotext
Bewährte Struktur, zwei Möglichkeiten:
- **Möglichkeit 1 — Werbetext:** Probleme ansprechen → Folgen → Lösung → Ergebnisse. (Marcos Beispiel: viel arbeiten, Achterbahn der Motivation, Prokrastination, Gefühl blockiert zu sein → daraus Stress und liegengelassenes Potenzial → "oft nur kleine Hebel" → Ergebnisse: Leichtigkeit, mehr Zeit für Sport/Freunde/Familie, Struktur, Klarheit.)
- **Möglichkeit 2 — Storytelling:** Neugierde-Hook → Vorher (wie schlimm) → Wendepunkt → Heute ("im Himmel") → CTA. Keine ist besser — je nach Werdegang wählen. (Vgl. [[Der Bruch als Bauplan]] und [[Die 12 Plots]] — der Rebirth-Bogen als Profil-Narrativ.)

### Im-Fokus-Bereich
Z. B. Freebie (Lead-Magnet gegen E-Mail/Handynummer) **plus** Social Proof (Testimonials). Weitere Optionen: Link zum Erstgespräch, Best Practices, erfolgreiche Postings, Image- oder Erklärvideos.

**Wissensaufbau (A4 — Personal Branding):** Wahrnehmung schlägt Wahrheit. Menschen denken in Schubladen — gib ihnen deine Lieblings-Schublade selbst in die Hand. Wenn du nicht definierst, wie man dich sehen soll, tut es jemand anderes. Dein LinkedIn-Profil ist deine erste und stärkste Wahrnehmungssteuerung.

**Action Steps:** Banner (mit Formel), Slogan, Infotext und Im-Fokus-Bereich anpassen → dann Nachricht in die Gruppe für Feedback.

**Community-Aufgabe:** Profil nach den Formeln erstellen/überarbeiten, Screenshot für Feedback posten.

---

## 08 · LinkedIn Banner

Kurze Video-Lektion (Canva-Demonstration) zur praktischen Banner-Erstellung. Unter dem Video liegt ein **Link zur Canva-Vorlage** von Marcos aktuellem Banner.

**Schritte:**
1. In Canva: **Datei → Kopie erstellen** (nur die Kopie wird bearbeitet, das Original bleibt erhalten).
2. Für sich anpassen: Schriftart, Schriftgröße, Transparenz, Farben, eigenes Bild einfügen, Trustpilot-Element drin lassen oder entfernen.
3. **Nicht 1:1 kopieren** — vor allem die Farben ändern (der Verlauf lässt sich frei umgestalten, z. B. komplett schwarz oder mit farbigem Hintergrund). Insgesamt clean halten.
4. In Canva eingrooven, mit Elementen spielen — aber nicht zu viel Zeit verlieren.

**Zeitbudget:** ~20 Minuten (im Video), maximal 60 Minuten (Community-Aufgabe). Fokus soll auf den wichtigen Dingen (Content, Nachrichten) bleiben. Sobald das Profil steht → Bescheid geben.

**Wissensaufbau (A4 — Personal Branding):** Drei psychologische Wirkungshebel im Banner —
- **Social Proof** (andere vertrauen dir: Kundenzahlen, Bewertungen, Testimonials),
- **Autorität** (Fotos mit Speakern, Logos, Medienpräsenz),
- **Gleichheit** (Menschen mögen Menschen, die ihnen ähnlich sind — visuell und inhaltlich).

Alle drei lassen sich gezielt einbauen.

**Community-Aufgabe:** Banner in Canva nach der Vorlage erstellen, in der Community teilen (max. 60 Minuten Aufwand).

---

*Quelle: [[Inner GOAT Academy]] · Notion · Reiter 3 – Sales, Marketing & Personal Branding · Modul „Einführung & LinkedIn". Verwandt: [[Storytelling Wissen]], [[Der Bruch als Bauplan]], [[Die 12 Plots]], [[Relevanz]].*
