---
type: playbook
tags: [sales, akquise, skripte, kaltakquise, warmakquise, closing, bant, einwandbehandlung, founder-workspace]
quelle: Notion
erstellt: 2026-07-08
---

# Akquise & Skript-Bibliothek

Alle Verkaufs-Skripte und die Akquise-Strategie aus dem [[Founder Workspace V2]] als nutzbare Bausteine. Enthält: Akquise-Mindset + Daten-Beschaffung, BANT-Qualifizierung, Kalt- und Warmakquise-Telefonskripte, Mehrwert-Video-Template, Discovery- und Closing-Skript sowie die Einwandbehandlung. Skripte sind Vorlagen — in die eigene Stimme übersetzen und an Avatar + Positionierung ([[Sales Foundation]]) anpassen.

## Kontext & Anlass

Stammt aus der Notion-Seite "📞 Akquise & Skript-Bibliothek" (Inner GOAT Founder Workspace 2.0) samt allen Sub-Pages. Ergänzt für das Telefon-/Call-Handwerk den [[Outreach-Stil LinkedIn]] (schriftliche DMs) und den [[Kampagnen-Standard]] (E-Mail-Sequenzen). Der **Lead-Tracker** / **Sales-Tracker** und die **Sales Pipeline (Deals)-DB** leben als Tracker im laufenden Notion und werden hier nicht gespiegelt.

## Nutzung dieser Bibliothek

1. Zuerst die **Akquise-Strategie** lesen (Mindset + Daten + Sequenz).
2. Kanal wählen — **Kaltakquise** (gekaufte/recherchierte Adressen) oder **Warmakquise** (nach Mehrwert-Video).
3. Vor jedem Call das passende Skript einmal kurz durchgehen.
4. Nach dem Call Ergebnis im Lead-Tracker loggen (Conversion-Raten messbar machen).

## Akquise-Strategie (Kalt + Warm)

**Ziel:** 100–200 Kontaktpunkte pro Tag mit Menschen aus der Zielgruppe. Kanäle: Anruf · E-Mail · LinkedIn · Instagram.

### Mindset
- Der Weg funktioniert — es braucht nur genug aufgebautes Vertrauen.
- Kaltakquise ist ein **Zahlenspiel**.
- Drei Herausforderungen: (1) Kontaktdaten besorgen, (2) Aufmerksamkeit gewinnen, (3) Interesse wecken.
- **Verliebe dich in den Gegenwind** — es ist ein Skill für jeden Lebensbereich.
- Nicht Perfektion, sondern Korrekturen aus echten Ergebnissen.
- Kaltakquise lebt vom **Follow-Up** — mit jedem Lead gut auseinandergehen, um wieder anrufen zu können.

### Wie du an Daten kommst
1. **Scrapen** — Google-Suchen wie "outbound leads scraping tool", "Google Maps Scraper"; mehrere Tools testen, filtern, Stichprobe von ein paar Hundert kaufen, bei Erfolg mehr.
2. **Listen kaufen** — "Nummern & E-Mail-Liste kaufen"; mehrere List-Broker mit Zielgruppe anfragen, Beispielliste testen, bei Erfolg dabeibleiben.
3. **Manuell suchen** — bei mehr Zeit als Geld: Gruppen/Communities der Zielgruppe beitreten (mehr geben als nehmen), Unternehmen per Google finden, Kontaktdaten sammeln.

> **Bonus:** In Facebook-/LinkedIn-Gruppen sitzt die heißeste kalte Audience — sie sucht aktiv nach einer Lösung.

### Vorteile der Kaltakquise
Kein großer Content-/Ads-Aufwand · Wettbewerb sieht nichts · verlässlich (Zahlen lügen nicht) · weniger abhängig von Plattform-Richtlinien · schwer zu kopieren.

### Warmakquise-Sequenz (5–6 Tage)
Vor dem Anruf ein **Mehrwert-Video** oder eine Broschüre schicken → Vertrauen + Aufhänger.

- **Tag 1:** Mail inkl. Video · 1× Anruf
- **Tag 2:** 2× Anruf · Social-Media-Nachricht (LinkedIn/IG) mit Video-Link
- **Tag 3:** 2× Anruf · Follow-Up-Mail
- **Tag 5:** Follow-Up-Mail · 2× Anruf · Social-Media-Nachricht
- **Tag 6:** 2× Anruf · Follow-Up-Mail
- **Danach:** Pause; alle 30 Tage 2× hintereinander anrufen.

## BANT — Kundenqualifizierung

> Filter im **Discovery Call** und **Closing**. Faustregel: mindestens **3 von 4** BANT-Punkten müssen grün sein, bevor ein Angebot gemacht wird. Bei **N = rot immer disqualifizieren** — kein Pain, kein Sales.

### B — Budget
Fragen: *"Habt ihr für [Thema] bereits Budget eingeplant?"* · *"In welchem Rahmen bewegt sich das Budget?"* · *"Wann ist die nächste Budgetrunde?"* · *"Range — 5k, 25k, 100k+?"*
- Klare Zahl = grün · "müssten wir klären" = gelb · ausweichend/"kein Budget" = rot → Pain hinterfragen.
- **"Kein Budget" heißt oft "nicht genug Vertrauen / nicht genug Pain".**

### A — Autorität
Fragen: *"Wer ist in den Entscheidungsprozess eingebunden?"* · *"Hast du die Entscheidung in der Hand?"* · *"Gibt es Geschäftspartner, CFO, Beirat, Familie, die mitentscheiden?"*
- "Ich entscheide allein" = grün · Co-Decider nötig = gelb (Multi-Threading) · "Ich muss das vorlegen" = rot.
- **Profi-Tipp:** Co-Decider in den nächsten Call einladen ("dann sparen wir uns eine Runde") — senkt Drop-Off massiv.

### N — Need / Nutzen
Fragen: *"Was ist der größte Engpass, den du lösen würdest?"* · *"Was passiert, wenn ihr 3–6 Monate nichts ändert?"* · *"Wie viel Zeit/Geld/Energie kostet das Problem pro Monat?"*
- Konkreter akuter Pain + Zahlen = grün (Hot Lead) · "nice to have" = rot · klein geredet = gelb (Pain Digging) · emotional flach = gelb (Future Pacing).
- **Goldene Regel: Kein Pain = kein Verkauf.** Ohne Pain NICHT in die Angebotspräsentation.

### T — Timing / Timeline
Fragen: *"Bis wann willst du das gelöst haben?"* · *"Warum jetzt und nicht in 3 Monaten?"* · *"Gibt es einen externen Trigger (Quartalsende, Launch, Vertragsende)?"*
- Konkreter Termin/Trigger = grün · "sobald wie möglich" + Pain stimmt = grün · "in ein paar Monaten" = gelb · "wir schauen mal" = rot (Tire-Kicker).
- **"Später" ist oft NIE.**

### BANT-Score
- 4× grün → direkt in den Sales Call.
- 3× grün + 1× gelb → Schwachstelle adressieren, dann Sales Call.
- ≤ 2× grün → disqualifizieren oder Long-Term-Follow-Up (alle 30 Tage).
- N = rot → immer disqualifizieren.

## Kaltakquise-Opener (Telefon)

Für kalte Leads. **Cadence:** Tag 1 3× anrufen (optional LinkedIn-Anfrage + Mail), Tag 2 1×, Tag 3 1× (optional LinkedIn/Mail); danach alle 14–30 Tage 2× direkt hintereinander.

### Teil 1 — Assistenz / Empfang
> *"Hey, spreche ich da mit [Firmenname]? Ah perfekt, [Dein Name] hier… Ich weiß ehrlich gesagt nicht, ob ich gerade bei Ihnen richtig bin… Aber sind Sie verantwortlich für [Thema, z.B. Marketing] bei Ihnen im Haus?*
>
> *Ah okay… ich weiß gar nicht, ob das, was ich anbiete, richtig passend ist… Aber können Sie einschätzen, auf einer Skala von 1–10, wie gut [Thema] gerade läuft — 1 = bringt genau gar nichts, 10 = wir werden mit Neukunden überströmt…*
>
> *Okay verstehe… mit wem kann ich denn am besten ganz kurz darüber sprechen? Super — will [Entscheider] nicht lange in Anspruch nehmen, weil ich selbst gleich los muss… Stellen Sie mich am besten gerade mal durch, oder? Super, vielen Dank!"*

### Teil 2 — Entscheider
> *"Hey, spreche ich da mit ___? Ah perfekt, [Vorname] hier… Die [Assistenz] hat mich gerade zu Ihnen weitergeleitet… Ich weiß ehrlich gar nicht, ob wir in Ihrem Fall weiterhelfen können… Aber wir arbeiten mit ganz vielen [Zielgruppe] in Bezug auf ihr [Thema] zusammen…*
>
> *Kurze Frage: Auf einer Skala von 1–10, wie zufrieden sind Sie gerade damit, wie das [Thema] läuft — 1 = bringt gar nichts, 10 = mit Neukunden überströmt… Und was sind die fehlenden Punkte?*
>
> *Letzte Frage: Rein theoretisch, wir könnten genau das lösen — wären Sie offen, dass wir mal unseren Lösungsansatz zeigen, oder sagen Sie 'auf gar keinen Fall, es soll so weiterlaufen wie bisher' 😀*
>
> *Super — ich würde mir heute Nachmittag oder morgen früh 15 Minuten freischaufeln, damit Sie mir mehr über sich und das Unternehmen erzählen. Dann gibt es 2 Alternativen: Alt. 1 — ich merke, wir können sehr gut helfen. Alt. 2 — wir können gar nicht helfen, dann connecte ich Sie ggf. mit jemandem aus meinem Netzwerk. Hört sich das fair an?*
>
> *Passt es besser um __ Uhr oder um __ Uhr? Auf welche E-Mail-Adresse soll ich die Einladung schicken? Bekommen? Dann bestätigen Sie sie gern. Dann bis nachher um ___ Uhr."*

**Kern-Techniken:** Skala-Trick (1–10) senkt die Verteidigung · Wahlfreiheit geben (Alternative 1 vs. 2) · locker statt aufdringlich.

## Mehrwert-Video-Template (vor Warmakquise)

Video, das **vor** dem Warmakquise-Anruf an den Lead geht. 10-teilige Skript-Outline:
1. **Hook** — *"Sie sind [Zielgruppe] und fragen sich, wie Sie [Ziel X] erreichen? Sie haben [Problem 1] und [Problem 2]?"*
2. **Fehlannahmen entlarven** — *"Sie denken vielleicht [Fehlannahme 1/2]. Doch dann kennen Sie das Geheimnis noch nicht."*
3. **Was sie bisher versucht haben** — *"Sie haben schon [Angebot] versucht, aber das Wichtigste bleibt aus — [Ziel X]."*
4. **Die 4 typischen Fehler** — *"Die meisten scheitern an [Fehler 1–4]."*
5. **Reframe** — *"Sie brauchen nicht die nächste Agentur, sondern eine individuell auf SIE angepasste Strategie."*
6. **Selbstvorstellung** — *"Hi, ich bin [Name], [Beruf] spezialisiert auf [Branche], seit [X] Jahren mit [Anzahl] Kunden."*
7. **Das Geheimnis (Insight)** — *"Das Geheimnis liegt nicht darin, dass [Fehlannahme], sondern weil Sie [Tatsache]."*
8. **3-Step-Lösung** — Step 1/2/3, am Ende minimaler Zeitinvest.
9. **Social Proof** — Kunde X, Kunde Y mit Ergebnissen einblenden.
10. **CTA** — Einladung zum unverbindlichen Strategiegespräch.

## Warmakquise-Skript (Anruf nach Mehrwert-Video)

Ziel: Pre-Qualifizierung + Termin fürs Strategiegespräch.

**Part 1 — Aufhänger:** *"Hey [Vorname], hier ist [Name]. Du hast vor einigen Tagen unser Video zum Thema [XYZ] erhalten, richtig? Wir machen dazu immer kurze Feedback-Calls — hattest du die Möglichkeit reinzuschauen?"* (Bei "nicht erhalten": nachfassen ob Mitarbeiter, dann *"Ist das Thema [XYZ] für Sie interessant?"*)

**Part 2 — Pre-Qualifizierung:** *"Dann nehme ich an, wie bei anderen [Branche] hat das Thema auch bei Ihnen noch Potenzial — oder sind Sie was [Thema] angeht auf einer 10/10? Was sind die entscheidenden Punkte, um auf 10/10 zu sein?"* → hinterfragen. Dann kurze Selbstvorstellung + Angebot: *"Wir bieten gerade kostenfreie Strategiegespräche an … das ist kein Verkaufsgespräch — Sie könnten Ihre Kreditkarte in die Kamera halten und nichts kaufen. Reiner Mehrwertcall. Hast du Bock, dass wir uns zusammensetzen?"*

**Termin (Funnel-Technik):** Tag → Tageszeit → Uhrzeit. *"Passt es morgen oder übermorgen? Eher vormittags oder nachmittags? [XX] Uhr oder [XX] Uhr?"* Jede Frage schränkt ein und schafft Verbindlichkeit.

**Bei Ablehnung:** Skala-Technik + kognitive Dissonanz ("was, wenn es ein Jahr so weitergeht?"). **Falls nicht Zielgruppe:** ehrlich absagen ("wäre Zeitverschwendung").

## Kennenlerncall / Discovery-Skript

Ziel: **Vertrauen aufbauen, Mehrwert geben, Sales Call als logischen nächsten Schritt setten.**

1. **Smalltalk** — Eis brechen.
2. **Kunde vorstellen lassen + Infos sammeln** — was ist ihm wichtig (Geld? Umsatz? Freiheit?). *"[Name], wir kennen uns ja von LinkedIn … erzähl mal genauer: Was genau machst du?"*
3. **Selbstvorstellung mit Positionierung** — kurz, an die Werte des Gegenübers angepasst, Expertenstatus + kurze Story ("Daseinsberechtigung").
4. **Agenda setzen** — Frame: *"Ich mache dir heute kein Angebot und verkaufe nichts. Wenn du am Ende sagst 'das war der Hammer, ich will mehr', terminieren wir einen 2. Call."* Alternativ Austausch-Frame mit Pain-Fragen (Reverse Psychology): zwei typische Pains nennen und *"Kommt dir das bekannt vor, oder hast du damit keine Herausforderungen?"*
5. **Mehrwert geben** — nur zu **einer** Sache echten Mehrwert + AHA-Momente, nicht das ganze Business umkrempeln.
6. **Cliffhänger + Sales Call setten** — *"Hat dir das Gespräch weitergeholfen?"* (klares JA) → *"Stell dir vor, du hättest so ein Meeting 1-2× pro Woche über 4 Monate — wie würde sich das auswirken?"* → *"Kannst du dir vorstellen, dass wir die nächsten X Monate zusammenarbeiten?"*
7. **Termin festlegen** — 2. Gespräch innerhalb 2–3 Tagen ("damit die Infos frisch sind"), Frame Pain Island → Dream Island.
8. **Optional letzter Touchpoint** — auf Website/YouTube/LinkedIn/Kundenstimmen verweisen.

## Sales-Skript (Closing-Call) — 12 Schritte

Zweitgespräch nach erfolgreichem Discovery; Angebot präsentieren und abschließen.

1. **Agenda setzen** — Ablauf erklären, Micro-Commitments sammeln, klares JA holen. Wer sich nicht führen lässt: disqualifizieren.
2. **Öffnen** — *"Was hast du aus unserem letzten Call mitnehmen können?"*
3. **Bedarfsergründung** — Engpass-Frage → Vertiefung ("was liegt dir noch auf dem Herzen?") → primäres Kaufmotiv (unklare Begriffe immer hinterfragen) → **Pain Digging** ("wie wirkt sich das auf andere Lebensbereiche aus? Was macht das mit dir?").
4. **Wunschzustand** — konkrete Ziel-Frage + **Future Pacing** ("stell dir vor, du erreichst [Ziel] — wie wirkt sich das aus?").
5. **Die Lücke** — IST- vs. Wunsch-Situation spiegeln; *"Was ist der ausschlaggebende Grund, warum du noch nicht da bist?"* (Selbsterkenntnis: er schafft es nicht allein) + *"Warum jetzt und nicht in 3 Monaten?"* (Commitment).
6. **Perfekte Lösung** — *"Wie muss die Zusammenarbeit im Idealfall aussehen, damit du dein Ziel zu 100% erreichst?"* → Werte-Technik: Bedarf spiegeln + Micro-Commitment einholen.
7. **(Optional) Bedarfserweckung** — offene Checkliste mit Nutzenargumenten abfragen.
8. **Kaufbereitschaftstest / Vorabschluss** — *"Mal angenommen, ich erfülle die Punkte zu deiner Zufriedenheit — bist du dann an Bord?"* Kein JA → *"Was brauchst du noch, damit wir heute starten?"* → Einwandbehandlung oder disqualifizieren.
9. **Angebotspräsentation** — 3 Säulen, wichtigste zuerst. Nach jeder Säule: *"Fragen? Wie hört sich das an? Wie profitierst du davon?"*
10. **Vorabschluss** — Moralischer Vorvertrag (*"Bist du überzeugt, dass du damit dein Ziel erreichst?"*) → Reverse Psychology (*"Was macht dich so sicher?"* — er verkauft es sich selbst) → *"Jetzt ist es nicht mehr die Frage OB, sondern nur noch WIE — korrekt?"*
11. **Endgültiger Abschluss** — Preis nennen: *"Die Zusammenarbeit über [X] Monate liegt bei [X] € netto zzgl. MwSt. bei Ratenzahlung und [X] € netto bei Einmalzahlung. Welche Option ist für dich die beste?"*
12. **After Sale — MUND HALTEN.** Nach dem Kauf nicht weiterreden, nur Infos holen (Name, Anschrift, Kontodaten), Onboarding-Termin festlegen.

## Einwandbehandlung — die 4 Techniken

> Die ausführliche **Einwandbehandlung-DB** (8 Standard-Einwände wie "Ich habe kein Geld", "Ich möchte später starten") lebt als Tracker im laufenden Notion.

- **Schalentechnik** — *"Gibt es neben [XYZ] noch einen weiteren Grund, der gegen eine Zusammenarbeit spricht?"* (schält verdeckte Einwände frei).
- **Klarheitstechnik** — *"Was genau brauchst du, dass du der 100%igen Überzeugung bist, dass du dein Problem ein für alle Mal löst?"*
- **Werte-Technik** — *"Dir ist also wichtig, dass zusätzlich [XYZ] gegeben ist, damit [Ziel] erreicht wird — richtig?"*
- **Voraussetzungstechnik** — *"Mal angenommen, wir können [XYZ] gewährleisten — legen wir dann los?"* (klares JA →) Angebot + Zusatz nennen.

## Anwendung

- Skripte an [[Sales Foundation]] (Positionierung, Avatar, Angebot) anpassen.
- Schriftliches Cold-Outreach folgt dem [[Outreach-Stil LinkedIn]]; automatisierte E-Mail-Ketten dem [[Kampagnen-Standard]].
- Vertieft in der [[Inner GOAT Academy]] (Reiter 3 — Kundenakquise & Kundenabschluss).

## Verwandte Notizen

- [[Sales Foundation]]
- [[Content-Templates (Social)]]
- [[Outreach-Stil LinkedIn]]
- [[Kampagnen-Standard]]
- [[Inner GOAT Academy]]
- [[Founder Workspace V2]]
