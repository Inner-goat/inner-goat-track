---
type: playbook
tags: [video, content, creator, guidelines, inner-goat]
quelle: Notion
erstellt: 2026-07-08
---

# INNER GOAT — Video-Guidelines

Der Fahrplan, den Creator bekommen, wenn sie ein Video für [[Inner GOAT]] beisteuern. Reichweite: tausende Gründer:innen direkt über WhatsApp, Telegram und E-Mail. (Original-Deadline im Onboarding-Fall: 11. August — Inner GOAT macht das Marketing kostenlos, zählt dafür auf die Zuverlässigkeit der Creator.)

## Schritt 1 — Rubrik wählen

- **IMPULS (45–60 Sek.)** — Deine Haltung. Dein Mindset. Ein Satz, der wachrüttelt.
- **DEEP DIVE (2–3 Min.)** — Klarer Mehrwert aus deiner Expertise, z. B. Sales, Branding, Cap Table.
- **TRUE STORY (3 Min.)** — Echtes Erlebnis. Was du gelernt hast. Was du weitergeben willst.

## Schritt 2 — So nimmst du auf

- Hochformat (9:16), Handy ab iPhone 11 oder vergleichbar
- Enthusiastische und freundliche Art
- Gute Audio- & Lichtqualität (Fensterlicht, ruhiger Raum). Beim Laufen aufnehmen geht auch, wenn man dich gut hören kann.
- Struktur: Starte mit einer **Hook**, dann Inhalt, dann **Call to Action**
- Der Zuschauer soll etwas mitnehmen und JETZT konkret umsetzen. Wir wollen die Leute mutiger machen — gib am Schluss eine klare Handlungsanweisung.
- Sei persönlich. Kein Skript nötig. Wir schneiden.

## Schritt 3 — Danach

- Video im Google-Drive-Ordner hochladen. Dateiname: `Vorname_Nachname_Rubrik_Titel.mp4`
- Man darf sich im Drive-Ordner inspirieren lassen — aber trotzdem den eigenen, individuellen Schuh fahren.
- Kurze Mail senden, damit klar ist: Video ist hochgeladen.
- Nach Eingang folgt eine Nutzungserklärung zum Unterschreiben (kommt im nächsten Schritt).

## Was der Creator bekommt

- Schnitt & Branding des Videos
- Veröffentlichung auf WhatsApp, LinkedIn, Website
- Expertenprofil im Creator Pool
- Option auf Affiliate-Link & Events

*Für alle, die mit ihrer Geschichte Gründer:innen bewegen wollen.*

## Kontakt

- Fragen an: marco@inner-goat.de
- Kurzer Call: calendly.com/marco-0704/q-a-mit-marco

## Verwandt

- [[Branding]] · [[Reel-Skripte (Beispiele)]] · [[Hook-Bibliothek]]
- [[Inner GOAT]] · [[Storytelling Wissen]]
