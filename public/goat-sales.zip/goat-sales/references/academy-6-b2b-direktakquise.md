---
type: wissen
tags: [academy, sales, akquise, kaltakquise, warmakquise, b2b, cold-calling, direktakquise]
reiter: Reiter 3 – Sales, Marketing & Personal Branding
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 6 – B2B Direktakquise

Dieses Modul der [[Inner GOAT Academy]] behandelt die B2B-Direktakquise als Königsdisziplin des Vertriebs: das aktive, direkte Ansprechen von Wunschkunden per Anruf, E-Mail, LinkedIn und Instagram. Es unterscheidet zwei Wege — die **Kaltakquise** (kalter Erstkontakt) und die **Warmakquise** (Mehrwert-Impuls zuerst, dann Anruf) — und liefert für beide fertige, anpassbare Leitfäden inklusive Telefonskripten und einer Mehrwert-Video-Vorlage.

Kernbotschaft über alle Lektionen hinweg: Akquise ist ein **Zahlenspiel**, das vom **Follow-Up** lebt. Nicht Perfektion, sondern Wiederholung und Iteration führen zur Meisterschaft. Wer diesen Skill knackt, wächst nicht nur im Business, sondern als Persönlichkeit — abgehärtet gegen Ablehnung, stärker in Kommunikation und Grenzsetzung. Das Modul verbindet damit direkt Marcos Signature-Thema [[Der Bruch als Bauplan]]: sich in den Gegenwind verlieben und den Bruch (die Ablehnung) als Baustein nutzen.

---

## 01 · Akquise-Einführung

Einführungsvideo, das die Landschaft der Direktakquise aufspannt und das nötige Mindset setzt.

**Ziel:** 100–200 Kontaktpunkte pro Tag mit Menschen aus der Zielgruppe schaffen. Kontaktwege: **Anruf, E-Mail, LinkedIn, Instagram** (Instagram nur in wenigen Fällen sinnvoll, z. B. Hotels/Restaurants).

**Mindset (Kernaussagen):**
- Der Weg funktioniert — es geht nur darum, genug **Vertrauen** aufzubauen. Kaltakquise ist ein absolutes **Zahlenspiel**.
- Kaltakquise ist die Königsdisziplin: Wer sie eine Zeit lang durchzieht, verliert die Angst vor Ablehnung und wächst als Persönlichkeit (Kommunikation, Grenzen setzen, Menschen verstehen). Zahlt sich auch privat aus.
- **In den Gegenwind verlieben**, es als Spiel sehen, Spaß haben. Prinzip: Ergebnis produzieren → Erkenntnis ziehen → Korrektur → besseres Ergebnis. Nicht perfekt sein — schnell viele Ergebnisse produzieren. (Vgl. [[Der Bruch als Bauplan]].)

**Die 3 Herausforderungen, die gelöst werden müssen:**
1. Du kannst sie nicht kontaktieren, weil du ihre Kontaktdaten nicht hast.
2. Selbst wenn du kontaktierst, ignorieren sie dich.
3. Selbst wenn sie Aufmerksamkeit geben, haben sie kein Interesse.

**Merksatz:** Kaltakquise lebt vom **Follow-Up**. Immer so auseinandergehen, dass der Lead nicht verbrannt wird — du willst immer wieder anrufen können. „Direkt beim ersten Anruf den Willen zu erwarten ist, als würdest du einen Fremden fragen, ob er dich heiraten will.“

### Wie wir an Daten kommen
- **Scrapen:** Google nach „outbound leads scraping tool", „database lead scraping", „Google Maps Scraper" (gut für Restaurants/Hotels). In mehreren Plattformen eintragen (oft kostenloser Probemonat), nach Kriterien suchen, ein paar hundert repräsentative Kontakte testen — wenn Daten aktuell sind und die Leads passen: mehr kaufen.
- **Liste kaufen:** Nach „Nummern & E-Mail-Liste kaufen" googeln, mehrere List-Broker um Beispiellisten bitten, diese testen, bei gutem Ergebnis dabei bleiben. Meist teurerer Ansatz.
- **Manuell suchen** (wenn mehr Zeit als Geld): Gruppen/Communities beitreten, Unternehmen googeln, über LinkedIn Sales Navigator Listen bauen. In Communities gilt: mehr geben als nehmen.
- **Bonus:** In Gruppen (z. B. Facebook) findet sich die „heißeste kalte Audience" — Menschen, die aktiv nach einem Problem suchen.

### Vorteile der Kaltakquise
- Wenig Content/Ads nötig (nur Bonus).
- Der Wettbewerb sieht nicht, was du tust — schwer zu kopieren.
- Verlässlich: Zahlen lügen nicht.
- Weniger Plattform-Änderungen und Richtlinien als bei Social Media.

Am Ende steht der Übergang zur **Warmakquise** (Video, Broschüre oder Mail zuerst) und zum konkreten Leitfaden. Grundausstattung dafür: Kontaktliste (Mails + Telefon + Firmendaten), E-Mail-Verteiler (z. B. Instantly), Video oder Broschüre.

**Follow-Up-Prozedere (aus dem Begleitdokument):**

| Tag | Aktionen |
|-----|----------|
| Tag 1 | Mail inkl. Video + Anruf |
| Tag 2 | 2× Anrufen + Nachricht auf Social Media (LinkedIn/IG mit Video-Link) |
| Tag 3 | 2× Anrufen + Follow-Up-Mail |
| Tag 5 | Follow-Up-Mail + 2× Anrufen + Social-Media-Nachricht |
| Tag 6 | 2× Anrufen + Follow-Up-Mail |

---

## 02 · Leitfaden Kaltakquise

Das konkrete Skript für Cold Calls, um einen Discovery-/Qualifizierungs-Call zu setten — der sogenannte **Opener-Call**. Kommt zum Einsatz, wenn Adressen gekauft oder über LinkedIn gefunden wurden. Die Abfolge wird befolgt, bis der Lead erreicht ist (ist er terminiert, wird der Rest abgebrochen).

### Anruf-Abfolge
- **Tag 1:** 3× anrufen (über den Tag verteilt); optional LinkedIn-Anfrage inkl. Nachricht (nach dem 1. Anruf); E-Mail (nach dem 3. Anruf).
- **Tag 2:** 1× anrufen.
- **Tag 3:** 1× anrufen; optional LinkedIn-Nachricht; E-Mail (nach dem 1. Anruf).
- **Danach alle 30 Tage** (14 Tage auch möglich): 2× anrufen (direkt hintereinander).

### Telefonskript — Kern-Technik
Das Skript nutzt bewusst die **„verwirrter-Opa"-Technik**: durch eine leicht hilflose Tonalität („Ich weiß ehrlich gesagt nicht, ob ich gerade bei Ihnen richtig bin…") entsteht beim Prospect der Impuls, helfen zu wollen — man lehnt ihn nicht ab.

**Gespräch mit Assistenz/Empfang:**
- „Spreche ich da mit [Firmenname]? … [Dein Name] hier. Ich weiß ehrlich gesagt nicht, ob ich richtig bin — aber sind Sie verantwortlich für [Thema, z. B. Marketing] im Haus?"
- Skalenfrage: „Können Sie einschätzen, auf einer Skala von 1–10, wie gut [Thema] läuft? 1 = bringt gar nichts, 10 = wir werden mit Neukunden überströmt."
- „Mit wem kann ich am besten kurz darüber sprechen? … Will [Entscheider] gar nicht lange in Anspruch nehmen, ich muss selbst gleich los — stellen Sie mich einfach durch, oder?" (Ergänzung möglich: Direktnummer erfragen, falls Entscheider nicht im Haus.)

**Gespräch mit dem Entscheider:**
- „[Dein Vorname] hier, die [Assistenz] hat mich weitergeleitet. Ich weiß gar nicht, ob wir in Ihrem Fall weiterhelfen können — aber wir arbeiten mit vielen [Zielgruppe] rund um [Thema]."
- **Skalenfrage** wiederholen (1–10 Zufriedenheit) → „Was sind die fehlenden Punkte?" (typische Antwort 5/6/7). Die Antwort weiter hinterfragen — es läuft fast immer auf **Neukunden** oder **Mitarbeiter** hinaus; dann dort erneut die Skala ansetzen.
- **Übertreibungs-Frage (kognitive Dissonanz):** „Rein theoretisch, wir könnten genau das Problem lösen — wären Sie offen, dass wir unseren Lösungsansatz zeigen, oder sagen Sie ‚Auf gar keinen Fall, ich will, dass es so bleibt wie bisher 😀'?"
- **Termin-Setzung mit 2 Alternativen:** „Ich schaufle 15 Minuten frei. Dann gibt es zwei Alternativen: (1) Ich merke, wir können sehr gut helfen. (2) Wir können gar nicht helfen — dann connecte ich Sie ggf. mit jemandem aus meinem Netzwerk. Hört sich das fair an?"
- **Terminierung:** „Passt es besser um *** oder um *** Uhr? … Auf welche E-Mail schicke ich die Einladung? … Bestätigen Sie sie gern. … Dann stelle ich sicher, dass ich im Büro bin — da kann nichts dazwischenkommen, oder?"

**Vorgehen:** Skript zuerst aufs eigene Business anpassen, dann **hoch und runter auswendig lernen**, antesten und iterieren. Einwände variieren von Nische zu Nische, sind aber meist ähnlich (3–5 wiederkehrende) — das Skript wird daran verfeinert. Vgl. Prinzip [[Der Bruch als Bauplan]]: Schritt für Schritt entsteht Meisterschaft, nicht beim ersten Call.

---

## 03 · Warmakquise

Konzeptvideo zur Abgrenzung der Warmakquise von der Kaltakquise. Der Unterschied: Bevor du anrufst, schickst du der Firma **zuerst** einen Mehrwert-Impuls (Video, Mail oder Broschüre) — das erhöht die Gesprächsbereitschaft massiv. „People buy from people": Erst geben, dann nehmen. (Verwandt mit [[Relevanz]] und dem Multi-Touch-Prinzip.)

**Was du brauchst:**

| Element | Details |
|---------|---------|
| Kontaktliste | E-Mail + Telefonnummer + Firmendaten (wie bei Kaltakquise) |
| E-Mail-Verteiler | z. B. Instantly — für automatisierten Versand der Sequenz |
| Video oder Broschüre | Empfehlung: mit **Video** starten (günstiger, persönlicher). LinkedIn-Loom-Strategie funktioniert ebenfalls sehr gut. |

**Die Warmakquise-Sequenz:**

| Tag | Aktionen |
|-----|----------|
| Tag 1 | E-Mail mit Video (morgens raus) → Anruf am Nachmittag |
| Tag 2 | 2× Anruf + Social-Media-Nachricht (Instagram/LinkedIn) mit Link |
| Tag 3 | 2× Anruf + Follow-Up-Mail |
| Tag 5 | Follow-Up-Mail + 2× Anruf + Social-Media-Nachricht (Follow-Up) |
| Tag 6 | 2× Anruf + Follow-Up-Mail |

**Wichtig:** Beim Warmakquise-Anruf wird **nicht** das Kaltakquise-Skript verwendet — da die Person bereits Mail/Video erhalten hat, ist der Einstieg anders (das genaue Skript folgt in Lektion 04). **Merksatz:** Multi-Touch gewinnt. Wer sieht, liest, hört — und dann angerufen wird — ist deutlich offener als bei kaltem Anruf.

---

## 04 · Leitfaden Warmakquise

Das vollständige Warm-Call-Skript. Kommt zum Einsatz, wenn zuvor ein Video/eine Broschüre verschickt wurde oder Leads sich über Ads eingetragen und ein VSL/Report gesehen haben. Der Vorteil: Es gibt immer einen **Aufhänger** (den bereits erfolgten Kontaktpunkt).

### PART 1 — Aufhänger zum Anruf
- „Hey [Vorname], hier ist [Name]. Schönen guten Morgen/Mittag/Abend erstmal!" → abwarten.
- „Du hast vor einigen Tagen unser Video zum Thema XYZ erhalten, ist das richtig?"
- **Ja, erhalten:** „Wir machen dahingehend immer kurze Feedback-Calls! Hattest du schon die Möglichkeit reinzuschauen?" → Feedback einholen → **weiter zum Pre-Quali-Skript (Part 2)**. (Am Versand-Tool sieht man meist, ob das Video angesehen wurde.)
- **Nein/nicht erhalten:** „Oh, sind Sie sicher? Es hat jemand das Video ‚[Thema]' angesehen, das wir an [E-Mail] rausgeschickt haben — das wollte ich persönlich bestätigen lassen. Waren Sie das nicht selbst?" → „War es vielleicht einer Ihrer Mitarbeiter?" Egal welche Antwort → Frage: „Ist das Thema [Thema] für Sie derzeit interessant?"
  - Interessant: „Ah, das trifft sich ja doch." (*hooked*) → direkt Part 2.
  - Nicht interessant: trotzdem weiter zu Part 2, nur etwas anders formuliert (den Einwand leicht überhören).

### PART 2 — Pre-Qualifizierung des Leads
- „Danke für das Feedback. Dann nehme ich an, wie bei anderen [Firmen aus Branche] hat [Thema] auch bei Ihnen noch Potenzial — oder sind Sie auf einer absoluten 10/10 und werden [übertriebenes Ziel] nie ein Problem damit haben?"
- „Was sind die entscheidenden Punkte, um bei [Thema] auf einer 10/10 zu sein?" → **Antwort hinterfragen.**
- **Pitch-Übergang:** „Bevor Sie sich fragen, welche fremde Person hier seit X Minuten mit Ihnen spricht — kurz zu uns: Wir sind spezialisiert auf [Angebot] für [Branche] und erreichen dabei [Ziel X]. Wir bieten gerade kostenfreie Strategiegespräche an, wo wir Ihre Situation in der Tiefe anschauen und individuell angepasst eine Strategie entwickeln. Das ist **kein Verkaufsgespräch** — Sie könnten Ihre Kreditkarte in die Kamera halten und nichts kaufen, es ist ein reiner Mehrwert-Call. Haben Sie Lust, dass wir uns zusammensetzen?"
- **Terminierung:** „Wir machen sowas immer zeitnah — wann passt es heute oder morgen?"

### Termin vereinbaren (Trichter-Fragen)
„Passt es besser MORGEN oder ÜBERMORGEN?" → „Eher Vormittags oder Nachmittags?" → „XX Uhr oder XX Uhr?" → Einladung schicken. **Am Termin geht es mit dem Discovery-Skript weiter.**

### Bei Ablehnung
Einwandbehandlung mit **Skala-Technik** und **kognitiver Dissonanz**. Einwände systematisch sammeln (es sind meist 3–5 wiederkehrende) und das Skript daran erweitern.

### Falls NICHT Zielgruppe
Ehrliche Verabschiedung: „Wir sind [Agentur/Beratung] für [Zielgruppe] und spezialisiert auf [Thema]. Da Ihr Angebot nichts direkt damit zu tun hat, wäre das für Sie wahrscheinlich Zeitverschwendung." → Nummer aus dem CRM nehmen.

**Vorgehen:** Skript auf Angebot, Branche und Wording anpassen, ausfüllen, testen und **kontinuierlich iterieren**.

---

## 05 · Leitfaden Mehrwert-Video

Vorlage für das **Mehrwert-Video**, das in der Warmakquise vor dem Anruf verschickt wird — besonders sinnvoll für Gastronomie, Restaurants, Hotels, Fitnessstudios und Handwerksbetriebe. Ziel: Probleme im Herzen des Kunden treffen, Vertrauen aufbauen, einen Aufhänger für den Anruf schaffen und im Idealfall Inbound-Leads erzeugen (Menschen tragen sich ein). Prinzip: nicht das Angebot erklären, sondern die **Bedeutung** für den Kunden treffen — die Probleme, nicht die Features. (Vgl. [[Relevanz]], [[Storytelling Wissen]].)

**Aufbau des Mehrwert-Videos (fettgedruckte Platzhalter selbst füllen):**

1. **Problem-Hook:** „Sie sind [Zielgruppe] und fragen sich, wie Sie [Ziel X] erreichen? Sie haben [Problem 1] und [Problem 2]?"
2. **Fehlannahmen benennen:** „Sie denken jetzt … [Fehlannahme 1] … [Fehlannahme 2]. Doch dann kennen Sie immer noch nicht das Geheimnis, weswegen andere Anbieter [Ziel X] haben."
3. **Bisherige Versuche entkräften:** „Sie haben eventuell schon über [Angebot, z. B. Social Media] nachgedacht oder selbst gestartet — aber am Ende bleibt das Wichtigste aus: [Ziel X]."
4. **Fehler auflisten:** „Die meisten scheitern daran, dass … [Fehler 1–4]."
5. **Reframe:** „Sie brauchen nicht die nächste Agentur mit [Versprechen], sondern eine individuell auf SIE angepasste Strategie, um [Ziel X] ohne [Problem] zu erreichen. Genau dafür habe ich die Lösung."
6. **Vorstellung + Autorität:** „Hi, mein Name ist [Name], ich bin [Beruf] spezialisiert auf [Branche] und habe in den letzten X Jahren mit [Anzahl] Kunden individuelle Strategien entwickelt, um durch [Angebot] [Ziel X] zu erreichen. Das Geheimnis liegt nicht darin, dass [Fehlannahme], sondern weil [Tatsache]." (*Content/Bilder einblenden.*)
7. **3-Schritte-Lösung:** „Das erreichen wir in 3 simplen Steps: Step 1 – [Konsequenz], Step 2 – [Konsequenz], Step 3 – so, dass Sie am Ende nicht nur [Ziel X] haben, sondern nur minimalen Zeitinvest."
8. **Proof:** „Genau so wie bei unserem Kunden [Kunde X] … oder [Kunde Y]." (*Content/Bilder einblenden.*)
9. **Call-to-Action:** „Wenn das auch für Sie das Richtige ist und Sie wissen wollen, wie so eine Strategie individuell auf Ihr Unternehmen zugeschnitten wird, lassen Sie uns das in einem unverbindlichen Strategiegespräch besprechen. Ich freue mich, Sie persönlich kennenzulernen."

**Vorgehen:** Vorlage aufs eigene Angebot anpassen, ausfüllen, Feedback einholen, dann das Video aufnehmen. Laut Modul einer der **wertvollsten Schritte** des Moduls.

---

*Verwandte Notizen: [[Inner GOAT Academy]] · [[Storytelling Wissen]] · [[Der Bruch als Bauplan]] · [[Relevanz]]*
