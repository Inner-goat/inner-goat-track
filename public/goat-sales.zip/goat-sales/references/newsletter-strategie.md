---
type: playbook
tags: [newsletter, email, sequenzen, funnel, resend, inner-goat]
quelle: Notion
erstellt: 2026-07-08
---

# Newsletter-Master-Strategie

Die komplette E-Mail-Sequenz-Architektur von [[Inner GOAT]]: fünf automatisierte Sequenzen, die Cold Traffic von drei Einstiegspunkten in [[Inner GOAT Academy]], [[Storybuilder Cards]] und Beratung überführen. Stand: 12. Mai 2026 — alle Sequenzen LIVE. Domain inner-goat.com bei Resend verifiziert (DKIM/SPF/DMARC ✅). Ergänzt den [[Kampagnen-Standard]].

## Strategischer Überblick

Zwei Hauptprodukte, drei Einstiegspunkte für Cold Traffic:
- **Academy** (Hauptprodukt, 2.500 € · Founder-Programm 6 Monate)
- **Storybuilder Cards/Pro** (79 € / 199 €)
- **Storytelling-Beratung** (Premium 1:1, 997 €) — Cross-sell für beide

Zwei Zielgruppen → zwei getrennte Newsletter mit eigener Voice und eigenem Conversion-Pfad:

| Eingang | Profil | Hauptinteresse |
|---|---|---|
| inner-goat.com (Hauptseite) | Founder allgemein, Solo-Gründer, Coach | Academy + Inner-GOAT-Methode |
| storytelling-app/ + Quiz | Storytelling-Interessierte | Cards / Pro / Beratung |

**Konsequenz:** Cross-Erwähnung nur in 1–2 Mails pro Sequenz für Tertiär-Awareness.

## Touchpoint-Map (Funnel)

- **Hauptseite** → GOAT-Founder-Sequenz (source `wordpress_startseite_h10`)
- **Cards-Seite** → Storybuilder-Newsletter (source `wordpress_storybuilder_inline`)
- **Quiz** → Quiz-Lead-Sequenz (Lead-Capture nach Quiz)
- **Stripe-Kauf Cards** → Cards-Customer-Onboarding · **Stripe-Kauf Pro** → Pro-Customer-Onboarding
- **Source-Routing im Cron:** `wordpress_storybuilder_*` → Storybuilder-Sequenz, sonst → GOAT-Founder-Sequenz
- **Unsubscribe (irgendeine Mail)** stoppt ALLE Sequenzen für diese E-Mail

## Alle Sequenzen — Status

| # | Sequenz | Trigger | Mails | Frequenz | Status |
|---|---|---|---|---|---|
| 1 | GOAT-Founder-Newsletter | Form Hauptseite | 8 | Day 1/8/15/22/29/36/43/50 | ✅ LIVE |
| 2 | Storybuilder-Newsletter | Form Cards-Seite | 8 | Day 1/8/15/22/29/36/43/50 | ✅ LIVE |
| 3 | Quiz-Lead-Sequenz | Quiz + Email | 5 | Day 0/2/4/7/11 | ✅ LIVE |
| 4 | Cards-Customer-Onboarding | Stripe tier=cards | 5 | Day 3/7/14/21/30 | ✅ LIVE |
| 5 | Pro-Customer-Onboarding | Stripe tier=pro | 5 | Day 2/5/10/20/30 | ✅ LIVE |

**Transactional (kein Marketing, kein Unsubscribe):** Welcome-Mail (nach Cards/Pro-Kauf, sofort, mit Login-Link), Magic-Link (Re-Login), DOI-Bestätigung (Newsletter-Anmeldung).

## GOAT-Founder-Newsletter — Mail-Reihenfolge

**Zielgruppe:** Solo-Founder, Coaches, Berater · DACH · Hauptseiten-Besucher. **Ziel:** Academy (2.500 €). **Voice:** Marco + Nel, gemeinsam, sachlich, founder-zu-founder, ehrlich.

| # | Tag | Subject | Funktion | Pitch? |
|---|---|---|---|---|
| 1 | T+1 | Geschichten erzählen ist die wichtigste Fähigkeit der Zukunft. | Welcome + Story-Manifest | nein |
| 2 | T+8 | Warum wir Inner GOAT gegründet haben. | Origin-Story (Nel + Marco) | nein (Podcast-Verweis) |
| 3 | T+15 | Die innere Ziege, die in dir wohnt. | Methode/Philosophie · 3 Prinzipien | nein |
| 4 | T+22 | 6 Monate Programm, die wir uns selbst gewünscht hätten. | Academy soft-launch | leise (Academy-Link) |
| 5 | T+29 | Storytelling ist Sales. Nicht andersrum. | Storytelling-Hebel im B2B-Sales | mittel (Cards 79 €) |
| 6 | T+36 | Was wir in 8 Jahren Beratung über Marken gelernt haben. | Academy-Kostprobe, 3 Marken-Fehler | mittel (Academy) |
| 7 | T+43 | Die 3 Fragen, die deine Sales-Story trägt. | Praxis-Mail, konkret anwendbar | leise (Beratung) |
| 8 | T+50 | Letzte Mail. Drei Wege weiter. | Final-CTA | hart (Academy + Beratung + Newsletter bleibt) |

## Storybuilder-Newsletter — Mail-Reihenfolge

**Zielgruppe:** Cards-Seite-Besucher, die noch nicht kaufen. **Ziel:** Cards (79 €), Pro (199 €), Beratung.

| # | Tag | Subject | Funktion |
|---|---|---|---|
| 1 | T+1 | Du wurdest erzählt — wahrscheinlich falsch. | Welcome + Storytelling-Hebel |
| 2 | T+8 | Warum dein ChatGPT-Post niemanden bewegt. | Methode vs. KI |
| 3 | T+15 | Jede gute Story hat einen Drachen. | Drache & Stadt vorstellen |
| 4 | T+22 | Ich hab dir etwas gebaut. 79 €. | Cards Soft-Pitch |
| 5 | T+29 | 40 % mehr Marge — wie eine Beraterin das geschafft hat. | Helena-Case-Study |
| 6 | T+36 | Wenn du es ernst meinst: dein Personal-Branding-Dokument. | Pro-Pitch + Beratung als Alternative |
| 7 | T+43 | Bevor du kaufst: 3 Fragen an dich. | Anti-Sales-Filter |
| 8 | T+50 | Letztes Mail. Und ein anderes Angebot. | Final-CTA |

## Quiz-Lead- & Customer-Sequenzen

- **Quiz-Lead (5 Mails):** Day 0 Ergebnis → Day 2 Schatten → Day 4 DNA-Probe + Pro-Pitch → Day 7 letzter Pitch + Beratung → Day 11 50-€-Rabatt + drei Wege.
- **Cards-Customer (5 Mails):** Day 0 Welcome → Day 3 erste Story-Aktivierung → Day 7 Feedback-Aufforderung (Sprechblase-Icon) → Day 14 Stellschrauben-Tipps → Day 21 Pro-Upsell + DNA-Probe → Day 30 drei Wege weiter.
- **Pro-Customer (5 Mails):** Day 0 Welcome → Day 2 Persönlichkeitstest → Day 5 Status-Check + Reply-Aufforderung → Day 10 Story-DNA-Hebel → Day 20 Anwendung im Alltag + Beratung → Day 30 letzte Mail + Beratungs-Einladung.

## Tech-Stack

| Komponente | Tool / Service | Status |
|---|---|---|
| Sender | Resend | ✅ verifiziert, sending enabled |
| Domain | inner-goat.com | ✅ DKIM + SPF + DMARC verified |
| Database | Supabase (`newsletter_subscribers`, `users`, `leads`, `marketing_consents`) | ✅ Live, Migrationen 0006 + 0007 |
| Hosting | Vercel | ✅ Production, Cron täglich 10:00 UTC |
| Frontend | WordPress (Custom-HTML-Blöcke v2 / v13) | ✅ eingefügt |
| Stripe-Coupon | `CARDS120` (-79 €) für Cards→Pro | ✅ Live, im Pro-Payment-Link aktiviert |
| Unsubscribe | HMAC-SHA256, stoppt alle 4 Sequenzen | ✅ DSGVO-konform |

## Conversion-Best-Practices 2026

**Richtig gemacht:** 5–8-Mail-Welcome-Series (→ 50 %+ Lifetime-Revenue) · Plain-Text statt Heavy-HTML (B2B) · Subject 5–9 Wörter, kein Clickbait · Value:Pitch = 3:1 · erste Mail < 24h · Segmentierung nach Source (bringt 760 % mehr Revenue) · 1-Klick-Unsubscribe · Founder-led Content (Marco + Nel als Absender) · Reply-to = persönliche Adresse (info@inner-goat.com) · DKIM/SPF/DMARC.

**Noch optimierbar:** Open-/Click-Tracking aktivieren · A/B-Test Subject-Lines (+15 % Open) · Re-Engagement nach 60 Tagen · Behavior-Trigger (Mail nicht geöffnet → Verzweigung) · Personalisierung jenseits `{{vorname}}` (Branche, Source) · Käufer per Behavior-Exit aus Newsletter-Sequenz raus.

**Explizit NICHT:** Heavy HTML mit Bildern · mehr als 1 CTA pro Mail · generische Anrede („Hi Stranger") · manuelles Versand-Marketing parallel zu Sequenzen (2× Mails/Tag → Unsubscribe).

## KPIs · Ziel-Werte

| Metrik | Quelle | Ziel |
|---|---|---|
| Open-Rate | Resend | 28–45 % |
| Click-Rate | Resend | 6–9 % (Welcome 35–50 %) |
| Reply-Rate Mail 1 | Inbox | 2–5 % |
| Conversion → Cards | Stripe + UTM | 2–4 % der Subs |
| Conversion → Pro | Stripe + UTM | 0,5–1,5 % der Subs |
| Beratungs-Anfragen | Inbox | 3–10 / 1.000 Subs |
| Unsubscribe-Rate / Mail | Supabase | < 2 % |

## Verwandt

- [[Kampagnen-Standard]] · [[Storybuilder Cards]] · [[Inner GOAT Academy]]
- [[Branding]] · [[Inner GOAT]] · [[GOAT Flows]]
