---
type: wissen
tags: [academy, content, linkedin, copywriting, personal-branding, storytelling, sales]
reiter: Reiter 3 – Sales, Marketing & Personal Branding
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 2 – Content

Dieses Modul ist eines der wichtigsten der gesamten [[Inner GOAT Academy]]. Es zeigt, wie du durch Content sichtbar wirst, Authority aufbaust und dafür sorgst, dass Kunden auf dich zukommen – statt ständig kalt akquirieren zu müssen. Der rote Faden: Content ist die effizienteste und skalierbarste Akquise-Strategie. Sie funktioniert aber nur, wenn du die Psychologie dahinter verstehst (Kaufentscheidungen sind emotional), deine Zielgruppe in- und auswendig kennst (Bewusstseinsstufen + Kundenavatar), starke Hooks schreibst (80 % der Wirkung) und konsistent ein System fährst statt auf Charisma und Laune zu setzen.

Die 16 Lektionen bauen aufeinander auf: erst die Fundamente und die Psychologie, dann Zielgruppen-Verständnis und Ideenfindung, danach die konkreten Content-Formate (Experten-Posts, Storytelling, Slide-Posts, Copywriting-Formeln), schließlich die Automatisierung per KI-Bot, eine Selfcheck-Checkliste und der Umsetzungsplan. Roter Bezug zum [[Storytelling Wissen]] und Marcos Signature-Winkel [[Der Bruch als Bauplan]]: Die stärksten Posts erzählen echte Transformationen – nicht perfekte Fassaden.

---

## 01 · Basics

Einstieg ins Content-Modul und die Begründung, warum Content überhaupt.

**Das Problem der meisten Selbstständigen:** Sie sind unsichtbar, potenzielle Kunden kennen sie nicht, sie müssen ständig kalt akquirieren, und ihr Wachstum ist durch ihre Zeit begrenzt.

**Die Lösung Content:** Wenn du hochwertige Inhalte produzierst, finden Menschen dich, du wirst zur Authority, Kunden kommen auf dich zu und Verkaufen wird leicht.

**Die Content-Wahrheit:** Es gibt tausende kostenlose Tipps online, aber nur ~1 % der Menschen setzt sie um – weil sie Content von einer echten Person mit Ausstrahlung und Authentizität brauchen. Du kannst diese Person sein.

**Die vier Basis-Prinzipien:**
1. **Authentizität** – Menschen folgen Menschen, nicht Marken. Zeige deine echte Persönlichkeit und Transformation. Das ist dein USP, den niemand kopieren kann.
2. **Value First** – Gib zuerst. 80 % kostenlose Insights, nur 20 % verkaufen. Vertrauen ist die Grundlage jedes Verkaufs.
3. **Konsistenz** – Ein Post pro Woche über Monate schlägt zehn Posts in einem Monat und dann Funkstille. Konstanz schlägt Sporadisches. Immer.
4. **System statt Charisma** – Content-Erstellung muss ein planbares, wiederholbares System sein, das nicht von der Tageslaune abhängt. (Der zentrale Punkt des Autors.)

**Die vier Phasen der Content-Reise:** Phase 1 Basics · Phase 2 Strategie (Themen, Zielgruppe, Formate, Kalender) · Phase 3 Produktion (effizient erstellen, Templates, Content-Batching) · Phase 4 Distribution (Reichweite, Engagement, Community).

**Erste Aufgabe:** (1) Für **eine** Plattform entscheiden (LinkedIn = B2B/professionell, X = schneller Thought Leadership, TikTok/Reels = visuell). (2) Thema definieren (Schnittmenge aus „Was kannst du besser lehren als 99 %?" und „Was will deine Zielgruppe lernen?"). (3) Andere Creator in der Nische beobachten. (4) Eigenen Style finden (humorvoll, ernst, erzählend, inspirierend) – nur durchs Anfangen.

*Community-Aufgabe:* Ersten LinkedIn-Beitrag der Woche schreiben, mindestens eines der vier Prinzipien anwenden, Entwurf in den nächsten Copywriting-Call bringen.

---

## 02 · Psychologie hinter Content der verkauft

Kernlektion mit der Psychologie hinter Content, der konvertiert. 90 % der Postings auf Social Media sind irrelevant – genau das wollen wir vermeiden.

**Prinzip 1 – Content ist eine unsichtbare Reise.** Jeder Beitrag führt den Leser Schritt für Schritt: Der Scrollstopper (vor allem die Hook, idealerweise plus Bild) fängt die Aufmerksamkeit. Dann verkauft jede Zeile die nächste Zeile. Erst am Ende der Reise denkt der Leser an eine Handlung (Like, Kommentar, DM, Speichern, Teilen, CTA).

**Prinzip 2 – Menschen kaufen aus Emotion und rechtfertigen mit Logik.** Jede Kaufentscheidung beginnt mit einem Gefühl (Wunsch, Angst, Hoffnung, Schmerz, Begeisterung, Interesse). Erst danach sucht das Gehirn logische Gründe zur Legitimation. Beispiel Schuhkauf: Begeisterung/Anerkennung löst aus, danach kommt die Rechtfertigung („Investment in mich"). Für Content heißt das: **zuerst emotional auslösen, dann rational nachschieben.** Content muss Resonanz erzeugen („Das fühle ich", inneres Nicken), nicht nur informieren.

Wichtig ist Spezifität: „Wie du Glaubenssätze auflöst" holt niemanden ab. „Du hast als selbstständiger Agenturinhaber ständig das Gefühl, nicht gut genug zu sein und noch mehr leisten zu müssen" trifft. Vgl. [[Relevanz]].

**Die 7 Kernemotionen für verkaufsstarken Content:** Schmerz (weg vom Problem) · Hoffnung (hin zum besseren Zustand) · Angst (Schlechtes verhindern) · Ehrgeiz/Stolz (wachsen, anerkannt werden) · Zugehörigkeit/Gemeinschaft (Teil von etwas sein, nicht allein) · Sicherheit/Stabilität · Neugier (Neues lernen, Chancen entdecken).

**Umsetzung im Post:** Schmerz präzise auf Symptomebene beschreiben (Fitness-Beispiel: Fahrstuhl kaputt, zwei Stockwerke hoch, außer Atem, die Frau verdreht die Augen) – dafür braucht es die Sprache der Zielgruppe (→ [[#04 · Dein Kundenavatar ist dein bester Freund]]). Hoffnung erzeugen mit realistischen Perspektiven, keine leeren Versprechen. Statt „Es ist wichtig, regelmäßig Akquise zu machen" lieber: „Es gibt zwei Arten von Selbstständigen: die einen haben volle Konten, die anderen volle To-do-Listen."

**Merksatz:** Ein starker Post funktioniert wie ein kleiner Verkaufsprozess – emotional einfangen, Problem/Sehnsucht verstärken, rational belegen, in Bewegung bringen.

---

## 03 · Die verschiedenen Bewusstseinsstufen

Warum Bewusstseinsstufen entscheidend sind: Nicht jeder sieht die Welt wie du. Menschen auf LinkedIn sind in ganz unterschiedlichen Phasen; Content wirkt nur, wenn er die aktuelle Denk- und Fühlwelt trifft. Der Nutzen ist doppelt – für Content **und** für Sales-/Discovery-Calls, um die Person richtig abzuholen.

**Die 5 klassischen Bewusstseinsstufen (nach Eugene Schwartz):**

1. **Unaware (unbewusst)** – Die Person weiß nicht, dass sie ein Problem hat, lebt im Status Quo. Content-Ansatz: Bewusstsein schaffen, sanft auf Probleme hinweisen. Beispiele: „Viele IT-Angestellte glauben, ihr Gehalt allein sichert ihre Zukunft. Leider ein Irrtum." / „Warum selbst Top-Produkte oft scheitern – und es nicht an der Qualität liegt."
2. **Problembewusst** – Spürt den Schmerz, weiß aber nicht, was sie braucht. Content-Ansatz: Problem klar benennen, Folgen sichtbar machen. Beispiel: „Wenn deine Landingpage Leser nicht festhält, verlierst du jeden Monat Umsatz, bevor der Verkauf überhaupt beginnt."
3. **Lösungsbewusst** – Sucht schon Wege/Optionen, ist offen, wie genau. Content-Ansatz: Vorteile der Lösung erklären, Orientierung bieten. Beispiel: „Warum Conversion Copywriting 3x mehr Leads generiert als klassisches Werbetexten."
4. **Produktbewusst** – Kennt dein Angebot und dich, wägt ab, ob du die richtige Wahl bist. Content-Ansatz: Vertrauen stärken (Testimonials), Einwände vorwegnehmen. Beispiel: „Warum Unternehmen wie … mit meiner Copy ihre Leadkosten halbieren konnten."
5. **Kaufbereit** – Kennt und vertraut dir, überlegt konkret zu handeln. Content-Ansatz: sanfte Erinnerung, klarer Handlungsimpuls / CTA (z. B. „Noch zwei Slots frei").

**Praxis:** Pro Woche mindestens einen Post pro Stufe planen. In Sales-Calls die Stufe des Leads einordnen und den passenden Impuls geben – bei einem lösungsbewussten Lead kein Grund-Problembewusstsein mehr wecken, sondern direkt Lösung liefern. Siehe auch [[Relevanz]] und [[#04 · Dein Kundenavatar ist dein bester Freund]].

---

## 04 · Dein Kundenavatar ist dein bester Freund

Warum der Kundenavatar dein wichtigstes Content-Werkzeug ist: Er ist nicht nur für Sales relevant, sondern die Grundlage für jeden starken Post. Der Autor zeigt sein eigenes, über vier Jahre gewachsenes Avatar-Dokument (Demografie mit Ranges, Charaktereigenschaften, derzeitige und gewünschte Situation).

**So nutzt du den Avatar für Content:**
1. **Fehlannahmen als Content-Ideen** – Jeder klassische Glaubenssatz der Zielgruppe ist ein fertiger Post. Beispiel: „Ich brauche größere Ziele, die mich motivieren" → Post, der genau diesen Glaubenssatz aufgreift und widerlegt.
2. **Klassische Aussagen als Hooks** – Die wörtlichen O-Töne der Kunden eins zu eins als Hook nutzen: „Ich habe den ganzen Tag was gemacht, aber nicht das Gefühl, als wäre was vorangegangen." / „Ich befinde mich im Kreisverkehr – ich sehe, wo ich hin will, finde aber nicht die Ausfahrt." / „Ich sage mir, in 5 Minuten fange ich an – und versacke dann doch am Handy."
3. **Ängste und Sorgen konkretisieren** – Angst vor Ablehnung/Verantwortung/Scham, Zukunftsängste, Selbstzweifel; aus Erfahrung schreiben, nicht aus Theorie.
4. **Avatar im Sales-Gespräch nutzen** – Sagt ein Interessent „Ich bin einfach faul", weißt du dank Avatar: Das ist kein Faulheitsproblem, sondern fehlendes Lösungs-/Problembewusstsein. Du kannst nachfragen und verstärken („Da ist so eine unsichtbare Kraft, die dich zurückzieht") → die Person fühlt sich verstanden, Verbindung entsteht.

**Kern-Disziplin:** Nach **jedem** Discovery-, Sales- oder Kundengespräch sofort neue Aussagen, Ängste und Fehlannahmen ins Avatar-Dokument einpflegen. Je lebendiger das Dokument, desto stärker Content und Vertrieb (auch Gold wert für spätere Ads).

---

## 05 · Contentideen finden

Grundsatz: Die besten Content-Ideen liegen bereits in deinem Alltag – du musst sie nur erkennen und systematisch sichern.

**Die 5 schnellsten Quellen:**
1. **Kundenfragen** – Was fragen dich Kunden am häufigsten? Jede Frage aus einer Session/einem Call = mindestens ein Post (Schmerz triggern + kurze Lösung).
2. **Eigene Fehler / Learnings** – Was hast du falsch gemacht und daraus gelernt? Was hat dir wirklich weitergeholfen? Menschen lieben und spüren echte Erfahrungen. (→ Storytelling.)
3. **Branchen-Mythen** – Was glauben viele fälschlich? („Mehr Reichweite = mehr Umsatz", „Weniger essen = abnehmen", „Ich bin durch die Rente abgesichert".) Fünf Mythen aufschreiben, je einen Post daraus machen.
4. **Kommentare und Gespräche** – Reaktionen auf Posts, DMs, Discovery-/Sales-Calls. Jede Diskussion = Content-Gold; Aussagen zusätzlich ins Avatar übertragen.
5. **Trigger-Fragen** – „Was wünschte ich, hätte ich früher gewusst?" · „Was würde ich meinem besten Freund raten?" · „Was hält meine Zielgruppe nachts wach?" · „Welches Verhalten sehe ich immer wieder?" (Verhaltensebene statt abstrakter Sachlichkeit; Beispiel: „leasen ein Auto für 800 €, können sich aber keine 200 € Sparrate leisten").

**Übung:** 10 Probleme der Zielgruppe aufschreiben, je zwei Posts (Was ist das Problem? Warum tritt es auf? Wie fühlt es sich an? Was ist die Lösung?).

**Wichtigster Tipp – Ideen sofort notieren:** Kreativer Teil und Umsetzungsteil des Gehirns sind selten gleichzeitig aktiv. Ideen kommen beim Nichtstun (Gym, Spazieren). Immer Apple Notes / Trello griffbereit haben: Ein Gedanke ist ein potenzieller Post.

---

## 06 · Endless Contentideen

Praxislektion mit einem fertigen ChatGPT-/Claude-Prompt, mit dem nie wieder Ideenmangel herrscht. Der Autor führt live vor, wie er den Prompt am Beispiel einer Social-Media-Agentur (Meta-Ads für Coaches, done-for-you) befüllt.

**Der Prompt (aus dem Begleitdokument, Klammern anpassen):**

> Du bist ein erfahrener LinkedIn-Content-Experte. Deine Aufgabe ist es, mir als **[Berufsbezeichnung]** Contentideen zu liefern, die perfekt zu meiner Zielgruppe passen: **[Zielgruppe beschreiben]**.
>
> Ich biete folgende Dienstleistung an: **[kurze, knackige Beschreibung]**
>
> Ziele meines Contents: Expertenstatus aufbauen · Vertrauen & Nähe erzeugen · Nachfrage auslösen · qualifizierte Anfragen gewinnen · Mehrwert liefern.
>
> Bitte gib mir: 15 Contentideen in unterschiedlichen Formaten (Storytelling, How-to, Pain-Pleasure, Meinung, Trigger, Learnings); zu jeder Idee eine kurze Beschreibung + Ziel; gerne auch polarisierende/aufmerksamkeitsstarke Vorschläge.
>
> Bonus: 3 Ideen speziell für Content, der gut in DMs weiterverwendbar ist (Bedarfserzeugung / Gesprächseinstieg).

Der Output liefert sofort brauchbare Ideen (Storytelling-Kundenreisen, How-to, Meinung „Warum organisches Marketing allein nicht mehr reicht", Trigger, Pain-to-Pleasure) plus DM-taugliche Formate (Mythos-Test, Wunschzustand-Visualisierung als Gesprächseinstieg). Für die eigene Nische alle Felder anpassen.

---

## 07 · Wichtige Prinzipien für Personal Brand

Vorab-Einordnung: Der Fokus des Programms ist nicht, die perfekte Personal Brand zu bauen – die Brand entsteht nebenbei, macht aber Sales und Outreach deutlich leichter. Vgl. [[Outreach-Stil LinkedIn]].

**Warum eine Personal Brand auf LinkedIn unverzichtbar ist:** Menschen folgen Menschen, nicht Unternehmen (Beispiel Tesla/Elon Musk – eine Haltung zieht an oder stößt ab). Vertrauen entsteht über Persönlichkeit, nicht über das Angebot. Eine starke Brand entscheidet, ob du überhaupt als Lösung wahrgenommen wirst, erlaubt höhere Preise ohne Rechtfertigung und hebt dich aus der Masse.

**Drei Ebenen der Brand:** Sichtbarkeit (durch Content) · Nachfrage (Expertise + Bedarf) · Vertrauen (konsistentes, authentisches Auftreten). Die Schnittmenge = deine Brand.

**Die 5 Grundprinzipien:**
1. **Klarheit** – Wer bist du, wem hilfst du, wobei konkret? In einem Satz verständlich. „Ich helfe IT-Fachkräften, ihre Finanzen intelligent aufzubauen" statt „irgendwas mit Finanzen". Slogan und Banner entsprechend.
2. **Konsistenz** – Eine Themenwelt; für **eine** Sache bekannt sein (Beispiel „Stefan Park = Copywriting"). Nicht über zig Themen posten. Name + Tätigkeit verknüpfen, ähnliche Tonalität, regelmäßige Präsenz (unregelmäßiges Posten wirkt unseriös).
3. **Relevanz** – Ego-Content interessiert niemanden. Über Themen der Zielgruppe sprechen; erklären, warum **du** die richtige Person bist (Transformation, Hero-Story). Relevanz entsteht durch Perspektivwechsel und die Sprache der Zielgruppe. Siehe [[Relevanz]].
4. **Authentizität** – Ecken und Kanten, Werte und Haltung zeigen (Clarity Sheet). Überzeugungen ziehen an und stoßen ab – das macht magnetisch. Nicht jedem gefallen wollen. Aber auch nicht ins Opfer-/Heul-Extrem rutschen.
5. **Verbindung** – Auf eigene Kommentare reagieren (pusht Algorithmus), bei anderen die eigene Meinung kommentieren (nicht nur „Toller Beitrag"), fremde Meinungen nicht persönlich nehmen (eine Meinung ist Interpretation, kein Fakt).

**Häufige Fehler:** Zu viel Nabelschau (Ich-Ich-Ich) · zu wenig Konsistenz (Themen-Springen) · Angst, Haltung zu zeigen (People Pleaser) · zu fachlich, zu wenig emotionale Resonanz · Ungeduld beim Brand-Aufbau (Dranbleiben ist das Wichtigste). Bezug zu [[Der Bruch als Bauplan]]: „Deine Story beginnt nicht auf LinkedIn, sondern in dir."

---

## 08 · 80% ist die Hook

Kurzlektion mit einer klaren Ansage: Die Hook ist ~80 % des Erfolgs. Egal ob Video, Slideshow oder Text-Post – ohne starke Hook keine Verweildauer, kein Reichweitenboost, keine Chance, die Botschaft zu transportieren. Empfehlung: erst die Hook denken/schreiben, dann den Beitrag. Investiere 80 % deiner Schreibzeit in die Hook.

**Merkmale einer starken Hook:** emotionaler Reiz (löst sofort Neugier, Angst, Hoffnung, Widerspruch aus) · Klarheit (in 1–2 Sekunden verständlich, kein Rätsel) · Kontrast/Überraschung (bricht eine Erwartung; „Breaking Hooks", z. B. der Reverse-Twist „Gar nichts habe ich daraus gelernt") · optionale Provokation (mehr Aufmerksamkeit) · Visualität (inneres Bild) · Dringlichkeit („Was passiert mit deinem Business, wenn LinkedIn morgen offline geht?").

**Typische Fehler:** zu weich/allgemein („Hier ein paar Gedanken …") · zu langatmig („Lass mich dir kurz eine Geschichte erzählen …") · zu unklar („Manchmal passieren Dinge, die man nicht erwartet").

**Hook-Bibliothek (Begleitdokument):** 20 allgemeine Vorlagen (z. B. „Niemand spricht darüber: [Problem] …", „90 % der [Zielgruppe] machen diesen Fehler bei [Thema]", „Es gibt zwei Arten von [Zielgruppe] …") und 9 Storytelling-Hook-Vorlagen. Immer für die eigene Zielgruppe abwandeln, nicht 1:1 kopieren.

---

## 09 · Verschiedene Contentformate

Überblick über die klassischen Copywriting-Formeln zur Post-Struktur – als Orientierung, nicht als starres Korsett. Der rote Faden aller Formeln ist ähnlich: Pain/Gefühl ansprechen → verschärfen → Solution → Trust/Push. Jeder Buchstabe wird über mehrere Zeilen ausgebaut, nicht nur eine Zeile.

**Die 6 Formeln (Begleitdokument):**
- **GELD** – **G**efühl wecken (Hook) · **E**motion verstärken · **L**ösung präsentieren · **D**ranbleiben/Aktion. (Beispiel Webdesigner; Marcos Beispiel „Führst du dein Business wie eine 12-Jährige, die beim Zahnarzt anruft?")
- **PASP** – **P**roblem aufzeigen · **A**gitation (verschärfen) · **S**olution · **P**roof. (Beispiel Finanzberater; Proof: „Über 150 Kunden …" oder Kunden-Case.)
- **4 P's** – **Picture** (Wunschzustand malen) · **Promise** · **Proof** · **Push** (CTA).
- **BAB** – **Before** (negative Ist-Situation) · **After** (bessere Zukunft) · **Bridge** (Weg dahin). Stark, um Problembewusstsein zu triggern.
- **AIDA** – **A**ttention · **I**nterest · **D**esire · **A**ction.
- **PRUNE** – **P**roblem zeigen · **R**oadblock benennen · **U**mschwung/neuer Weg · **N**achweis/Vertrauen · **E**rmutigung zur Aktion.

Zu jeder Formel bringt der Autor ein plakatives Branchenbeispiel und ein eigenes, verfeinertes Beispiel. Beim CTA nicht in jedem Post „Melde dich bei mir" – oft passt eine gute Abschlussfrage besser. Bezug: Jedes Content-Format ist ein stiller Vertrauensaufbau; der eigentliche Pitch passiert Monate vorher.

*(Hinweis: Das Notion-Transkript dieser Lektion bricht am Ende in eine korrupte Wiederholung ab – inhaltlich vollständig ist es bis zum letzten eigenen PASS/PASTOR-Beispiel „Wenn du keine 10K Monatsumsatz machst …".)*

---

## 10 · Expertenposts

Genauer Aufbau von Experten-Posts. Warum unverzichtbar: Vertrauen entsteht durch Kompetenz, Menschen kaufen von Experten statt von Mitläufern, und Experten-Posts machen die Zielgruppe auf Probleme aufmerksam, die ihr nicht bewusst waren (Pain Digging). Premium-Kunden wollen Premium-Anbieter – deshalb laufend an der eigenen Expertise arbeiten und sie sichtbar machen.

**Was einen Experten-Post ausmacht:** löst ein konkretes Problem / klärt eine wichtige Frage · ist klar, strukturiert, direkt umsetzbar · zeigt Kompetenz ohne belehrend zu wirken (Impulse statt „Du musst").

**Die 5 Typen:**
- **How-to** – „So erreichst du [Ziel] in [Anzahl] Schritten."
- **Fehler-Posts** – „3 Dinge, die 90 % der [Zielgruppe] bei [Thema] falsch machen."
- **Mini-Analysen** – aktuelle Entwicklung/Trend für die Zielgruppe erklären.
- **Framework-Posts** – eigene Methode/System (z. B. „Wie ich von schwankenden auf konstant fünfstellige Umsätze kam").
- **Mythbusting** – falsche Glaubenssätze aufdecken.

**Häufige Fehler:** zu kompliziert / Fachjargon (oft Ausdruck von Unsicherheit) – echter Experte kann es einem Fünfjährigen erklären; zu theoretisch (nur Was-Ebene) statt auch Wie-Impulse; Angst, „zu viel Wissen" rauszugeben (Value First zieht – wenn das dein Problem ist, hast du ein anderes Problem).

**Prinzipien:** klare Frameworks/Modelle statt loser Tipps (drei Schritte funktionieren gut) · Zusammenhänge zeigen, die andere nicht sehen · konstant sichtbar bleiben (Expertenstatus durch Wiederholung) · kleine Success Stories / Micro-Case-Studies einbauen. Bezug: „5 Dinge auf 100 Arten sagen" – Thought Leadership durch Wiederholung und Tiefe.

Ausführliches eigenes Beispiel: Hook „Selbstständig machen für mehr Zeit – und dann prokrastinieren, sehr geil" → Problem auf Symptomebene → Framework eines idealen Selbstständigen-Tages → Dream (5,5 Std./Woche mehr Zeit) → Formel „Erfolg = Potenzial − Störung" → kurzes „Merke dir". Der Post lief stark (viele Impressionen, Interaktionen, InMail-Leads).

---

## 11 · Storytelling

Posts im Storytelling-Stil. Warum es funktioniert: Menschen erinnern sich besser an Informationen in Story-Form, Stories stellen eine emotionale Verbindung her (nicht Argumente), sie bauen Sympathie, Glaubwürdigkeit und Autorität auf. Analogie Superheldenfilm: Die ersten 70–80 % leidet die Person, dann kommt der Wendepunkt, die letzten 20 % ist sie der Held – genau dieser Bogen zieht. Storytelling lässt sich in Experten-, Testimonial-/Social-Proof- und persönliche Posts einbauen. Vgl. [[Storytelling Wissen]], [[Die 12 Plots]].

**Wichtige Abgrenzung:** Storytelling niemals zum Aushäulen / Opfer-Darstellen. Mitleid bringt nichts. Auch nicht künstlich stark/perfekt – aber eben nicht Opfer.

**Was eine starke Story braucht** (echte, relatable Momente): Situation/Herausforderung · Emotion oder Konflikt (innerer Konflikt oder äußere Herausforderung) · Wendung/Erkenntnis · Lehre / neues Ergebnis (das, wo die Zielgruppe hinwill).

**Der Story-Bogen (Begleitdokument):**
1. **Hook** – Emotion/Neugier wecken
2. **Einstiegssituation** – Setting, Ausgangslage
3. **Konflikt/Herausforderung** – Problem auf Symptomebene (Gedanken, Emotionen, Verhalten)
4. **Wendepunkt/Entscheidung** – Was hast du erkannt/verändert?
5. **Ergebnis und Erkenntnis** – Was hat sich geändert?
6. **Take-Away** – Was nimmt der Leser mit?

Dieser Bogen entspricht Marcos Signature-Winkel [[Der Bruch als Bauplan]] (Bruch → Wendepunkt → Rebirth) und dem McKinsey-**SCR-Modell** (Situation → Complication → Resolution). Auch ideal für Testimonials: Ausgangssituation des Kunden → was wurde etabliert → neues Ergebnis.

**Prinzipien:** kurze Absätze (1–3 Zeilen) · Dialoge/innere Gedanken nutzen · Mikro-Emotionen einbauen (Zweifel, Wut, Freude, Erleichterung) · immer mit klarem Learning oder starker Abschlussfrage enden. Verknüpfe nur Erfahrungen, die auch für die Zielgruppe relevant sind.

Ausführliches eigenes Beispiel: Hook „Früher dachte ich, ich muss endlich das finden, was mich wirklich erfüllt" → Problembeschreibung auf Symptomebene → Wendepunkt „bis ich verstanden habe, dass genau diese Gedanken mich nicht zum Ziel bringen" → neues Ergebnis (konstant mehrfach fünfstellige Umsätze) + Tipps → Take-Away. Kernbotschaft: Nicht das fehlende „Why", sondern Blockaden und konstante Umsetzung sind der Hebel.

---

## 12 · Slide Post Basics

Grundprinzipien für LinkedIn-Slideshows (Carousels). Eine Slideshow funktioniert im Aufbau wie ein Post, nur grafisch aufbereitet – gutes Abwechslungsformat. Wichtig: nicht verkünsteln, erst die Basics beherrschen, aufwendige Designs höchstens am Wochenende, nie zulasten der Akquise-Zeit.

**Die 5 Grundprinzipien (Begleitdokument):**
1. **Eine Idee pro Slide** – eine zentrale Aussage, keine Überladung/Mehrfachbotschaften.
2. **Kurze, starke Texte** – max. 1–5 kurze Sätze pro Slide, mit Auflistungen arbeiten, idealerweise 10–50 Wörter, Fokus auf Punchlines statt Fließtext.
3. **Große, lesbare Schrift** – klare, moderne Schriftarten; genügend Kontrast Text/Hintergrund; Schriftgrößen-Hierarchie (Überschrift, Unterüberschrift, Stichpunkte).
4. **Saubere Abstände** – genügend Weißraum, keine Elemente am äußersten Rand, gleichmäßige/luftige Anordnung.
5. **Einheitliches Layout** – gleiche Schriftarten/-farben auf allen Slides, max. 2–3 Farben, Branding-Farben aus dem Banner übernehmen (Wiedererkennungswert).

**Aufbau einer Slideshow:** Slide 1 = Hook (emotional/neugierig, muss ballern) · Slides 2–x = Pain ansprechen, Lösung entwickeln, Tipps geben (Slides eignen sich gut für „3 Tipps") · letzte Slide = CTA (speichern, kommentieren, folgen, DM). Die konkrete Umsetzung in Canva folgt in Lektion 13.

---

## 13 · Slide Post Umsetzung

Praxis-Walkthrough in **Canva** (kostenlose Version reicht) anhand einer erfolgreichen eigenen Slideshow (>90 Likes, mehrere tausend Impressionen).

**Tool & Setup:** Größe **1080 × 1350 px** · Elemente/Grafiken/Texte über die linke Leiste suchen und einfügen (Checks, Übergänge, Zahlen etc.) · Farben über Hex-Code des eigenen Brandings · Schrift im **Sicherheitsrahmen** (Rechteck-Markierung) halten, nicht über den Rand · Bilder mit Transparenz (30–50 %) in den Hintergrund legen, Ebenen-Position (nach vorn/hinten) nutzen · Seiten duplizieren/löschen/verschieben · Export als **PDF Standard** (nicht PNG), da LinkedIn ein PDF für Carousels braucht.

**Aufbau des Beispiels:** Hook „Am Abend habe ich das Gefühl, nicht genug gemacht zu haben" → Problem triggern und verstärken (kleinere Schrift für Zwischentöne) → Change/Erkenntnis („Das Bild vor deinen Augen liegt Jahre in der Zukunft") → Lösung/Tipps (hier bewusst etwas mehr Text, da die Leser bereits gecatcht sind – aber das Maximum an Text) → CTA „Speichere den Beitrag / folge mir für mehr". Durchgehend gleiche Schrift (Montserrat), gleiche Größen, nur „big/nicht big" als Kontrast.

**Effizienz-Trick:** Bestehende Slideshow duplizieren und als Template wiederverwenden – nicht jedes Mal neu designen.

**Inhaltsformate für Slides:** Expertenwissen (Tipps/Learnings) · Testimonials (Vorher/Nachher mit Kundengesicht + konkretem Ergebnis, über mehrere Slides erzählt) · Analysen (viraler Post, Website oder Banner vorher/nachher) · branchenspezifisch (Depotwerte für Finanzberater, Website-Redesigns für Webdesigner, Banner-Analysen für LinkedIn-Experten). Empfehlung: ca. ein Slide-Post pro Woche als Abwechslung zum Text-Post.

---

## 14 · Content Bot erstellen

Schritt-für-Schritt-Anleitung für einen eigenen **Content-GPT** (Custom GPT) als Zeitersparnis-Werkzeug.

**Voraussetzung:** **ChatGPT Plus** (~22 €/Monat) – Custom GPTs gehen nicht mit der Gratis-Version, und das Erstellen nur in der Web-Version (chat.openai.com/gpts → „Erstellen"). In der App lässt sich der fertige Bot nutzen, aber nicht bauen.

**Aufbau der Konfigurationsseite:** Links = Konfiguration (Name, Beschreibung, **Hinweise/Instructions**, Gesprächsaufhänger, **Wissen**/Datei-Upload). Rechts = Vorschau-Chat zum Testen. Man kann links manuell alles eintragen oder rechts mit dem Bot sprechen/diktieren, wodurch er die linke Seite automatisch aktualisiert.

**Der Prompt** kommt in das Feld „Hinweise/Instructions" (aus dem Begleitdokument, Klammern befüllen):

> Du bist mein persönlicher Content-GPT für LinkedIn. Ich bin: [z. B. Finanzberater für Selbstständige]. Meine Zielgruppe: […]. Ich helfe ihnen bei: […]. Der Ton meiner Beiträge ist: […]. Themen: […]. Vermeiden: [z. B. Fachchinesisch, Clickbait, leere Versprechen]. Gib klare Handlungsimpulse. Antworte auf Deutsch.

**Wichtiger Hinweis zur Memory:** Der GPT merkt sich nur, was in der Konfiguration (Hinweise + Wissen) steht. **Jeder neue Chat startet bei Null** – innerhalb eines laufenden Chats merkt er sich Dinge, aber nicht chatübergreifend. Empfehlung: einen festen Chat für die laufende Arbeit nutzen; dauerhafte Anpassungen immer in die Konfiguration schreiben, nicht nur im Chat sagen.

**Tipps für optimale Nutzung:** (1) Bestehende Inhalte als „Wissen" hochladen (Positionierung, [[#04 · Dein Kundenavatar ist dein bester Freund|Kundenavatar]], Website-Texte, bereits geschriebene Posts, Coaching-Notizen) – der GPT zitiert nicht direkt, nutzt sie aber als Kontext. (2) Klare Erwartungen formulieren (Struktur Hook → Problem → Lösung → CTA, Formate, Länge). (3) Klar definieren, was der GPT **nicht** tun soll. (4) Iterativ Feedback geben, damit der Bot mit dir zusammen lernt. Bonus: fertigen Bot duplizieren, um daraus z. B. einen DM-/Erstnachrichten-Bot mit gleichem Wissensstand zu machen.

---

## 15 · Beiträge Selfcheck Checkliste

Das Werkzeug, das ab sofort **vor jedem** Post läuft – nicht nur bei Unsicherheit. Denn die Hälfte der Posts, die nicht performen, scheitern nicht an der Idee, sondern daran, dass zu früh auf Veröffentlichen gedrückt wurde. Ausdrucken / als Sticky Note an den Monitor.

**Die Checkliste:**
- ☐ **Eine klare Kernbotschaft?** Nicht zwei, nicht drei. Wenn du sie nicht in einem Satz sagen kannst, hat der Post noch keine → überarbeiten. Klarheit siegt.
- ☐ **Auf Symptomebene geschrieben?** Statt „Du hast Angst vor Ablehnung" → „Du weißt, du müsstest den nächsten Kontakt anrufen, beantwortest aber stattdessen erst ausgiebig die Mails von gestern und ziehst dir drei YouTube-Videos zur Einwandbehandlung rein." Das trifft.
- ☐ **Sprache der Zielgruppe?** Kraftsport: nicht „Ich will stärker werden", sondern „Ich will jeden Monat neue PRs setzen." Seine Worte, nicht deine.
- ☐ **Keine leeren Worthülsen?** „Finanzielle Freiheit" ist eine Hülse. Konkret: „Im Restaurant nicht mehr die Pasta-Preise mit dem Steak vergleichen." Erzeugt Bild und Emotion.
- ☐ **Klare Handlungsaufforderung am Ende?** Frage stellen, Erfahrung teilen, Link klicken – irgendetwas. Ohne CTA wirkungslos.
- ☐ **Wirklich gehooked?** In eine fremde Person versetzen: würde sie weiterlesen oder weiterscrollen? Die Hook ist 80 %. Nie zu früh zufrieden geben.
- ☐ **Füllwörter/überflüssige Sätze raus?** So viel wie nötig, so wenig wie möglich.
- ☐ **Richtig formatiert?** Nicht zu lang, keine zu langen Absätze, Zeilen zwischen den Sätzen frei. Lesbarkeit ist ein Qualitätsmerkmal.

Kern: „Content, der konvertiert, ist nicht zufällig klar – er wurde bewusst klar gemacht."

---

## 16 · Nächsten Schritte

Umsetzungsplan zum Modulabschluss.

**Schritt 1 – Erste 3 Postings schreiben:** empfohlen 2 Experten-Posts + 1 persönlicher Post (oder alle 3 als Experten-Posts). Diese 3 in den nächsten **Copywriting-Call** mitnehmen und dort Feedback einholen. Wichtig: **nicht** 20 Posts im Voraus schreiben – sonst wiederholst du in allen dieselben Fehler und wirfst 19 Posts weg.

**Schritt 2 – Wöchentliche Routine:** ab sofort **5 Postings pro Woche**, davon regelmäßig 1–2 zur Korrektur einreichen (nicht alle 5 auf einmal). So verstehst du schnell die wichtigen Prinzipien und passt sie für Zielgruppe und Angebot an.

**Prinzipien für den Start:** Perfektion beiseitelegen (fertig schlägt perfekt) · klein anfangen → Feedback → korrigieren → weiterschreiben · der Feedback-Loop ist das schnellste Wachstumswerkzeug. „Drei Posts diese Woche sind mächtiger als ein perfekter Post in drei Monaten."
