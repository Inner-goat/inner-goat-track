---
type: wissen
tags: [academy, sales, marketing, personal-branding, neukundengewinnung, angebot, positionierung, zielgruppe, icp, no-brainer-offer]
reiter: Reiter 3 – Sales, Marketing & Personal Branding
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 1 – Grundlagen der Neukundengewinnung

Dieses Modul ist das Fundament des gesamten Sales- & Marketing-Reiters der [[Inner GOAT Academy]]. Bevor es überhaupt um Content, Akquise oder Werbung geht, wird hier das Angebot geschärft, die Positionierung geklärt und der Kundenavatar in aller Tiefe definiert. Leitgedanke: **Marketing verstärkt nur, was bereits da ist** (Amplifier-Prinzip). Ein starkes Angebot mit klarer Positionierung und einer brennenden Zielgruppe macht jedes spätere Marketing leichter – ein schlechtes Angebot macht Marketing nur schneller sichtbar als schlecht.

Roter Faden durch die sieben Lektionen: **Warum wir hier anfangen → 4 Merkmale eines No-Brainer-Offers → Zielgruppe/ICP finden → das Positionierungs-Worksheet ausfüllen → Angebotsmodell wählen → Zielgruppe tief analysieren → nächste Schritte.** Am Ende steht ein einziges Arbeitsdokument (Worksheet), das als Kompass für Content, Gespräche und Sales dient.

Verwandtes: [[Storytelling Wissen]], [[Der Bruch als Bauplan]], [[Relevanz]], [[Die 12 Plots]] – die Pain-Island-→-Dream-Island-Logik dieses Moduls ist im Kern eine Transformations-Erzählung.

---

## 01 · Ziele

Einführungs-Lektion (Video). Sie beantwortet die Frage: **Warum starten wir mit Angebot und Positionierung – und nicht mit Marketing?**

**Amplifier-Prinzip:** Marketing ist kein Zaubermittel, es verstärkt nur das Vorhandene. Schlechtes Angebot + Marketing = mehr Menschen merken schneller, dass es nichts für sie ist. Starkes Angebot + klare Positionierung + brennende Zielgruppe = Kunden sagen schneller Ja, Gespräche werden leichter, du musst weniger überzeugen, weil das Angebot schon überzeugt. Das Angebot ist das Fundament – ohne Fundament bricht alles andere zusammen.

**Die sechs typischen Probleme, die dieses Modul löst:**
1. **Zielgruppe zu breit** – wer für jeden da ist, spricht niemanden wirklich an. Content zieht nicht, Gespräche sind zäh.
2. **Angebot unklar** – Kunde weiß nicht, was er bekommt (Laufzeit, Schritte, Ergebnis). Klarheit verkauft, Unklarheit tötet Deals.
3. **Fokus auf Prozess statt Ergebnis** – du erklärst, was du tust, statt was der Kunde davon hat. Die Transformation (vorher/nachher) interessiert den Kunden.
4. **Keine klare Transformation** – kein Vorher-Nachher-Bild. Wer sich das Ergebnis nicht vorstellen kann, kauft nicht.
5. **Keine Abgrenzung zur Konkurrenz** – du bist austauschbar, es gibt keinen Grund, genau dich zu wählen.
6. **Kein klares Dokument / Arbeitsblatt** – alles läuft "über den Kopf", kein System, Chaos in Kommunikation und intern.

**Merksatz (Pitch & Marke):** Marke entsteht aus Klarheit – nicht automatisch aus Kapital. Die meisten warten auf Budget, die Besten starten mit Prinzipien.

**Community-Aufgabe:** Nenne die drei drängendsten Probleme, die du für deine Zielgruppe löst, und erkläre, warum genau dein Angebot die Brücke von Pain Island zu Dream Island ist.

---

## 02 · Angebot Grundlagen

Kern-Lehrlektion. Ziel: ein **No-Brainer-Offer** für die eigene Zielgruppe entwickeln.

**Die 4 Merkmale eines No-Brainer-Offers:**
1. **Dringendes Problem** – Kunden zahlen für Probleme, die sie *jetzt* lösen wollen. Je dringender, desto besser (Beispiel Pharma: Gesundheit = größter Schmerz, größte Angst, sofortige Zahlungsbereitschaft).
2. **Klare Transformation** – ein definierter Vorher-Zustand und ein Nachher-Zustand. Verkauft wird die Transformation, nicht eine Anzahl Sessions/Postings/Verträge.
3. **Ergebnis in klarer, greifbarer Sprache** – konkret, messbar, verständlich.
4. **Minimiertes Risiko** – Garantien, Sicherheitsmechanismen, Done-for-You / Done-with-You-Modelle (im Sales-Teil vertieft).

**Warum kaufen Kunden überhaupt?** Immer wegen eines **Schmerzes** oder eines **Wunsches**. Kunden kaufen keine Produkte, sondern Lösungen (Ibuprofen wird nicht wegen der Pille gekauft, sondern wegen "keine Kopfschmerzen mehr").

**Zwei Grundmotive** (dieselben, die uns aus der Komfortzone in die Wachstumszone bringen):
- **Weg-von-Motiv** – schmerzhafte Situation, da will ich raus.
- **Hin-zu-Motiv** – neugierig auf eine schönere Situation, da will ich hin.
- Dein Angebot ist die **Brücke** zwischen beiden.

**Was Menschen wirklich kaufen – psychologische Grundbedürfnisse:**
- Sicherheit & Stabilität (Finanzen, Versicherung)
- Abwechslung & Vielfalt
- Bedeutsamkeit & Anerkennung (sehr häufiger, legitimer Kaufgrund)
- Liebe & Verbindung (warum der Beziehungscoaching-Markt riesig ist)
- Wachstum & Entwicklung
- Beitrag & Sinn

Kaufentscheidungen erfüllen meist mehrere Bedürfnisse gleichzeitig. Im Sales geht es nicht darum, Leistungsmerkmale herunterzurattern, sondern zu verstehen, was wirklich dahintersteckt.

**Pain Island → Dream Island (zentrale Metapher):** Der Kunde sitzt auf Pain Island (Problem/unbefriedigende Lage). Dahinter liegt Dream Island (Zielzustand). Zwischen beiden liegt eine Kluft. Allein rüberzuschwimmen ist anstrengend, riskant, oft erfolglos (Jojo-Effekt). Dein Angebot ist die **Brücke** – Speedboat/Helikopter/Floß – die den Kunden sicher und schnell hinüberbringt. Das Angebot wird dabei in **klare, nachvollziehbare Schritte** unterteilt (Schritt 1 → 2 → 3), weil Klarheit Sicherheit gibt und Sicherheit verkauft.

**Wichtige Prinzipien für das Angebot:**
- Es muss einen **essenziellen Schmerz** lösen – je größer der Schmerz, desto kaufbereiter. Nice-to-have-Probleme sind schwer zu verkaufen.
- **Sei kein Alleskönner** – löse *eine* Sache mit einem Angebot. Nicht mit einem "Bauchladen" nach außen gehen. (Beispiel Zahnarzt: kauft eher die doppelt so teure Website vom Spezialisten für Zahnärzte als die billige vom Generalisten.)
- **Ein Problem, eine Lösung**, Zielgruppe muss erkennbar sein – nicht zu breit, aber auch nicht zwingend ultra-eng.
- Deine **Positionierung** ist die Lösung des Schmerzes deiner Zielgruppe.
- Es geht **nicht um dich, sondern um deinen Kunden** – der Kunde muss es verstehen und relevant finden.
- Du verkaufst keine Eigenschaften und Vorteile, sondern eine **Transformation**.

**Merksatz (Pitch & Marke):** Wissen ist Potenzial, Umsetzung ist Momentum. Viele sammeln Wissen an, ohne umzusetzen – Fortschritt entsteht nur durch Iteration.

Diese Transformations-Mechanik ist eng verwandt mit [[Der Bruch als Bauplan]] und der Grundstruktur jeder Story (Ausgangslage → Bruch/Kluft → neue Ordnung) aus dem [[Storytelling Wissen]].

**Community-Aufgabe:** Formuliere deine Transformation als Pain Island → Dream Island in zwei Sätzen.

---

## 03 · Zielgruppe finden & ICP

Lehrlektion zur Definition des **Ideal Customer Profile (ICP)** – einer der wichtigsten Schritte im gesamten Prozess.

**Drei Gründe, warum eine genaue Zielgruppendefinition entscheidend ist:**
1. **Cold Traffic funktioniert nur mit Spezifizierung** – Content, Akquise und Werbung greifen nur, wenn klar ist, wen man anspricht. Unklare Zielgruppe = verbranntes Geld, Zeit und Energie. Punktgenau zielen schlägt Schrotflinte.
2. **Spezialisten verlangen höhere Preise** – wer sich spezialisiert, wird als Experte wahrgenommen. Generalist konkurriert über Preis, Spezialist über Expertise.
3. **Begrenzte interne Komplexität** – gleicher Kundentyp → Systeme, Prozesse, Templates → schneller, effizienter, bessere Arbeit; kein Start bei Null pro Projekt.

**Häufigster Fehler:** Bei der Zielgruppe **nicht für EINE Sache bekannt** zu sein, weil man über jedes Thema postet (Marketing, Mindset, Ernährung, Produktivität, Finanzen, Reisen …). Dann weiß niemand, wofür du stehst – und kann dich auch nicht weiterempfehlen. Positivbeispiel: Stefan Park = sofort mit Copywriting assoziiert. Punkt.

**Drei Fragen zur ICP-Findung:**
1. **Wem konntest du bisher am besten helfen?** – Blick auf bisherige Kunden: beste Ergebnisse, meiste Freude in der Zusammenarbeit.
2. **Welches Problem brennt wirklich?** – kein nettes Problem, sondern eines, das nachts wachhält. Je drängender, desto kaufbereiter (siehe Pharma-Beispiel).
3. **Wo überschneiden sich dein Können und der Marktbedarf?** – das ist dein Sweet Spot, dort liegt dein ICP.

**Merksatz (Personal Branding):** Positionierung ist Magnetismus. Du bist nicht für alle da, sondern für eine bestimmte Art Mensch mit einem bestimmten Problem. Positionierung schränkt nicht ein – sie macht magnetisch. Siehe auch [[Relevanz]].

**Community-Aufgabe:** Beschreibe deinen ICP in drei Sätzen – wer, welches dringende Problem, wie bist du der Spezialist dafür.

---

## 04 · Positionierung und Zielgruppe

Die zentrale Arbeits-Lektion: gemeinsames Ausfüllen des **Worksheets Positionierung & Zielgruppe**. Aufforderung: jetzt ausfüllen, nicht "irgendwann". Dieses Worksheet ist die Grundlage für Content, Akquise und Sales.

### Die 3S-Formel (Positionierung)

Drei Bausteine, die zusammen die Positionierung ergeben:

- **Spezifischer Markt (WER):** Schau auf bisherige Kunden – wer hat am meisten Spaß gemacht, beste Ergebnisse gebracht, war am einfachsten im Support und am einfachsten zu verkaufen? Mit diesen willst du mehr arbeiten.
- **Spezifisches Problem (WAS):** Schau auf deine Skillsets – welches Problem kannst du besser lösen als 99 % der Menschen, in welches würdest du dich wirklich tief einarbeiten wollen?
- **Spezifischer Weg / Mechanismus (WIE):** Was macht dich besser als die Konkurrenz, die dasselbe Problem löst? Aufbau: *Die meisten, die XYZ erreichen wollen, probieren [Ansatz] → Problem dabei ist [Grund] → das führt zu [Folgeproblem] → stattdessen machen wir [dein Mechanismus] → was erlaubt [großer Vorteil] → was führt zu [Vorteil vom Vorteil].*

**Positionierungssatz (Beispiel):** "Wir helfen Agenturen dabei, durch die NMP-Methode planbar 3–5 Neukunden pro Monat zu gewinnen." – klar, spezifisch, verständlich. Formel: Problem (WAS) + Markt (WER) + Weg (dein Modell).

Zusätzlich: die **5 wichtigsten Punkte der Transformation** deiner Kunden festhalten.

### Schritt 2 – Dein Angebot definieren
Einfache, aber entscheidende Fragen (die meisten Selbstständigen können sie nicht klar beantworten – unklar = kein Kauf):
- Laufzeit des Core-Offers (z. B. 4 Monate)
- Investment (z. B. 5.000 € netto)
- Ratenzahlung möglich? (z. B. ja, max. 4 Raten)
- Was passiert nach der Laufzeit? (z. B. Support-Verlängerung für 1.000 € netto/Monat)
- Genauer Ablauf der Zusammenarbeit (Schritte aus der Vogelperspektive)

### Schritt 3 – Kundenavatar
Der Teil, dem die meisten am wenigsten Zeit widmen, obwohl er fundamental ist. Der Wunschkunde soll in- und auswendig bekannt sein – dieses Material speist Content und Gespräche. Struktur:

- **(1) Demografische Daten:** Geschlecht, Alter, Beziehungsstatus, Beruf, Einkommen/Verdienst, Auto, Hobbys, Bücher, Freunde, Wochengestaltung, Weiterbildung, alltägliche Sorgen.
- **(2) Symptome:** Herausforderungen, welche Sorgen du löst, Konsequenzen, **Gedanken beim Einschlafen** (wichtig), Sorgen auf Gedanken-/Emotions-/Verhaltensebene (jeweils 1:1-Aussagen notieren), unerfüllte psychologische Bedürfnisse, tiefe Ängste und wie sie sich zeigen, klassische Teufelskreise.
- **(3) Wunschzustand:** Was wollen die Kunden erreichen, was ist ihr Wunschzustand, warum.
- **(4) Expertenavatar:** Was will die Zielgruppe im Experten sehen; Merkmale erfolgreicher Big Player im Markt und wie die Zielgruppe darauf reagiert; wie sie auftreten, sich kleiden, positioniert sind.

**Merksatz (Personal Branding):** Thought Leadership entsteht durch Wiederholung und Tiefe – nicht 100 Dinge sagen, sondern fünf Dinge auf 100 Arten. Konsistenz schlägt Themenvielfalt.

**Community-Aufgabe:** 3S-Formel ausfüllen und Positionierungssatz posten – je konkreter, desto klarer das Marketing.

---

## 05 · No-Brainer Offer

Lehrlektion zur konkreten Angebotsgestaltung. Wenn das Angebot wirklich ein No-Brainer ist, kaufen Menschen nicht, weil man sie überzeugt hat, sondern weil es **logisch** ist.

**Denke an dein Warum (#3 im Begleitdokument):** Das Warum bestimmt, wie das Angebot gestaltet wird. Wer maximalen Mehrwert liefern und das Leben der Kunden wirklich verändern will, für den wird Geld zum Nebenprodukt. Man gestaltet das Angebot dann nicht so, dass man möglichst wenig herausgibt, sondern so, dass der Kunde das bestmögliche Ergebnis bekommt.

**Angebotsmodelle:**
- **Fixe Laufzeit + fixe Raten** (z. B. 12 Wochen, 3 Raten) – klar und verständlich.
- **Fixe Laufzeit + Einmalzahlung** – einfacher in der Administration; beliebt bei Kunden ohne Lust auf monatliche Verpflichtungen.
- **Monatlich kündbarer Retainer** – flexibel für den Kunden, weniger planbarer Cashflow für dich.
- **Setup + Monthly** – einmalige Einrichtungsgebühr plus monatliche Betreuungspauschale; gut für kontinuierliche Leistungen.

**Tipps:**
- Bei neuem Angebot oder Anfang: immer mit **Testkundenpreis** starten – günstigere erste Kunden, Ergebnisse und Testimonials sammeln, dann mit Beweisen den Preis erhöhen. Der smarteste Weg zum Markteintritt.
- Wähle das Modell, das **Ergebnis + Kapazität + Cashflow** am besten verbindet: Ergebnis muss in der Laufzeit lieferbar sein, Kapazität muss die Kundenzahl zulassen, Cashflow muss für dich funktionieren.

Das Modell wird konkret im Worksheet aus Lektion 04 ausgearbeitet – falls noch nicht geschehen: erst dort ausfüllen.

**Merksatz (Pitch & Marke):** Knappheit als Lehrer – Gründen mit wenig Budget zwingt zu präziserem Denken und schnellerem Lernen. Ein mit Mindestressourcen geschärftes Angebot baut ein tragfähiges Fundament.

**Community-Aufgabe:** Entscheide dich für ein Angebotsmodell und begründe, warum es zu Ergebnis, Kapazität und Cashflow passt.

---

## 06 · Zielgruppenanalyse

Vertiefungs-Lektion: die Arbeit am Kundenavatar in die Tiefe treiben. Genau die Arbeit, die sich die meisten sparen – und genau der Grund, warum ihr Marketing, Content und Akquise nicht funktionieren. Wer seinen Kunden wirklich kennt, schreibt besseren Content, führt bessere Gespräche, macht bessere Angebote.

Das Worksheet hat vier Teile:

**Teil 1 – Demografische Daten:** der einfachste Teil (Geschlecht, Alter, Beziehungsstatus, Beruf, Einkommen), ergänzt um konkrete Details (Auto, Lektüre, Wochengestaltung). Ziel: keine abstrakte Zielgruppe, sondern eine echte Person, für die man schreibt.

**Teil 2 – Symptome (wichtigster Teil):** Herausforderungen, Konsequenzen bei Nicht-Lösung und die entscheidende Frage – **welche Gedanken macht sich der Kunde, wenn er abends im Bett liegt?** Das sind die echten, emotionalen Schmerzen, nicht die rationalen Probleme, die jemand auf Nachfrage aufzählt. Konkrete **1:1-Aussagen** notieren, wie Kunden sie wirklich sagen – auf Gedanken-, Emotions- und Verhaltensebene. Solche Aussagen (aus Discovery Calls / Coaching Sessions) sind Gold und lassen sich direkt in Content übertragen.

**Teil 3 – Wunschzustand:** nicht das Oberflächliche ("mehr Kunden"), sondern das tiefere Warum – finanzielle Sicherheit, morgens ausgebucht aufwachen, der Familie ein bestimmtes Leben bieten. Das sind die echten Motivationen.

**Teil 4 – Expertenavatar:** Was will die Zielgruppe im Experten sehen, dem sie vertraut? Welche Merkmale haben die Big Player, wie treten sie auf, kleiden sich, positionieren sich? Hilft zu bestimmen, wie man selbst nach außen wirken will.

Ergebnis ist ein Dokument, das als **Kompass** dient: für den Content-Bot, als Referenz vor jedem Discovery Call, als KI-Input beim Schreiben von Posts.

**Merksatz (Personal Branding):** Menschen kaufen Bedeutungen, nicht Produkte. Kommuniziere nicht, was du tust, sondern was es für den anderen bedeutet. Der Self-Reference-Effect: je stärker sich jemand in deiner Botschaft wiederfindet, desto höher die Resonanz. Wer seine Zielgruppe besser kennt als sie sich selbst, gewinnt Vertrauen. Verwandt mit [[Relevanz]] und dem [[Storytelling Wissen]].

**Community-Aufgabe:** Zielgruppen-Worksheet vollständig ausfüllen und eine konkrete 1:1-Aussage eines echten Kunden teilen, die zeigt, dass du die echten Schmerzen kennst.

---

## 07 · Nächsten Schritte

Kurze Abschluss-Lektion (Video) mit dem Handlungsauftrag zum Modulabschluss.

**Deine nächsten Schritte:**
- **Worksheet Positionierung & Zielgruppe ausfüllen** – so weit und so genau wie möglich. Offene Punkte sind kein Problem; wichtig ist, sich die Zeit zu nehmen und haargenau zu sein, denn dies ist die Grundlage für das komplette Business.
- **Link des Worksheets in die 1:1-WhatsApp-Gruppe schicken.**
- **Fragen für den Auftaktworkshop notieren**, in dem alles gemeinsam besprochen wird.

**Merksatz (Mindset):** Schritt für Schritt vorzugehen ist kein Fehler, sondern die einzige Methode, die wirklich funktioniert. Einfache tägliche Schritte in die richtige Richtung schlagen jeden einmaligen Kraftakt – kleiner denken, Momentum aufbauen.

**Community-Aufgabe:** Teile, bis wann du dein Worksheet ausgefüllt haben wirst – und halte dich öffentlich accountable.
