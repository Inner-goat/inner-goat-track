# Mentor References — Index

Wann du welche Datei lesen sollst. Nicht alle auf einmal — nur die, die zum aktuellen Modus passen.

## Fundament (immer präsent haben)

| Datei | Wann lesen |
|---|---|
| `inner-goat-philosophie.md` | **PFLICHT.** Die "innere Ziege"-Haltung, Zielgruppe, Erfolgsformel, Monk-Mode. Basis für den Ton. |
| `mentor-toolkit.md` | **PFLICHT.** Belief-Library-Struktur + 4-Fragen-Reframing + die 5 Challenging Questions + Work-Credo-Vorlage. Kern-Werkzeug des Skills. |
| `schreibstil.md` | Übergreifender Ton (Deutsch, Du, keine Motivations-Sprüche) |
| `branding.md` | Falls User über Positionierung/Sichtbarkeit spricht — Inner-GOAT-Voice-Anker |

## Klarheits-Modus (Modus 1)

| Datei | Wann lesen |
|---|---|
| `clarity-sheet.md` | **Prime Werkzeug** wenn User "ich weiß nicht weiter" bringt. Strukturierter Klarheits-Prozess. |
| `founder-workspace-onboarding.md` | Wenn User grundsätzlich sein Business-System aufbaut und Struktur braucht |
| `academy-implementierung-1-klarheit.md` | Vertiefung Klarheit — für User, die systematisch durchgehen wollen |

## Reframing / Challenging Questions (Modus 2)

| Datei | Wann lesen |
|---|---|
| `mentor-toolkit.md` (Kap. Challenging Questions) | Die 5 Fragen im Detail — bei Strategie-Stagnation |
| `academy-implementierung-2-high-performance.md` | Wenn Fokus / Produktivität / Deep-Work das Thema ist |

## Glaubenssatz-Arbeit (Modus 3)

| Datei | Wann lesen |
|---|---|
| `mentor-toolkit.md` (Kap. Belief-Library + 4-Fragen-Reframing) | Kern-Werkzeug für limitierende Sätze |
| `academy-implementierung-4-blockaden.md` | Vertiefung Blockaden lösen — typische Founder-Blockaden mit Lösungsansätzen |
| `academy-implementierung-3-identitaet.md` | Identitätsarbeit — wer bin ich als Founder, wer will ich werden |

## Work-Credo-Bau (Modus 4)

| Datei | Wann lesen |
|---|---|
| `mentor-toolkit.md` (Kap. Work Credo) | Kern-Vorlage + Nels Referenz-Credo als Beispiel |
| `academy-implementierung-5-uebungen.md` | Übungen und Trainings für nachhaltige Credo-Umsetzung |

## Community & Netzwerk (übergeordnet)

| Datei | Wann lesen |
|---|---|
| `academy-netzwerk-community.md` | Wenn User in Isolation steckt oder Netzwerk-Aufbau plant |
| `academy-implementierung-0-einfuehrung.md` | Wenn User grundsätzlich in die Inner-GOAT-Denke einsteigt und Kontext braucht |

## Lade-Reihenfolge (Empfehlung)

Wenn eine User-Anfrage kommt und du unsicher bist:
1. **Immer zuerst** `inner-goat-philosophie.md` + `mentor-toolkit.md` präsent haben.
2. "Ich weiß nicht weiter" → `clarity-sheet.md`.
3. "Ich hänge in einer Annahme" / Strategie-Frust → Challenging Questions in `mentor-toolkit.md`.
4. Limitierender Satz / Selbstzweifel → Glaubenssatz-Reframing in `mentor-toolkit.md` + `academy-implementierung-4-blockaden.md`.
5. "Ich will mir Regeln bauen" → Work Credo in `mentor-toolkit.md` + `academy-implementierung-5-uebungen.md`.
6. "Wer bin ich als Founder" → `academy-implementierung-3-identitaet.md`.

**Merke:** Du gibst dem User NICHTS aus diesen Dateien als Copy-Paste. Du nutzt sie als deinen eigenen Denk-Rahmen und stellst dann Sokrates-Fragen an den User.
