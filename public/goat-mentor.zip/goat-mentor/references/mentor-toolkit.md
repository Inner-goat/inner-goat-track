---
type: wissen
tags: [founder-workspace, mindset, glaubenssätze, sales, notion]
quelle: Notion
erstellt: 2026-07-08
---

# Mindset & Glaubenssätze

Das Mindset-Modul des [[Founder Workspace V2]]: Das Sales-Mindset ist mindestens so wichtig wie die Skripte. Hier werden limitierende Glaubenssätze identifiziert, hinterfragt und durch befreiende ersetzt. Diese Notiz hält die Struktur der Belief-Library, das Reframing-Werkzeug „Challenging Questions" und die Work-Credo-Vorlage fest. Thematisch verwandt mit Marcos Signatur-Winkel [[Art of Breaking Yourself]] — den eigenen Glaubenssatz zu brechen ist die Mindset-Variante des Bruchs als Bauplan.

## Belief-Library (Struktur)

Zwei Datenbanken, die im laufenden Notion-Workspace leben (Trackerinhalt, hier nicht importiert):

- **Glaubenssatz-Library** — ~90 typische Sätze als Inspiration. Felder: *Glaubenssatz* · *Kategorie* (Identität / Verkaufen / Geld / Branche·Kunden) · *Polung* (Limitierend / Befreiend) · Checkbox *Trifft mich* · Relation zu „Meine Bearbeitung". Vorgehen: alle Sätze, die einen treffen, per „Trifft mich" markieren.
- **Meine Glaubenssätze** — die persönlich getroffenen Sätze mit Status-Tracking (Offen → In Arbeit → Transformiert).

**4-Fragen-Reframing (monatlicher Review, 1. des Monats):** Einen markierten Satz nehmen und mit dem 4-Fragen-Framework von limitierend zu befreiend umschreiben. Genau *einen* Satz pro Session — Tiefe vor Menge.

## Challenging Questions — Business reframen

Wann nutzen: bei Endlosschleifen, Stagnation oder dem Gefühl, in der Bubble eigener Annahmen festzustecken. Pro Frage 20–30 Min, ehrlich, ohne sich von der aktuellen Realität einschränken zu lassen — gesucht werden neue **Hebel**, nicht der „richtige" Plan. Fünf Fragen, jede führt in eine andere strategische Richtung:

1. **10-fach höherer Preis?** → *Premium-Nische.* Wer ist der neue Kunde? Was muss das Produkt zusätzlich leisten, welcher Service/welche Garantie? Verkauf per Hand-Selling statt Funnel. (Bsp.: 190-€-Kurs → 1.900 € mit Vor-Ort-Bootcamp, Mentoring, fertigen Pitch Decks.)
2. **Spaß-Faktor maximieren?** → *Entertainment-Nische.* Jeder Kontaktpunkt wie ein Event, Kunde als Held seiner Geschichte, Community mitnehmen statt nur konsumieren lassen. (Mr.-Beast-Prinzip: Spaß maximieren, nicht Watch Time.)
3. **Keine Website erlaubt?** → *Exklusivitäts-Nische.* Word-of-Mouth, Social-Kanäle, Mitgliedschaft an Exklusives koppeln (Code/Empfehlung/Event), Knappheit als Marketing.
4. **CEO wäre ein Soziopath?** → *Radikale Disruption.* Welche Prozesse sofort eliminieren (existieren nur aus Gewohnheit)? Welche „heiligen Kühe" der Branche schlachten? (Bsp.: Tesla Cybertruck — 77 % weniger Kabel, weil keine Rücksicht auf alte Pipelines.)
5. **Meetings verboten?** → *Kostenführerschaft-Nische.* KI ab Tag 1, alles schriftlich/asynchron, Entscheidungsstrukturen ohne gemeinsamen Raum, Doku für eigenständiges Handeln.

**Bonus-Frage:** Welche der 5 Antworten hat den stärksten *Schmerz* verursacht? Das ist wahrscheinlich die wichtigste Frage gerade.

**Aktion ableiten:** 1–3 spannendste Ideen highlighten → was ist nächste Woche risikoarm testbar? → Tasks anlegen (Typ Sales/Strategie, verknüpft mit Ziele-Tracker Bereich Business) → monatlicher Review (Antworten verändern sich mit dem Wachstum).

## Work Credo — eigene Regeln als Reminder

Jede:r erfolgreiche Selbstständige hat ein eigenes Set an Regeln, Standards und Routinen — der rote Faden, der an chaotischen Tagen zurückholt. Faustregel: lieber **10 Regeln, die man wirklich lebt**, als 50 auf einer vergessenen Liste. So bauen, dass sie unter Stress greifen. Vorgehen: 2 Std nehmen, Beispiel unten in eigene Sprache übersetzen (nicht abschreiben), ausdrucken, über den Schreibtisch hängen, quartalsweise reviewen.

### Beispiel: Nel's Work Credo (Inspiration, gewachsen über Jahre)

**Roter Faden — Umsetzung:** Kann sich für jedes neue Projekt begeistern und es zur Umsetzung führen; Geburtshelfer für die Ideen anderer; gibt gern die Zügel ab, sobald etwas eingependelt ist; merkt schnell, wenn eine Umsetzung keinen Sinn ergibt.

**Grundsatzfragen:** Wie skaliere ich mein Business? Wie werde ich erfolgreicher? Wie verdiene ich mehr Geld? Wie mache ich mich und andere glücklich? Wofür will ich bekannt sein? Wo sage ich Nein, um Ja zum Business zu sagen?

**Erfolgsformel:** `ERFOLG = POTENZIAL − ABLENKUNG`. Harte Arbeit, Disziplin, etwas Mut. **Fokus durch Monk Mode:** 1 Zielgruppe · 1 Angebot · 1 Marketing-Kanal · 1 Akquiseweg.

**Weekly Minimum Standard:** min. 3 LinkedIn-Postings · wichtigste DMs & E-Mails · min. 5× Sport · 1× Dankbarkeits-Reflexion.

**Daily Standard (6 h Fokuszeit):** 1 h Akquise (8 Nachrichten raus) · 1 h Marketing · 1,5 h Calls mit potenziellen Kunden · 2 h Fulfillment für Bestandskunden · 0,5 h Puffer.

**My Movement:** Less time working · more time with family · more time in nature · less doing what I hate · more money for impact.

**Fokus auf die Basics:** *Angebot* = Problem, das du schneller/besser löst · *Marketing* = Vertrauen aufbauen, Zielgruppe auf Symptomebene ansprechen · *Vertrieb* = direkter Kontakt, Gespräche vereinbaren. Genau das umsetzen, jeden Tag, konstant.

**17 eigene Regeln (Auswahl der Kernpunkte):**
1. Nie am gleichen Tag kaufen — erst überlegen.
2. Nicht verschwenderisch leben — minimalistisch, frugal.
3. Controlling, Buchhaltung, Steuern immer im Blick.
4. Achtsamkeit leben — Körper/Seele, regelmäßig Sport.
5. Kernarbeitszeit 9:00–18:00.
6. Eigene Regeln/Maßstäbe wahren — nicht unterordnen.
7. Erfinde dich jeden Tag neu — jeden Tag ein bisschen besser.
8. Habe Spaß. Das Leben ist ein Spiel.
9. Nicht nur geben — auch nehmen und einfordern.
10. Pareto: 4,8 h fürs Wichtigste — 20 % Ressourcen für 80 % Outcome.
11. **CASHFLOW FIRST!**
12. Im Zweifel dagegen entscheiden.
13. In den Ruf investieren — Vertrauen, Kontakte, Reputation.
14. Geld: richtige Einstellung — löst nur Geldprobleme, Positiv-Summenspiel, Mittel zum Zweck.
15. Bescheidenheit.
16. Glück: im Moment leben, nichts bewerten, nichts wollen, alles akzeptieren; sich entscheiden, glücklich zu sein.
17. Bleib offen — weniger Alkohol/Drogen, Gemütszustand stabilisieren, Sport.

### Deine Vorlage (Sektionen zum Selbstausfüllen)
Roter Faden · Grundsatzfragen · eigene Erfolgsformel · Weekly Minimum Standard · Daily Standard · My Movement · Basics-Definitionen (Angebot/Marketing/Vertrieb je 1 Satz) · die 10–15 wichtigsten Regeln.

**Review-Rhythmus:** wöchentlich (Weekly Minimum erreicht?) · monatlich (welche Regel half, welche gebrochen?) · quartalsweise (Daily Standard & Erfolgsformel noch stimmig?) · jährlich (roter Faden / Movement verändert?).

## Anwendung

Mindset-Modul: laut Workspace-Empfehlung wöchentlich an einem Glaubenssatz arbeiten, monatlich reviewen. Die Challenging Questions sind das Strategie-Werkzeug bei Stagnation; das Work Credo ist der persönliche Anker. Für Marco koppelt das direkt an [[Art of Breaking Yourself]] und die Positionierung im [[Inner GOAT]]-Kosmos.

## Verwandte Notizen

- [[Clarity Sheet]]
- [[Founder Workspace – Onboarding]]
- [[Founder Workspace V2]]
- [[Art of Breaking Yourself]]
- [[Home]]
