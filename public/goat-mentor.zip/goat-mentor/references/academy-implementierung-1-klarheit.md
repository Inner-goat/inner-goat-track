---
type: wissen
tags: [academy, klarheit, vision, werte, angebot, kundenavatar, akquise, planbarkeit, traum]
reiter: Reiter 1 – Implementierung
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 1 – Klarheit

Klarheit ist das Fundament von allem. Ohne Klarheit weiß man nicht, wohin man will — und verbrennt Energie wie jemand, der sich ins Auto setzt und ohne Ziel drauf losfährt. Dieses erste Modul der [[Inner GOAT Academy]] (Reiter 1 – Implementierung) legt genau dieses Fundament: Vision und innere Antreiber, Werte und Brand, ein glasklares Angebot, ein tiefes Verständnis der Zielgruppe und schließlich planbare Akquise mit konkreten Wochenzielen.

Der rote Faden: Erst das Fundament gießen (Traum → Vision → Werte), dann das Werkzeug schärfen (Angebot → Kundenavatar), dann die Umsetzung planbar machen (Akquise → Wochenziele). Klarheit ist dabei kein einmaliger Zustand, sondern ein Muskel, der durch tägliche Reflexion (Clarity Sheet) trainiert wird. Das Modul verweist immer wieder auf zentrale Mindset-Konzepte des Inner-GOAT-[[Storytelling Wissen]]s wie [[Der Bruch als Bauplan]] (Scheitern als Daten, nicht als Endpunkt) und [[Relevanz]] (die exakte Sprache der Zielgruppe treffen).

> Wichtiger Hinweis: Dies ist kein Business-Coaching. Themen wie Positionierung und Zielgruppe werden bewusst angesprochen — nicht, um in die letzte Tiefe zu gehen, sondern um das Fundament sauber zu legen, damit Marketing und Akquise danach Schritt für Schritt umsetzbar sind.

---

## 01 · Einführung Modul Klarheit

Video-Lektion (Einführung). Klarheit steht am Anfang des Kurses, weil sie das Allererste ist, was man braucht, um Business-Ziele zu erreichen: Klarheit über Werte, Vision, Ziele, die eigene Identität, die Zielgruppe, das Angebot und die Ansprache.

**Fahrplan durch das Modul:**
- **Vision & Antreiber:** Wo willst du wirklich hin? Was motiviert dich? Schlüsselfrage: *„Wie sieht dein Leben aus, wenn du nicht scheitern kannst?"*
- **Clarity Sheet:** Persönlicher Kompass (Anti-Vision, Vision in 7 Lebensbereichen, Werte, Ziele, Verkaufsargumente) — täglich zu lesen.
- **Werte:** Deine Fingerabdrücke auf allem, was du tust.
- **Angebot:** Die 4 Elemente — WHO, PROBLEM, LÖSUNG, ERGEBNIS.
- **Kundenavatar:** Kenne deinen Kunden besser, als er sich selbst kennt.
- **Planbarkeit & Akquise:** Kein Hoffnungs-Business, sondern System. Konkrete Wochenziele.

**Warum Klarheit zuerst kommt:**

| Ohne Klarheit | Mit Klarheit |
|---|---|
| Prokrastination durch Unklarheit | Klare nächste Schritte = Handeln |
| Shiny Object Syndrome | Fokus auf das Wichtige |
| Marketing fühlt sich leer an | Marketing trifft und resoniert |
| Verkaufen fühlt sich unangenehm an | Sicherheit im eigenen Wert |
| Abstrakte oder fehlende Ziele | Konkrete Ziele geben Richtung |

Kernbotschaft: Werte sind wichtig, weil sich in einem Markt mit vielen austauschbaren Anbietern (Agenturen, Coaches, Finanzdienstleister) am Ende die Brand durchsetzt — Menschen, die klar hinter ihren Werten stehen und das überall (Postings, Positionierung, Verkaufsgespräche, Ausstrahlung) ausdrücken.

> **Mindset-Anker:** Hyper-fokussierte Menschen sind die Erfolgreichen. Wer sich ständig von neuen Ideen, Tools und Strategien ablenken lässt (*Shiny Object Syndrome*), verliert. Und: Prokrastination entsteht sehr häufig nicht aus Faulheit, sondern aus Unklarheit — Klarheit ist das wirksamste Gegenmittel.

**Aufgaben:** Alle Videos in Reihenfolge · Clarity Sheet ausfüllen und ab sofort jeden Morgen lesen · Kundenavatar-Worksheet ausfüllen und nach jedem Gespräch aktualisieren.

---

## 02 · Klarheit über deine Vision

Diese Lektion führt in das **Kundenavatar-Worksheet** ein — eines der wichtigsten Arbeitsblätter überhaupt, weil Zielgruppenkenntnis das Wichtigste ist, was man im Business braucht. Vision schärft sich durch tiefes Kennen der Zielgruppe.

**Die 3 Teile des Worksheets:**

1. **Demografische Daten:** Geschlecht, Alter, Beziehungsstatus, Beruf, Einkommen (bewusst zwischen Einkommen und Umsatz unterscheiden), Auto, Hobbys, Bücher, Wochenprogramm, alltägliche Sorgen.
2. **Psychografisches Profil (der wichtigste Teil):** Ausgangssituation vor deiner Leistung, Wunschsituation, Abendgedanken, Ängste & Wünsche — jeweils **1:1 in der Sprache der Kunden** notiert.
3. **Expertenavatar:** Wie möchte der Kunde beraten werden? Merkmale der Big Player im Markt? Wie reagiert die Zielgruppe auf verschiedene Berater-Typen?

**Das wichtigste Prinzip:** Aussagen der Kunden wörtlich aufschreiben. Nicht „hat Versicherungsprobleme", sondern das echte Zitat: *„Ich bin seit 15 Jahren beim Versicherungsberater meines Vaters versichert und habe seit 8 Jahren nicht mehr in meine Dokumente geschaut."* Je genauer die Worte, desto tiefer trifft das Marketing (→ [[Relevanz]]). Das Worksheet wird nach jedem Berührungspunkt gepflegt und wächst über die Zeit auf mehrere Seiten.

> **Vertiefung Vision:** Vision ist ein Muskel — sie wird durch regelmäßige Übungen geschärft (Brief an dein zukünftiges Ich · Idealer-Tag-Visualisierung · Epitaph-Übung · 100 Ziele ohne Zensur · Vision Board). Und: **Money Psychology** — das Traumleben rückwärts bauen: (1) Traumleben konkret definieren, (2) Jahreskosten ausrechnen, (3) durch 12 → monatlicher Bedarf, (4) mal 2–3 für Steuern/Rücklagen → Umsatzziel, (5) durch Angebotspreis → nötige Kundenzahl pro Monat. Zahlen erzeugen Handlung.

---

## 03 · Klarheit über Vision Teil 2

Vertiefung des Vision-Themas mit einem zentralen Denkfehler und der kraftvollsten Frage des Moduls.

**Die häufigste Falle — der Flur mit den Räumen:** Viele warten auf ihr „tiefes Warum", bevor sie starten. Das ist wie in einem weißen Flur zu stehen, links und rechts Räume, aber in keinen hineinzugehen — ein Leben lang. Das Warum findet man nicht durch Nachdenken, sondern durch Tun. Man geht in einen Raum, schaut, ob er gefällt, entdeckt die nächste Tür.

**Die Kernfrage — „Wenn du nicht scheitern kannst…":** Für alle Lebensbereiche beantworten (Finanzen, Business, Beziehungen, Gesundheit, Lifestyle, Persönlichkeit), jeweils für 1 / 3 / 10 Jahre. Sobald Ego und Verstand mit „Wer bin ich schon?" dazwischenfunken, hilft diese eine Frage, um darüber hinwegzukommen.

Stephen Covey: *„Begin with the end in mind."* — Fang mit dem Ende an. Das Schlimmste ist, irgendetwas zu tun und dann festzustellen, dass man das gar nicht wollte.

**Die Statistik zur Angst:** 88 % unserer Sorgen treffen nie ein. Von den 12 %, die eintreten, sind 30 % sogar besser als erwartet. Fast alle Blockaden sind Bilder im Kopf, keine Realität.

**Anti-Vision als Werkzeug:** Manchmal ist es einfacher zu wissen, was man NICHT will. Fragen: Wie soll mein Leben in 3 Jahren auf keinen Fall aussehen? Was würde mich unglücklich machen? Welches Gehalt möchte ich nie akzeptieren müssen?

> **Mindset-Anker:** Neurowissenschaftlich ist dein Zukunfts-Ich für dein Gehirn ein Fremder — deshalb fällt es schwer, heute klug für morgen zu entscheiden. Die Vision-Übung trainiert das Gehirn, das Zukunfts-Ich als real zu akzeptieren. Und: Wir überschätzen, was wir in kurzer Zeit schaffen, und unterschätzen, was in langen Zeiträumen möglich ist — „Begin with the end in mind" heißt: Ziel kennen, aber Schritt für Schritt gehen. Denk kleiner, nicht größer.

---

## 04 · Clarity Sheet

Das **Clarity Sheet** ist kein bloßes Arbeitsblatt, sondern ein täglicher Kompass. Einmal sauber ausfüllen — dann jeden Morgen lesen. Es hält ausgerichtet und erinnert daran, wofür man das alles macht.

**Aufbau des Sheets:**

**1. Wichtige Reminder** (Haltungen, die sich durch tägliches Lesen verankern):
- So wie du eine Sache machst, machst du alles andere auch.
- Das, was du reingibst, kriegst du am Ende raus.
- Je weniger ich abgelenkt bin, desto fokussierter bin ich.
- Umsatz kommt von Umsetzen. Jeden Tag ein Step nach vorne, egal wie groß.
- Es geht IMMER um die Basics.
- Erfolg entsteht nicht durch das, was du konsumierst, sondern durch das, was du ignorierst.
- In dem Moment, wo du dich bewegst, kommen mehr Möglichkeiten auf.

**2. Anti-Vision:** Welches Leben du NICHT führen willst (in 3 Jahren auf keinen Fall, was dich unglücklich machen würde, welches Gehalt du nicht akzeptieren willst, was schmerzhaft wäre, wenn enge Freunde/Familie es über dich denken würden).

**3. Vision in den 7 Lebensbereichen** (jeweils: „wenn du nicht scheitern kannst"): Deine Person · Gesundheit & Fitness · Beziehungen · Business · Lifestyle · Finanzen. So konkret wie möglich — Bilder, Zahlen, genaue Beschreibungen.

**4. Werte** (5 Unternehmenswerte mit eigener Definition) und **Verkaufsargumente** (warum jemand ausgerechnet bei dir kauft).

**5. Mission:** Warum du dein Business machst — die tiefere Mission dahinter.

**6. Ziele:** Ziele für die nächsten Jahre plus **3 konkrete, messbare Ziele für die nächsten 3 Monate.**

> **Mindset-Anker:** Prokrastination entsteht aus Unklarheit über den nächsten Schritt — das Clarity Sheet ist das tägliche Antidot gegen Stillstand. Und die Anti-Vision ist ein Schutzschild gegen das *Shiny Object Syndrome*: Wer klar weiß, was er NICHT will, hat einen Filter für alles, was Energie stiehlt.

---

## 05 · Deine Werte

Werte sind wie Fingerabdrücke: Niemand hat die gleichen, und man hinterlässt sie überall — im Marketing, in Gesprächen, in der Akquise, im Umgang mit Kunden. Diese Lektion macht sie bewusst und nutzt sie als Fundament, damit Marketing und Sales einfacher und authentischer werden.

**Definition:** Werte sind Überzeugungen und Eigenschaften, die man als erstrebenswert betrachtet. Sie sind **Gefäßwörter** — jeder füllt sie anders (100 Menschen → 100 Definitionen von „Freiheit"). Man handelt bereits nach seinen Werten, auch unbewusst; das Ziel ist, sie bewusst zu machen. Werte werden durch Erfahrung, Erziehung, Umwelt und Kultur geprägt (Beispiel: Scheitern wird in den USA gefeiert, in Deutschland belächelt) — und dürfen jederzeit hinterfragt und weiterentwickelt werden.

**Das Fundament: Werte → Vision → Ziele.** Der Pinguin-Vergleich: Pinguine sind im Wasser am schnellsten, weil sie dort in ihrem Element sind. Menschen kommen am schnellsten voran, wenn sie nach ihren Werten leben. Ohne Werte ist das Handeln extrem volatil; mit Werten gibt der Grundbaustein einen stabilen Rahmen.

**Die 3 Aufgaben dieser Lektion:**
1. **5 Unternehmenswerte** definieren (Wort + eigene Definition). *Nils' Beispiel:* Umsetzung · Klarheit · Erfolg · Empathie · Wachstum.
2. **Mindestens 10 Punkte,** die dich besonders machen (Quellen: Kundenfeedback, Komplimente aus dem Umfeld, Fähigkeiten, die andere immer wieder bemerken).
3. **3–6 Verkaufsargumente** formulieren — prägnante, tiefgründige Aussagen, die Emotion wecken und zum Nachdenken anregen. *Nils' Beispiele:* „Umsatz kommt von Umsetzen." · „Konstante Umsetzung der wichtigen Aufgaben bringt dich auf die Überholspur, während deine Konkurrenz im Kreisverkehr fährt." · „Die beste Strategie und die besten Skripte bringen dir nichts, wenn du sie nicht umsetzt." · „Du hast keine Kontrolle über deine Ergebnisse, nur über deine Handlungen und Einstellungen." · „Erfolg bringt dir nichts, wenn du ihn nicht lebst."

Die Verkaufsargumente baut man oft auf Verbildlichungen auf (Überholspur/Kreisverkehr) — sie erzeugen sofort Bilder im Kopf (→ [[Relevanz]]). Auch dieses Sheet liest man täglich, um sich den Wert der eigenen Dienstleistung immer wieder bewusst zu machen und so williger zu verkaufen.

> **Mindset-Anker:** Authentizität und Accountability sind untrennbar — wer nach seinen Werten lebt, muss sich nie fragen „Was sollen andere denken?". Und Werte schützen vor Ablenkung: Bei jeder neuen Strategie/jedem Tool nur eine Frage — „Passt das zu meinen Werten und meiner Vision?"

---

## 06a · Dein Traum — Warum du einen brauchst

*(Teil 1 von 3 · basierend auf Simon Squibb, „What's Your Dream?")*

Bevor das Modul tiefer in Angebot, Avatar und Akquise geht, wird das eigentliche Fundament gegossen: der Traum. Ohne ihn ist alles darauf Gebaute beliebig.

**Das Paradox der Träume:** Das, was wir uns am meisten wünschen, fürchten wir am meisten. Je länger wir den Traum verleugnen, desto mehr Lebenskraft kostet die Verleugnung. Der Traum geht nicht weg — er wartet und nimmt sich stille Stücke aus unserem Leben. Deshalb begraben die meisten Menschen ihren Traum („nur eine Spinnerei", „zu spät", „unrealistisch") — das ist nicht die Realität, die spricht, sondern die Angst.

**Ein Traum passt in einen Satz.** Kein Essay, kein 500-Wörter-Statement. Beispiele: „Ich möchte Menschen helfen, finanziell unabhängig zu werden." · „Ich möchte ein Business aufbauen, das ohne mich läuft." Einfach, aber multidimensional — er trägt dich in vielen Lebensbereichen und wirkt als Kompass: Bringt mich das näher ran oder weiter weg?

**NPC-Dasein — das Leben ohne Traum:** Ohne Traum wird man zur Nebenfigur im eigenen Leben (NPC = „Non-Playable Character") — programmiert, routiniert, ohne Richtung. Das Fatale: Es fühlt sich „richtig" an, weil die Mehrheit so lebt. Ein Traum macht dich zur Hauptfigur.

**Was ein Traum gibt:** Kompass (einfachere Entscheidungen) · Kraftquelle (morgens aufstehen, weil man will, nicht muss) · Resilienz (Rückschläge werden zu Umwegen). Und: Ein **Mindset-Shift vom Überlebensmodus in den Möglichkeits-Modus** — er passiert in dem Moment, in dem man sich erlaubt zu träumen. Der Traum kommt zuerst; er ist nicht der Lohn für ein gelöstes Leben, sondern der Motor.

**Warum zentral fürs Business:** Das Business ist nicht das Ziel, sondern das **Vehikel**, mit dem der Traum realisiert wird. Ohne Traum baut man ein zufälliges Business; mit Traum eines, das dient. (→ [[Der Bruch als Bauplan]] · Rebirth-Plot der [[Die 12 Plots]])

**Aufgabe:** Einen einzigen Satz aufschreiben — „Mein Traum ist…" — roh, ohne Urteil, 5 Minuten ohne Ablenkung.

---

## 06b · Dein Traum — Die 7 Blockaden

*(Teil 2 von 3)*

Fast jeder Mensch, der seinen Traum nicht lebt, steht auf einer von sieben ganz konkreten Stufen. Jede ist ein eigener Mechanismus — und jede ist überwindbar, sobald man sie erkennt.

| Stufe | Was dahintersteckt | Erster Schritt nach oben |
|---|---|---|
| **1 — „Ich hab keine Zeit"** | Traum nicht als legitim akzeptiert (höflichste Art zu sagen: nicht wichtig genug) | 1 Minute/Tag reservieren → 5 → 10 |
| **2 — „Ich bin gefangen"** | Du arbeitest rückwärts von der Ist-Situation aus | Mental an den erfüllten Traum stellen, ersten Rückweg-Schritt finden |
| **3 — „Ich brauch keinen Traum"** | Schutzbehauptung — du glaubst nicht, einen haben zu dürfen | Frage: „Wenn Geld keine Rolle spielte, was würde ich tun?" |
| **4 — „Ich weiß nicht was"** | Du suchst in der Zukunft, aber der Traum liegt in der Vergangenheit | Rückschau: Was hat dir früher Freude gemacht? Was tust du freiwillig? |
| **5 — „Ich weiß nicht wie"** | Du überschätzt die Größe der Aufgabe | Den Traum in so kleine Schritte zerlegen, dass der nächste machbar ist |
| **6 — „Was denken die anderen?"** | Du nimmst Rat von Menschen an, deren Leben du nicht willst | Bei jedem Ratgeber fragen: „Will ich das Leben dieser Person?" |
| **7 — „Ich hab's schon versucht"** | Du behandelst Scheitern als Endpunkt statt als Daten | Frage: „Was habe ich gelernt? Was würde ich anders machen?" |

Kernbotschaften: Die Lösung für eine Stufe funktioniert nicht auf einer anderen — deine identifizieren, dann kennst du deinen Hebel. Und: Du musst nicht die ganze Treppe auf einmal nehmen — ein Schritt reicht für jetzt.

Zu Stufe 5 („Wissen ist nur einen Knopfdruck entfernt") und Stufe 7 (Scheitern trägt Informationen in sich) klingt direkt Marcos Signature-Thema an — [[Der Bruch als Bauplan]]: Gescheiterte Versuche sind keine Endpunkte, sondern Daten für den klügeren nächsten Versuch.

**Aufgabe:** Deine Stufe identifizieren · die eigene Ausrede ausformulieren und sichtbar machen · den ersten winzig-kleinen Schritt definieren (der, der morgen möglich ist).

---

## 06c · Dein Traum — Finden & Befreien

*(Teil 3 von 3)*

Zwei Teile: erst den Traum finden, dann sich befreien, ihn zu leben.

**Teil 1 — Den Traum finden (Rückblick-Ansatz):** Die meisten suchen ihren Traum in der Zukunft („Was will ich werden?") und landen im Leeren. Simon dreht es um: Schau zurück, um zu verstehen, WER du bist. Der Traum liegt in dir und war meist die ganze Zeit da.

*Die Likes-&-Dislikes-Übung:* Zwei Spalten („Was mag ich?" / „Was mag ich nicht?"), 20 Minuten, kein Filter — Tätigkeiten, Situationen, Umgebungen, Menschen, Themen. Dann fragen: „Wie würde ein Leben aussehen, in dem die linke Seite maximal und die rechte minimal ist?" Der Traum ist die verdichtete Version deiner Likes. Oft reicht ein ehrlicher Nachmittag mit Papier und Stift.

**Teil 2 — Die 3 Freiheiten:**

1. **Finanzielle Freiheit:** Fixkosten senken (Leasing, große Wohnung, Abos). Die Frage ist nicht „Wie verdiene ich mehr?", sondern „Wie viel brauche ich wirklich, um meinen Traum zu verfolgen?". Jeder eingesparte Euro ist ein Euro weniger Druck. Kein Aufruf zur Armut, sondern zur Klarheit.
2. **Mentale Freiheit:** Befrei dich vom Glauben, harte Arbeit allein löse alles — harte Arbeit ohne Klarheit führt nur zu Erschöpfung. Erfolg kommt aus Klarheit + Konsequenz. Limitierende Glaubenssätze erkennen, hinterfragen („Stimmt das? Wer hat mir das beigebracht? Dient er mir?") und durch realistischere Versionen ersetzen.
3. **Die Idee befreien:** Solange der Traum nur im Kopf lebt, ist er fragil. Ausgesprochen wird er real — erst mit einer Vertrauensperson, dann mit mehr, dann in einer Community. Jedes Aussprechen macht ihn klarer und dich committeter. Die meisten Träume verhungern im stillen Kämmerlein.

**Die Zeitachse (SMART Goals):** Wo will ich in 1 Woche / 1 Monat / 1 Jahr sein? Ganz konkret, keine Platitüden. Beispiel: „Bis nächste Woche Traum-Satz fertig · bis Monatsende mit drei Menschen geteilt · bis Jahresende ersten konkreten Schritt realisiert." Planen ist der erste Akt des Tuns.

**Aufgabe:** Likes-&-Dislikes-Liste · die 3 Freiheiten durchgehen und je einen nächsten Schritt definieren · Zeitachse schreiben.

---

## 07 · Klarheit über dein Angebot

Das häufigste Problem: „Ich mache eigentlich alles für jeden." Genau das macht austauschbar, drückt den Preis und macht das Verkaufen schwer — weil man selbst nicht weiß, wen man anspricht.

**Die 4 Elemente eines klaren Angebots:**

1. **WHO — Zielgruppe:** Nicht „alle Selbständigen 25–45", sondern konkret, z. B. „Coaches, die bereits erste Kunden haben und auf konstante 10.000 €/Monat kommen wollen".
2. **PROBLEM:** Konkret und schmerzhaft, z. B. „weiß nicht, wie sie planbar Neukunden gewinnt — Kompetenz da, aber Vertrieb läuft nicht".
3. **LÖSUNG:** Was genau, in welchem Zeitraum, was bekommt der Kunde? (z. B. 90-Tage-Programm mit klaren Bausteinen).
4. **ERGEBNIS (wichtigster Punkt):** Was verändert sich im Leben des Kunden? Menschen kaufen keine Dienstleistungen, sondern **Transformationen** — das Leben nach der Zusammenarbeit.

**Der Pitch-Satz:** *„Ich helfe [Zielgruppe] dabei, [Problem] zu lösen, indem ich [Lösung] anbiete — damit sie [Ergebnis] erreichen."* Einsetzbar in Marketing, Verkaufsgespräch und LinkedIn-Bio.

**Angebot-Pyramide:** WHO + WHAT → Methode → Result/Outcome → Transformation.

**Preisstruktur:** Zu niedrige Preise entstehen meist nicht aus zu wenig Wert, sondern aus einem zu diffusen Angebot. Ein klares Angebot rechtfertigt einen höheren Preis.
- **Low-Ticket** (Kurs, eBook, Template) → Lead-Generierung
- **Mid-Ticket** (Group Coaching, Signature-Programm) → skalierbar
- **High-Ticket** (1:1, VIP-Day, Done-for-You) → 20 % der Zeit, 80 % des Einkommens

**Value Proposition / USP:** Warum du und nicht die anderen? Unique Experience · Unique Approach · Unique Results.

**Angebot-Audit (diese Woche):** Habe ich eine super-spezifische Zielgruppe? Kann ich das Problem in einem Satz beschreiben? Weiß der Kunde genau, was er bekommt? Ist die Transformation messbar und verlockend? Rechtfertigt mein Angebot einen höheren Preis als die Konkurrenz? — Danach: Pitch auf 5 Menschen testen, Feedback sammeln, optimieren.

> **Mindset-Anker:** Der One-Liner „Ich helfe [Zielgruppe] dabei, [Problem] zu lösen" ist nicht nur Marketingformat, sondern Fundament jeder Akquise-Konversation — besonders auf LinkedIn (→ [[Outreach-Stil LinkedIn]]). Und: Wer in Stunden/Sessions verkauft, konkurriert über den Preis; wer das Ergebnis verkauft, kann jeden Preis verlangen, der dem Wert der Transformation entspricht.

---

## 08 · Kundenavatar

Vertiefung und praktisches Ausfüllen des **Kundenavatar-Worksheets**. „Selbständige zwischen 25 und 45, die mehr Umsatz wollen" ist keine Zielgruppe, sondern eine demografische Beschreibung — damit lässt sich kein gutes Marketing machen. Der Kunde ist ein Mensch mit Ängsten, Wünschen und Überzeugungen; je besser man ihn kennt, desto besser spricht man mit ihm.

**Die 3 Teile:**

1. **Demografische Daten:** Geschlecht, Alter, Beziehungsstatus, Beruf, Einkommen, Auto, Hobbys, Bücher, Freunde, Wochenprogramm, Weiterbildung, alltägliche Sorgen — die Oberfläche.
2. **Psychografisches Profil (entscheidend):** Nische · Ausgangssituation vor deiner Leistung · Wunschsituation · Abendgedanken/was hält nachts wach · welche Sorgen du löst · Ängste & Wünsche (**1:1-Aussagen!**) · wie deine Dienstleistung das größte Problem löst · welche Werte er verkörpert · Vorbilder · worauf/auf wen er wütend ist · welche Sprache, Analogien und Metaphern die Zielgruppe benutzt.
3. **Expertenavatar / Marktanalyse:** Was will die Zielgruppe in ihren Augen? Merkmale der Big Player und Reaktion darauf? Welche Anbieter sind wirklich erfolgreich — und was machen sie anders?

**Kernprinzip:** Aussagen wörtlich notieren. Sagt der Kunde „ich fühle mich wie ein Hamster im Rad", notiert man genau das — diese Sprache trifft und resoniert und entscheidet zwischen einem weggescrollten Post und einem „Hey, der spricht über mich" (→ [[Relevanz]]). Das Worksheet ist kein Einmal-Dokument, sondern wird nach jedem Gespräch gepflegt.

> **Mindset-Anker:** Echte Neugier an anderen Menschen ist ein Wettbewerbsvorteil — der Kundenavatar ist die systematisierte Form dieser Neugier. Und: Vertrauen entsteht nicht durch Beeindrucken, sondern durch das Gefühl, wirklich gesehen zu werden — die exakten Worte der Kunden zu verwenden, sendet das Signal „Ich kenne dein Problem".

---

## 09 · Planbarkeit

Fehlende Klarheit in der Akquise führt zu fehlendem Vertrauen und ständiger Getriebenheit („Woher kommt der nächste Kunde?"). Vertrauen entsteht, wenn man genau weiß: Wenn ich X, Y, Z mache, erreiche ich mein Ziel. Diese Lektion dient als Reminder, typische Fehler zu erkennen und umzustellen — kein Hoffnungs-Business, sondern Planbarkeit.

**Zentrale Prinzipien:**
- **Einer Strategie treu bleiben** und sie ausreizen, statt ständig zu wechseln (Strategie-Hopping bringt nichts).
- **80 % der Zeit** gehören — besonders am Anfang — in Marketing und Vertrieb. Stress kommt selten von „zu viel zu tun", sondern davon, nicht zu wissen, wie man an die Ziele kommt.
- **Kein Hoffnungsmarketing/-vertrieb:** Empfehlungen und reines Reels-/TikTok-Posten sind Hoffnung („Ich hoffe, jemand meldet sich"). Empfehlungen nur ergänzend, nie als Hauptkanal.
- **Größten Hebel finden:** Wie hast du die letzten 5 Kunden gewonnen? Welche Tätigkeit hat den größten Hebel? (Beispiel: ein Social-Media-Coach fokussierte sich komplett auf Direktnachrichten + Standard-Posts und generierte darüber massiv Calls und Kunden.) Alles ohne Hebel wird gestrichen.
- **Niemals so akquirieren, wie du selbst nicht akquiriert werden willst.**

**Das Planbarkeits-System (Mathematik des Vertrauens):**

| Nachrichten | Erstgespräche | Beratungen | Kunden |
|---|---|---|---|
| 50 | 10 | 4 | 1 |
| 100 | 20 | 8 | 2 |
| 200 | 40 | 16 | 4 |

(Bewusst konservative Zahlen.) Wer seine Quoten kennt, weiß: „50 Nachrichten heute = 1 Kunde." Das gibt Vertrauen — selbst nach einer krankheitsbedingten Pause weiß man, dass man danach wieder anfängt und gewinnt.

**Kanäle:** LinkedIn DMs · Cold Calls · Instagram + DMs · E-Mail-Outreach (alle planbar) — Empfehlungen sind Hoffnung. **Entscheidung: einen (max. zwei) Kanal wählen und Monate durchziehen.**

> **Mindset-Anker:** 200 Nachrichten klingen viel — aber 200 ÷ 5 Tage = 8/Tag. Wer die Zahlen kennt und täglich einen kleinen Schritt macht, baut echte Planbarkeit ohne Überforderung. Und: Vertrauen entsteht durch Verlässlichkeit — planbare Akquise IST eine Form von Vertrauensaufbau. Planbarkeit beginnt mit einer Entscheidung: dieser Kanal, diese Woche, diese Zahlen, keine Ausreden.

---

## 10 · Akquise und Wochenziele

Übersetzung aller Grundlagen (Vision, Werte, Angebot, Zielgruppe) in konkrete Wochenaktionen. Viele denken zu abstrakt („Ich möchte diesen Monat Neukunden gewinnen") — entscheidend ist: Wie viele genau, über welchen Weg, was tust du konkret diese Woche?

**Die 3 Akquise-Kanäle:**
1. **Inbound** (Content, Sichtbarkeit, Empfehlungen): braucht Zeit, skaliert langfristig, sehr hohe Conversion.
2. **Outbound** (aktive Ansprache: LinkedIn, Cold Mails, direkte Kontaktaufnahme): zuverlässigster Weg für planbare Gespräche, weil man selbst die Kontrolle über Menge und Timing hat.
3. **Partnerships** (Empfehlungspartner, Joint Ventures): höchste Conversion, setzt aber aufgebaute Beziehungen voraus.

Die Frage ist nicht, welcher Kanal der beste ist, sondern welcher für dich am effektivsten ist und den du **konsistent durchhältst**. Konstanz schlägt Talent — immer.

**Wochenziele statt Monats-/Jahresziele:** Konkrete Zahlen, z. B. „Diese Woche: 20 LinkedIn-Nachrichten, 3 Erstgespräche, 1 Partnerschafts-Call." Am Freitag kurzes Review: Ziele erreicht? Was hat funktioniert? Was mache ich nächste Woche anders?

**Beispielrechnung (10 Kunden/Monat):** Inbound 3 + Outbound 5 + Partnerships 2. Pro Woche u. a. 15–20 Cold Contacts. Mit einfachem Tracker (z. B. Trello), täglich aktualisiert, Freitag-Review.

**Psychologie der Akquise:** „Nein" ist keine Ablehnung der Person, sondern „nicht jetzt / nicht zu dir / nicht das Problem". Es ist ein Zahlenspiel: Wenn 1 von 10 „Ja" sagt, brauchst du 10 Kontakte — nicht 100 „perfekte", nur 10 normale.

**Letzter Gedanke:** Klein anfangen, aber anfangen. Eine realistische Woche, die man durchzieht, ist wertvoller als eine ambitionierte, bei der man nach drei Tagen aufhört. Ziele, die fordern, aber nicht überfordern.

> **Mindset-Anker:** Unsere Welt trainiert auf sofortige Belohnungen — wer in der Akquise konstant bleibt, auch wenn kurzfristig nichts passiert, hat einen massiven Vorteil gegenüber allen, die nach 3 Wochen aufhören. Und: Akquise wird selten prokrastiniert, weil sie unangenehm ist, sondern weil unklar ist, was zu tun ist — „Heute um 10 Uhr 10 LinkedIn-Nachrichten nach diesem Skript" lässt nichts zu prokrastinieren übrig.

---

## 11 · Abschluss Klarheit

Zusammenfassung des Moduls: herausgearbeitet wurden Vision und innere Antreiber, Ziele, Werte für dich und deine Brand, glasklare Zielgruppe und deren Marketing-Ansprache, Vertriebsstrategie und ein gut gestaltetes Angebot. Das erzeugt ein Freigefühl — „Jetzt kann ich umsetzen." Das Fundament des Hauses steht; im nächsten Modul (High Performance) werden die Schienen gelegt: Systeme, die dich automatisch produktiv, fokussiert und regelmäßig in Marketing und Akquise bringen.

**Klarheits-Checkliste (ehrlicher Check vor Modul 2):**
- *Vision & Anti-Vision:* alle 7 Lebensbereiche schriftlich · Anti-Vision definiert · Clarity Sheet täglich lesen
- *Werte & Brand:* 5 Unternehmenswerte mit eigener Definition · mind. 10 Punkte, die dich besonders machen · 3–6 Verkaufsargumente
- *Angebot & Zielgruppe:* 4 klare Elemente (Zielgruppe, Problem, Lösung, Ergebnis) · Pitch in einem Satz · Kundenavatar inkl. psychografischem Profil und 1:1-Aussagen
- *Akquise & Planbarkeit:* primärer Kanal gewählt · Planbarkeits-Quote definiert · konkrete Wochenziele in Zahlen

**Das tägliche Ritual (Nils' Empfehlung):** Clarity Sheet jeden Tag durchlesen — (1) wichtige Reminder, (2) Verkaufsargumente (warum ist mein Angebot so wichtig?), (3) Vision 3–5 Minuten visualisieren, (4) Werte und Ziele. Nach jedem Coaching-/Beratungsgespräch: Kundenavatar-Sheet mit neuen Aussagen aktualisieren.

> **Mindset-Anker:** Klarheit ohne Umsetzung ist Prokrastination in neuem Gewand — das Gefühl „Jetzt weiß ich, was ich tun muss" muss sofort in Handlung überführt werden; wer auf Perfektion wartet, wartet für immer. Und: Klarheit ist kein einmal erreichter Zustand, sondern ein Muskel — das tägliche Clarity Sheet und das Aktualisieren des Kundenavatars sind das Training, das Klarheit dauerhaft hält.

---

## Querverweise

- [[Inner GOAT Academy]] — Gesamtstruktur des Kurses
- [[Storytelling Wissen]] — zentraler Wissens-Ordner
- [[Der Bruch als Bauplan]] — Scheitern als Daten (Traum-Stufe 7, Rebirth-Plot)
- [[Die 12 Plots]] — Rebirth/Überwindung des Monsters als narrative Muster hinter dem Traum
- [[Relevanz]] — die exakte Sprache der Zielgruppe treffen (Kundenavatar, Verkaufsargumente)
- [[Outreach-Stil LinkedIn]] — Anwendung des Angebots-One-Liners in LinkedIn-Akquise
