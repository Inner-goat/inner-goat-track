---
type: wissen
tags: [academy, high-performance, fokus, produktivitaet, planung, energie, geduld, routinen]
reiter: Reiter 1 – Implementierung
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 2 – High Performance

Dieses Modul ist das Fundament der [[Inner GOAT Academy]] und steht bewusst ganz am Anfang: Bevor tiefere Blockaden- und Mindset-Arbeit greifen kann, braucht es Strukturen, mit denen wirklich in die Umsetzung gekommen wird. Der Kern des Moduls ist die Beobachtung, dass die meisten Selbstständigen nicht an fehlendem Wissen scheitern, sondern an fehlendem Fokus, fehlenden Systemen und einem chronisch übersteuerten Dopamin- und Energiehaushalt. Sie arbeiten viel, kommen aber nicht voran.

Der Aufbau geht von ganzheitlich zu spezifisch: Erst wird Fokus als wichtigste Ressource etabliert und Ablenkung eliminiert (Fokus, Monk Mode, Dopamin, Addition durch Subtraktion). Dann folgt ein konkretes, minimalistisches Planungssystem (Kalender + Trello, 3 Unternehmensrollen, Hebel-Denken). Danach kommen die stabilisierenden Fundamente (Aufräumen, Cut-Eliminierung, Absichts-Technik) und schließlich der ganzheitliche Unterbau: Energie, Geduld und tägliche Routinen. Rote Grundregel: Nicht konsumieren — umsetzen. Jede Lektion hat eine konkrete Aufgabe und eine Community-Aufgabe.

Thematisch grenzt das Modul an mehrere Konzepte aus dem [[Storytelling Wissen]]: Wer nach Outcome statt Stunden denkt und in Hebeln handelt, verkauft [[Relevanz]] statt Beschäftigung — und Marcos Signature-Winkel [[Der Bruch als Bauplan]] taucht implizit auf, wo Adversity, Resilienz und "School of Hard Knocks" zum Wachstumsbauplan werden.

---

## 01 · Einführung High Performance

Rahmen-Video für das gesamte Modul. Kernproblem: Viele arbeiten 8–10 Stunden am Tag, sind scheinbar produktiv, aber die Ergebnisse bleiben aus — nicht aus Faulheit, sondern weil sie die falschen Dinge tun bzw. die falschen (oder gar keine) Systeme haben. Der Hauptgrund für ausbleibende Ergebnisse ist Prokrastination, also das Nicht-Umsetzen von bereits vorhandenem Wissen.

High Performance beginnt nicht mit einer neuen Technik, sondern mit dem Entfernen aller Ablenkungen ("modern day gladiators"). Der Ansatz ist ganzheitlich → spezifisch: erst generell Fokuskiller im Leben eliminieren, dann business-spezifisch die wirklich wichtigen Aufgaben herauskristallisieren, dann Kalender/Planung, dann Produktivitätstricks. Explizite Absage an oberflächliche "Hacks" (Pomodoro & Co. machen nicht erfolgreich).

**Modul-Überblick laut Begleitdokument:** 1. Fokus, 2. Monk Mode, 3. Dopamin, 4. Planungssystem (Trello + Kalender), 5. Hebel-Denken, 6. Addition durch Subtraktion.

**Community-Aufgabe:** Größten Produktivitäts-Killer in einem Satz benennen.

---

## 02 · Fokus

Kernthese: **Fokus ist heute die wichtigste und knappste Ressource** — knapper als Geld, Zeit oder Energie, weil diese drei ersetzbar sind, Fokus in einer auf Ablenkung ausgelegten Welt aber kaum.

| Ressource | Ersetzbar durch |
|---|---|
| Geld | Fähigkeiten aufbauen, mehr verkaufen |
| Zeit | Delegieren, outsourcen |
| Energie | Schlaf, Ernährung, Sport |
| **Fokus** | Kaum ersetzbar |

**Die 5 Gesetze des Fokus:**
1. **Ablenkungen eliminieren** — Handy, Internet, Social Media, andere Menschen, auch eigene Gedanken.
2. **Dopaminpegel managen** — hoher Pegel durch Scrollen macht "langweilige" Aufgaben schwer; Lösung: Dopamin-Detox.
3. **Wichtige vs. unwichtige Aufgaben unterscheiden** — eine Aufgabe ist wichtig, wenn sie dem Ziel näherbringt. ~80 % der Zeit = Marketing & Vertrieb.
4. **Zeitblockplanung** — Tag in konkrete Blöcke, Pufferzeiten, Deep-Work-Blöcke.
5. **Kopf leeren** — ablenkende Gedanken sofort aufschreiben; "Dein Kopf ist zum Denken da, nicht zum Speichern."

Weitere Kernideen: Shiny Object Syndrome (Aufmerksamkeit wandert zum Neuen, nicht zum Besseren); High Performer denken in Outcome statt Stunden (20 Std. mit 10× Output schlagen 60 Std.); Delegieren, wenn eine Aufgabe nur Zeit, aber nicht Energie/mentale Kapazität kostet. Praxis-Trick bei akuter Ablenkung: aufschreiben, was ablenkt, dann weiterarbeiten.

**Community-Aufgabe:** Fokuskiller benennen und mit einem Partner einen 24h-Dopamin-Detox mit gegenseitiger Accountability machen.

---

## 03 · Monk Mode

Monk Mode = mehrere Stunden extremer Fokussierung: Handy aus, Internet aus, keine Unterbrechungen, **eine einzige große Aufgabe**. Faustregel: 4 Stunden Monk Mode ≈ 2 normale Arbeitstage.

**Ablauf (3 Phasen):**
- **Vorbereitung (30 Min):** eine große Aufgabe wählen, alles bereitlegen, Team informieren ("9–13 Uhr nicht erreichbar"), alles abschalten (Handy AUS, nicht nur stumm).
- **Deep Work (4–8 Std):** No-Interruption-Mode, Blöcke von 60–90 Min mit kurzen Pausen (15 Min nach 60 Min, nicht am Handy, aufstehen, Wasser).
- **Ausstieg (15–30 Min):** aufschreiben, was erledigt wurde (Completion-Gefühl), nächsten Schritt notieren, wieder anschalten, Progress reviewen.

**Wann:** große Projekte, Deadlines, maximale Qualität, Aufholen, Einarbeitung. **Wann nicht:** normaler Workflow reicht, kleine Aufgaben, keine Deadline. Nicht täglich — **2–3× pro Woche**, sonst Burnout-Risiko. Am besten morgens (frisches Gehirn), nicht nach 15 Uhr starten. Instrumentale Musik ohne Worte (Lo-Fi, Ambient, Binaural Beats).

**Häufige Fehler:** zu viele Tage hintereinander, Internet "ein bisschen an", Handy "nur kurz", zu lange Blöcke ohne Pause, falsches (unterbrechungsanfälliges) Projekt.

Verweist auf das Prinzip "Komfortzone verlassen" — Monk Mode fühlt sich anfangs unbequem an, genau daraus entsteht Wachstum.

**Community-Aufgabe:** Datum + Zeitfenster des ersten Monk-Mode-Blocks posten, Accountability-Partner suchen.

---

## 04 · Monk Mode Umsetzung

Umsetzungsvideo, das das Konzept in einen konkreten Aktionsplan übersetzt. Grundproblem: Man versteht Monk Mode, findet es super — und macht es nie. Antwort: radikale Selbst-Accountability ("Don't blame other people why you will not make it").

**7-Schritte-Action-Plan:**
1. **Projekt wählen (heute):** Welches Projekt nervt am meisten / hätte größten Impact? Aufschreiben.
2. **Termin blocken:** morgen/übermorgen, min. 4 Std (z. B. 9–13 Uhr), Ort festlegen.
3. **Materialien sammeln:** alle Dateien/Tools am Vorabend bereit, Handy in Flugmodus.
4. **Team informieren:** 24 Std vorher kurze Nachricht, Status auf "Do Not Disturb".
5. **Environment vorbereiten (Vorabend):** Schreibtisch aufräumen, laden, Wasser/Snacks.
6. **Morning Ritual (30 Min vorher):** Frühstück, kaltes Wasser, 5 Min Dehnen, 1 Min Box-Breathing (4-4-4), Tagesfokus aufschreiben.
7. **Erste Session durchziehen:** 4 Std, 60-Min-Blöcke mit Pausen; abschweifende Gedanken notieren, bei Müdigkeit aufstehen.

Danach: Ergebnis + Take-aways festhalten (Completion als Treibstoff), Handy wieder an. Frequenz: 2–3×/Woche, nach ~3 Wochen Routine. Enthält Tracking-Tabelle (Datum/Projekt/Stunden/Ergebnis) und 10 Beispielprojekte (Sales Page, Content-Kalender, Kurs entwickeln, Rebranding etc.). Leitprinzip: schrittweise vorgehen — "Think smaller, not bigger".

**Community-Aufgabe:** Ergebnis des ersten Blocks + ehrlicher Bericht über Ablenkungen teilen.

---

## 05 · Dopamin verstehen

Neurobiologische Grundlage für Fokus und Disziplin. Dopamin = Botenstoff/"Glückshormon", das in die Umsetzung bringt. Zentrale Bilder:

- **Eine universelle Batterie:** nicht je eine für Sport/Business/Serien — alles zieht aus demselben Speicher.
- **Evolutionärer Sinn:** Dopamin wurde bei Belohnung (Jagd-Erfolg) ausgeschüttet und flachte danach wieder ab, damit man erneut aktiv wird.
- **Basiswert vs. Spitzenwert:** Konsum (Reels, TikTok, Zucker) treibt den Pegel auf einen Spitzenwert. Danach fällt er nicht zurück auf den Basiswert, sondern *darunter* → Antriebslosigkeit, Gefühl von Leere, teils "depressive" Phasen.
- **Habituation:** Je öfter man denselben Reiz konsumiert, desto niedriger Spitzen- *und* Basiswert; man hat immer weniger Energie für andere Dinge.

Die moderne Welt trainiert Instant Gratification (3 Klicks → Paket/Pizza). Ein Business funktioniert aber nicht per Klick — es braucht ausdauernde Energie. Die Welt (Amazon, Netflix, Google) trainiert aktiv Ungeduld — Anknüpfungspunkt zu Lektion 18.

**Lösung — Dopamin-Detox:** Social Media bewusst reduzieren; ersten Arbeitsblock im Flugmodus erledigen; die erste Stunde des Tages nicht aus dem Flugmodus gehen; größte Dopaminquellen identifizieren und reduzieren. Wichtigste Haltung: bei akuter Motivationslosigkeit nicht das ganze Leben überdenken, sondern annehmen ("Pegel ist gerade niedrig, kommt in ein paar Stunden zurück").

**Community-Aufgabe:** Täglichen Handy-/Social-Media-Konsum schätzen (Minuten) und Wochenziel definieren.

---

## 06 · Addition durch Subtraktion

Prinzip: **Addition der Qualität / des Wertes (Geld, Zeit, Energie) durch Subtraktion der Aufgaben.** Mehr erreichen durch Weglassen des Falschen.

Lebens-Beispiel: Ein Bekannter lud weniger Hochzeitsgäste ein → mehr Qualität. Analog Freundeskreis: weniger, aber tiefere Verbindungen.

**Coaching-Praxis:** Kunden von 1.000–3.000 € auf konstant 10.000 €/Monat in 2–3 Monaten. Vorgehen: (1) Analyse "Was machst du den ganzen Tag?", (2) ~70 % der Aufgaben waren nicht umsatzproduzierend, (3) diese 70 % gestrichen, (4) Kalender mit umsatzproduzierenden Aufgaben neu gefüllt, (5) Ergebnis: 3× Umsatz bei weniger Arbeitsstunden.

**3 Aufgaben-Kategorien:** ✅ umsatzproduzierend (mehr davon) · ⚠️ business-relevant (effizient halten) · ❌ Zeitfresser (streichen).

Ergänzende Prinzipien: "Do what you are good at and outsource the rest" (nicht selbst die Steuer machen, wenn es nicht die Superkraft ist) und Outcome statt Stunden ("Stop selling time and start buying it"). Warnung vor Pseudo-Optimierung (Kreatin-Timing, Posting-Uhrzeit) — stattdessen "Back to the Basics": **Vertrieb, Marketing, Kundenpflege**.

**Aufgabe (3-Tage-Audit):** Alle 30 Min aufschreiben, was man getan hat; jede Aufgabe markieren "umsatzproduzierend: ja/nein"; alles mit "nein" streichen oder delegieren.

**Community-Aufgabe:** Ergebnis des 3-Tage-Audits teilen (% umsatzproduzierender Zeit).

---

## 07 · Einführung ins Planungssystem

Einleitung in den Planungsteil. Grundregel: **So wenig Aufwand wie nötig — aber alles abgedeckt.** Der Autor hat Notion, Asana, Trello, diverse Kalender und Post-its ausprobiert; das empfohlene System ist das minimalistischste, das trotzdem alles abdeckt. Empfehlung: 1:1 übernehmen und min. 2 Wochen konsequent testen (bis es Gewohnheit wird) — selbst Kunden, die dachten, ihr System sei gut, waren nach zwei Wochen überzeugt.

Warum Planung nicht optional ist: Ohne Planung kreisen zu viele Gedanken im Kopf ("da muss ich noch…"), Termine werden vergessen, Wichtiges wird verschoben, man reagiert statt zu gestalten. Ziel: **ein zweites Gehirn** aufbauen, das mentale Kapazität für die wirklich wichtigen Aufgaben (Sales, Neukunden, Kundenbetreuung) freihält. "Dein Kopf ist zum Denken da, nicht zum Speichern."

System-Bausteine: **Kalender** (Termine, Zeitblöcke, WANN) + **Trello** (Aufgaben, Projekte, WAS). Woran schlechte Systeme scheitern: Post-its (verlierbar, nicht durchsuchbar), zu komplexes Notion, oder gar kein System.

**Community-Aufgabe:** In einem Satz beschreiben, welches Planungssystem aktuell genutzt wird.

---

## 08 · 3 Ebenen im Unternehmen

Grundlage für die Planungsstruktur: drei Rollen, die (auch als Solo-Selbstständiger) integriert werden müssen. Wald-Metapher:

| Rolle | Aufgabe | Metapher | Rhythmus |
|---|---|---|---|
| 👷 Arbeiter | Aufgaben stumpf abarbeiten | fällt die Bäume | täglich (Arbeitszeit) |
| 💼 Manager | plant & organisiert | entscheidet welcher Baum, wann, wie | täglich (jeden Abend) |
| 🏆 Unternehmer | gibt Richtung & Vision vor | prüft, ob es der richtige Wald ist | wöchentlich (So/Fr) |

Integration ins System: Der **Unternehmer** reflektiert wöchentlich (Vision, Werte, Ziele, Kurs) und plant grob. Der **Manager** plant jeden Abend den nächsten Tag im Detail und koordiniert die Trello-Karten. Der **Arbeiter** arbeitet morgens einfach ab, was Manager und Unternehmer bereits entschieden haben — keine morgendliche "Was mache ich heute?"-Entscheidung mehr, maximale mentale Energie für die Ausführung.

**Community-Aufgabe:** Ehrlich einschätzen, in welcher Rolle man aktuell die meiste Zeit verbringt.

---

## 09 · Trello Einführung

Praktisches Setup-Video für Trello als Aufgaben-Management (das "WAS"). Trello wird empfohlen, weil es einfach ist und über App + Desktop synchronisiert. Trello = externes Gehirn ("Dein Kopf ist zum Denken da, nicht zum Speichern").

**Setup:** Download → Account → gleiches Login auf allen Geräten → neues Board (z. B. "Strategie & Planung").

**7 Listen (in dieser Reihenfolge):**
1. Task / Aufgaben
2. Wochentag / Heute
3. Im Prozess / Warten auf
4. Erledigt / Done
5. Fokus (Top 1–3 der Woche)
6. Blog / Marketing / Ideen
7. Posting-Ideen

**Karten-Format:** `[Aufgabe] ([geschätzte Zeit])`, z. B. "LinkedIn Beiträge schreiben (60 Minuten)". Die Zeit MUSS dahinterstehen — sie ist Voraussetzung für die Kalenderplanung. Wirklich **alles** eintragen, auch Privates (Zahnarzt, Umsatzsteuervoranmeldung, 5-Min-Tasks).

**Karten-Features:** Labels (Empfehlung: Eisenhower-Matrix — wichtig/dringend-Achsen), Fälligkeitsdatum (wird 24h vorher rot), Checklisten **nur bei echten Großprojekten** (nicht überplanen), Karten per Drag & Drop zwischen Listen. Ein Board pro Person; Team-Aufgaben in ein separates Board.

**Workflow:** Am Vortag (z. B. Montag 18 Uhr) den nächsten Tag planen — Karten von "Task" nach "Wochentag" schieben; abends erledigte Karten archivieren.

**Community-Aufgabe:** Screenshot des fertigen Boards mit ersten Karten posten.

---

## 10 · Kalenderplanung & Trello

Integration beider Tools: **Trello = das WAS, Kalender = das WANN.** Beide brauchen einander.

**Prozess:**
1. Alle Aufgaben in Trello (mit geschätzter Zeit) sammeln.
2. **Immer am Vorabend planen** (z. B. 17–18 Uhr, nie morgens): abends ist man entspannter, sieht klarer, kann morgens ohne Entscheidung sofort loslegen.
3. Fixe Termine im Kalender ansehen → Trello-Aufgaben in die freien Slots blocken; jede Aufgabe bekommt einen festen Block.
4. Aufgaben in Trello nach "Wochentag" verschieben.

**Regeln:** Nicht zu 100 % planen — bei 8 verfügbaren Stunden nur ~6 verplanen, 2 Std Puffer (immer läuft etwas anders). Focus Blocks (1–2 Std, geschützt: keine Meetings/Mails/Handy) für die Top-Priorität einplanen. Nicht zu kleinteilig (nur Aufgaben ≥ 15–20 Min), klare Anfangszeiten (volle/halbe Stunden). Abend-Review: Erledigtes archivieren, Nicht-Erledigtes zurück in "Task". Der Plan ist nicht heilig — flexibel anpassen.

Anknüpfung: schrittweise Tagesplanung ("simple daily steps") und das zweite Gehirn als Energie-Management, nicht Bürokratie.

**Community-Aufgabe:** Geplanten Focus-Block für morgen (Uhrzeit + Task) teilen, Partner suchen, nachher checken.

---

## 11 · Denke in Hebeln

Prinzip: **den größten Hebel betätigen — mit minimalem Aufwand maximales Ergebnis.** Drei Hebelarten: Geld, Zeit, Energie. Viele Aufgaben kosten so viel Energie schon zum Anfangen, dass für das Ergebnis kaum etwas übrig bleibt.

**Praxis-Beispiel (Videograph):** Monatelang Social Media mit viel Geld/Zeit/Energie → 1 Kunde. Dann 40 bestehende Firmenkontakte angerufen (wenige Tage) → 5 Kunden / 5 Imagevideos. Der Hebel "bereits aufgebautes Vertrauen im Netzwerk" schlug Social Media deutlich. Weitere Beispiele: Netzwerk-Intros reaktivieren statt neu online akquirieren; totes Kapital aus einer alten Firma freimachen statt mühsam neue Leads jagen.

**Reflexionsfragen:** Wie hast du deine letzten 5–10 Kunden gewonnen? Welcher Kanal hatte den größten Hebel? Warum hast du damit aufgehört? Was sind deine Low Hanging Fruits (wen könntest du sofort anrufen)?

**Hebel-Matrix:** niedriger Aufwand/hohes Ergebnis = Priorität 1 · hoch/hoch = später oder delegieren · niedrig/niedrig = nur wenn Zeit · hoch/niedrig = streichen.

Zentral: kein pauschales richtig/falsch — der eigene natürliche Stil ist der größte Hebel (introvertiert → LinkedIn, extrovertiert → Netzwerkevents, telefonaffin → Cold Calling). Der Connector, der Vertrauen reaktiviert, ist einer der stärksten Netzwerk-Hebel.

**Community-Aufgabe:** Welcher Akquise-Kanal hatte den größten Hebel — und welchen nutzt du gerade? Wenn abweichend: warum?

---

## 12 · Aufräumen

Überraschendes, aber laut Autor eines der wichtigsten Videos: Performance beginnt im Umfeld, nicht am Schreibtisch. Leitprinzip: **"How you do one thing is how you do anything."** Zwei Stressquellen: große Dinge (Steuernachzahlung) und viele kleine Dinge (leerer Akku, voller Speicher beim Content-Aufnehmen). Beide reißen aus dem Flow.

**Drei Bereiche:**

**1. Zuhause:** Zimmer, Wohnung, Küche, Kleiderschrank vollständig aufräumen; alles rauswerfen, was 2 Jahre nicht gebraucht/getragen wurde; Briefe sofort öffnen → erledigen → abheften.

**2. Geräte:** Desktop max. 3–4 Ordner, keine losen Dokumente; klare Ordnerstruktur; Handy nur mit täglich gebrauchten Apps (keine Spiele); Speicher/Kamera regelmäßig leeren. (5 Min/Tag Suchen ≈ 30+ verlorene Stunden/Jahr.)

**3. Finanzen** (wichtigster Bereich, weil Steuer-/Geldprobleme mental wochenlang aus der Bahn werfen):

| Konto | Zweck |
|---|---|
| 💼 Business | alle Einnahmen & Business-Ausgaben |
| 🏠 Privat | monatliches Gehalt an sich selbst |
| 💰 Steuer | sofort ~35 % jeder Einnahme zurücklegen |
| 🏦 Puffer | langfristiger finanzieller Puffer ("Goldgrube") |

Monatliche Routine (~1 Std): Einnahmen-Überschussrechnung ausfüllen; Belege in Ordnerstruktur `Jahr > Einnahmen-Ausgaben > Monat`; Gesamtvermögen (alle Konten + Depot) in einer Excel-Tabelle tracken. Steuerberater empfohlen (auch bei Gewerbe). Warnung anhand eines Kunden, der trotz hoher Einnahmen fast pleite war, weil er seine privaten Ausgaben nicht im Blick hatte — Zahlen müssen schwarz auf weiß vorliegen.

Anknüpfung: Disziplin im Kleinen ist Prädiktor für Disziplin im Großen; Accountability beginnt im Kleinen.

**Community-Aufgabe:** 3-Bereiche-Audit machen und teilen, was ausgemistet/geordnet wurde und wie es sich angefühlt hat.

---

## 13 · Death by a Thousand Cuts

Konzept gegen den versteckten Produktivitätskiller vieler kleiner Ablenkungen ("Cuts"). Jeder Cut ist klein (5 Min Handy, 10 Min Instagram), aber die Summe ist massiv. Zentraler Punkt: Nach einer Unterbrechung dauert es bis zu ~23 Minuten, bis man wieder voll im Fokus ist — 5 Unterbrechungen/Tag kosten so fast 2 Stunden tiefer Arbeit. Nicht die Zeit selbst ist das Problem, sondern der wiederholte Wiedereinstieg in den Flow.

Untermauert durch Forschung: Multitasking senkt kognitive Leistung um bis zu 40 % (Meyer & Kieras), "Residual Attention" bei jedem Aufgabenwechsel. Fokus muss aktiv geschützt werden.

**Häufige Cuts:** Handy-Checks (~alle 12 Min), E-Mails außerhalb geplanter Zeiten, "kurze" Social-Media-Checks, sofortiges Beantworten jeder Nachricht, Task-Hopping ohne Abschluss, Prokrastinations-Rituale (Kaffee, Aufräumen), ausufernde Gespräche.

**3 Prinzipien zur Eliminierung:**
1. **Bündeln** — E-Mails 2×/Tag (z. B. 12 & 17 Uhr), Nachrichten in definierten Blöcken.
2. **Barrieren aufbauen** — Handy in einen anderen Raum, Benachrichtigungen aus, Website-Blocker (Freedom, Cold Turkey), "Nicht stören" als Standard.
3. **Cut-freie Zeitblöcke** — die Monk-Mode-Zeiten sind absolute Cut-freie Zonen.

**Aufgabe:** Einen Tag lang jede Ablenkung tracken (Was? Wie lange? Wie oft?), dann die 3 größten Cuts gezielt eliminieren.

**Community-Aufgabe:** 1-Tages-Cut-Tracking machen, die 3 größten Cuts teilen und fragen, wie andere sie eliminiert haben.

---

## 14 · Mehr Effektivität durch Absichten

Quick-Win-Technik, um die letzten 5–10 % aus jeder Aufgabe zu holen. Beobachtung: Wichtige Aufgaben (Sales Calls, Kundenbetreuung, Akquise, Content) werden oft im Autopilot "abgehakt" — dabei geht der eigentliche Sinn verloren.

**Die 2-Minuten-Absichts-Technik:** Vor jeder Aufgabe 2 Minuten nehmen und die Absicht **physisch aufschreiben** (nicht nur denken) und sichtbar hinlegen. Dadurch wird der Sinn vom Unterbewusstsein ins Bewusstsein geholt; man geht mit voller Präsenz und Energie heran und verdrängt störende "Was, wenn"-Gedanken.

**Beispiele:**
- Sales Call: "Meine Absicht ist, die Person abzuschließen und zu zeigen, warum das Angebot ihr Leben verändert."
- Coaching/Kundenbetreuung: "…das Maximale aus diesem Menschen herausholen und ihm optimal helfen."
- LinkedIn-Beitrag: "…einen Beitrag schreiben, mit dem sich Leute wirklich verbinden und der echten Mehrwert gibt."
- Admin: "…so schnell und korrekt wie möglich abarbeiten, um Zeit fürs Wichtige zu schaffen."

Anknüpfung: Das Gehirn kann nur eine Sache wirklich gut — die Absichts-Technik führt es bewusst in den Zustand voller Präsenz. 7 Tage konsequent testen.

**Community-Aufgabe:** Technik heute bei mind. 3 Aufgaben anwenden, Absichten aufschreiben, Feedback teilen.

---

## 15 · Abschluss High Performance

Zusammenfassung und Brücke zum nächsten Modul. Rückblick: Fokus, Monk Mode, wichtige Aufgaben & Hebel, Weglassen, Produktivitäts-Unterstützer, Flow-Zustand, komplettes Planungssystem (Kalender + Trello). Kernbotschaft: Viel Prokrastination entsteht aus fehlender Klarheit ("wann mache ich was?") — die Planungstools schaffen genau diese Klarheit (was/wann/warum).

**Die Blockade-Wahrheit:** Trotz fertigem System machen es viele nicht — das ist kein Produktivitätsproblem, sondern ein Mindset-/Blockaden-Problem (Prokrastination bei bestimmten Aufgaben, Erfolg nicht genießen können, 24/7-Arbeiten, physisch anwesend/psychisch abwesend). Deshalb folgt als Nächstes das **Identitäts-/Mindset-Modul**.

Empfehlung: einzelne Videos (besonders "How you do one thing…" und Fokus) alle paar Wochen erneut ansehen, weil man dazu tendiert, wieder Neues hinzuzunehmen und sich zu zersplittern. Enthält die 3-Wochen-Challenge (Woche 1: Setup + erste Monk-Mode-Session; Woche 2: 2–3 Sessions + tägliche Planung; Woche 3: System läuft automatisch).

Streut mehrere übergreifende Prinzipien ein: **Change = Opportunity = CEO** (jede Veränderung ist Chance für den, der schnell reagiert), **School of Hard Knocks** (keine Shortcuts; aus Adversity lernen statt Opfer spielen; Mentor suchen) und **Cashflow als Timing-Game** (aktiv planen, nicht nur Umsatz). Mantra: "Ich bin nicht unproduktiv. Ich habe nur noch keine Blockaden gelöst."

**Community-Aufgabe:** Größte Erkenntnis aus dem Modul teilen und benennen, welches Video zuerst erneut angesehen wird.

---

## 16 · Energie als Fundament (Teil 1) — Warum Energie wichtiger ist als Motivation

Erweitertes Fundament-Video. Kernaussage: Alle Strategien, Systeme und Mindset-Arbeit funktionieren nur auf einem stabilen Energie-Fundament. Viele scheitern nicht an der Strategie, sondern weil "der Tank leer ist".

**Energie > Motivation:** Motivation ist ein flüchtiges Gefühl. Energie ist eine Ressource, die man aktiv aufbauen, erhalten und schützen kann. Wer gut mit Energie umgeht, braucht keine Motivation — er hat Kapazität. Smartphone-Analogie: beste Apps nützen nichts bei leerem Akku.

**Die 4 Energiequellen (Loehr & Schwartz):**

| Quelle | Aufgebaut durch | Zerstört durch |
|---|---|---|
| Physisch | Schlaf, Bewegung, Ernährung | Schlafmangel, Bewegungsarmut |
| Emotional | positive Verbindungen, Flow | chronischer Stress, Ärger |
| Mental | tiefes Fokussieren, Pausen | Multitasking, Ablenkung |
| Spirituell | Sinn, Werte, Vision | Bedeutungslosigkeit, Dissonanz |

Physische Energie ist das Fundament (Gehirn braucht Sauerstoff und Glukose). Spirituelle Energie ist der tiefste Tank — ohne Sinn brennt man aus, egal wie gut die Schlafroutine ist. Häufigster Fehler: Energie durch Willenskraft ersetzen (durcharbeiten, zu wenig Schlaf, Erholung als Zeitverschwendung). High Performance heißt nicht mehr Stunden, sondern **vollere Stunden** — präsent, klar, kapazitätsvoll (Fokus als Leverage). Eigenverantwortung: täglich Sport, bewusste Ernährung.

**Aufgabe:** Die drei größten Energieräuber aufschreiben.

**Community-Aufgabe:** Die drei größten (oft unbewussten) Energieräuber teilen.

---

## 17 · Energie als Fundament (Teil 2) — Nervensystem & Burnout-Prävention

Vertiefung: Das Nervensystem als eigentlicher Schlüssel zur Burnout-Prävention. Zwei Modi: **Sympathikus** (Gaspedal: Alarm, Aktion, Leistung) und **Parasympathikus** (Bremse: Erholung, Regeneration). Problem: Die meisten Selbstständigen stecken dauerhaft im Sympathikus — der Körper glaubt, in Gefahr zu sein, selbst beim E-Mail-Checken. Chronischer Sympathikus-Stress → schlechterer Schlaf, weniger Konzentration, schwächeres Immunsystem, irgendwann Burnout.

**3 Regulations-Tools:**

| Tool | Technik | Dauer | Wirkung |
|---|---|---|---|
| Physiologisches Seufzen | Doppel-Einatmung durch die Nase + lange Ausatmung durch den Mund | 30 Sek | Herzrate sinkt sofort |
| Temperaturwechsel | kaltes Wasser ins Gesicht / kurz kalt duschen | 30 Sek | Tauchreflex, Cortisol ↓ |
| Bewegte Pause | kurzes Gehen/Stretching zwischen Blöcken | 5–10 Min | Cortisol-Abbau, Reset |

**Anti-Burnout-Logik:** Burnout ist schleichend; man merkt es erst in der roten Zone. Deshalb: **Erholung als Pflicht, nicht als Belohnung.** Profisportler planen genauso viel Erholung wie Belastung ein — Wachstum geschieht in der Pause, nicht im Training. Ergänzt durch das Ruhestandsnetzwerk des Gehirns: schon 12-minütige, ziellose Pausen erhöhen Kreativität und Problemlösung deutlich.

**Energie-Check:** Schlaf (1–10), emotionale Grundstimmung (1–10), echte Pausen (täglich/wöchentlich/selten), Freude an der Arbeit. Mehrere Werte < 6 = Signal zum Gegensteuern. "Dein Nervensystem ist dein wichtigstes Business-Tool."

**Community-Aufgabe:** Ehrliche Position auf der Burnout-Skala (1–10) + größten Stressfaktor teilen.

---

## 18 · Geduld — Die 7 Prinzipien

Video über Geduld als unterschätzten, aber starken Erfolgshebel — nicht als Floskel, sondern als trainierbare Superkraft. Direkte Verbindung zum Dopamin-Video (Lektion 05): Die Welt der Sofortigkeit trainiert Ungeduld.

**Die 7 Prinzipien:**
1. **Geduld ist ein Muskel** — trainierbar durch bewusstes Üben (Sarah Schnitker); kein angeborenes Talent.
2. **Dein Gehirn hasst dein Zukunfts-Ich** — das Selbst in 10 Jahren aktiviert dieselben Hirnregionen wie ein Fremder (Stanford). Tipp: Zukunfts-Ich bildlich visualisieren → bessere langfristige Entscheidungen.
3. **Die Welt macht dich absichtlich ungeduldig** — Amazon/Netflix/Instagram/TikTok sind auf Sofort-Belohnung designt. Aktiv gegensteuern, Warten wieder lernen.
4. **Nichtstun ist oft klüger** — Action Bias überwinden; Beispiel "Watchful Waiting" in der Medizin, wo geduldiges Beobachten die beste Therapie ist.
5. **Geduld macht dich gesund** — Ungeduld = chronischer Stress, Schlafprobleme, Bluthochdruck; geduldige Menschen leben laut Langzeitstudien länger und stabiler.
6. **Geduld ist Beziehung** — Zuhören/Aushalten schafft Vertrauen und Nähe; Ungeduld zerstört Vertrauen.
7. **Geduld ist Widerstand** — in einer auf Tempo gedrillten Welt ist Innehalten ein Akt der Freiheit (Hesse: "Alles Wachstum braucht Zeit"). Erfolg ist Marathon, nicht Sprint.

Abschluss-Frage: Nicht "Wie schnell kann ich sein?", sondern "Wo sollte ich geduldig sein?" — nicht passiv, sondern weise.

**Community-Aufgabe:** Konkrete Situation teilen, in der man im Business am schnellsten die Geduld verliert; gemeinsam das passende Prinzip finden.

---

## 19 · Morgen- & Abendroutine — Die zwei Ankerpunkte des Tages

Übersetzt Energie, Fokus und Dopamin in konkrete tägliche Rituale — die zwei Ankerpunkte, die den Rahmen für alles andere setzen.

**Warum Morgenroutine (5 Gründe):**
1. Mentale Stärke — strukturierter Start reduziert messbar Stressparameter.
2. Körperliche Gesundheit — "Nachteulen" anfälliger für Depression; erstes To-do: 0,5 L Wasser, bevor das Handy angeht.
3. Willenskraft schonen — automatisierte Routine spart Willenskraft. **Radieschen-Experiment:** wer morgens schon Willenskraft verbraucht hatte, gab bei Rätseln nach ~8 Min auf, die Kontrollgruppe hielt 20 Min durch.
4. Zeit für dich — die ersten 60 Min gehören dir, nicht den Nachrichten.
5. Produktivität — Automatismen entlasten den Denkapparat.

**Morgen-Bausteine:** Wasser + Körper aktivieren (Bewegung/Stretching, 10–20 Min) · Mindset (Dankbarkeit, Visualisierung, Journaling, 5–10 Min) · Tagesplanung (1–3 wichtigste Dinge). Beispiele bekannter Leistungsträger (Franklin, Jarvis, Oprah, Robbins) — nicht kopieren, aber bewusst einen Rahmen schaffen.

**Abendroutine (die unterschätzte Hälfte):** direkte Voraussetzung für einen guten Morgen. Studie: 12 Min ziellose Ruhe erhöhen Kreativität/Problemlösung um 41 % (Ruhestandsnetzwerk des Gehirns). Problem: Arbeitstag endet direkt am Handy, kein Puffer → schlechter Schlaf. **Abend-Bausteine:** feste Feierabend-Uhrzeit · Digital-Detox (30–60 Min vor dem Schlaf) · Reflexion (Was war gut? Was lerne ich?) · die 3 wichtigsten Aufgaben für morgen notieren.

Wichtigste Regel: **Konsistenz vor Perfektion** — 3 Elemente täglich schlagen 10 gelegentliche. Klein starten, aufbauen, die Zeit schützen wie ein Meeting mit dem wichtigsten Kunden. (Quellenbezug: Goldene Morgen-/Abendroutine, Dominik Spenst / UrBestSelf.)

**Aufgabe:** Je eine Sache aus Morgen- und Abendroutine wählen, 7 Tage machen, dann erweitern.

**Community-Aufgabe:** Die echten ersten 3 Morgen-Handlungen posten und benennen, was man ändern möchte.
