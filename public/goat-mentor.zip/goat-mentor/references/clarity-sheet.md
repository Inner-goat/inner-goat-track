---
type: wissen
tags: [founder-workspace, clarity, vision, ziele, mindset, notion]
quelle: Notion
erstellt: 2026-07-08
---

# Clarity Sheet: Vision & Anti-Vision

Das Fundament-Sheet des [[Founder Workspace V2]]: Bevor verkauft wird, braucht es Klarheit über Vision, Werte und Mission. Einmal in Ruhe ausfüllen (1–2 Stunden), dann regelmäßig lesen. Diese Notiz hält die Struktur, die Leitfragen und die 30 vertiefenden Visionsübungen fest. Ergänzt Marcos eigene Ausarbeitungen in Träume, Ziele, Wünsche & Ängste *(privat → Marco Brain)* und Persönlichkeit *(privat → Marco Brain)*.

## Wichtige Reminder

Wahrheiten, die man sich vor jedem Sales-Call und vor jedem Tiefpunkt vor Augen halten soll:

- So wie du eine Sache machst, machst du alles andere auch.
- Das, was du reingibst, kriegst du am Ende raus.
- Je weniger ich abgelenkt bin, desto fokussierter bin ich.
- Umsatz kommt von umsetzen. Jeden Tag ein Step nach vorne, egal wie groß.
- Es geht **IMMER** um die Basics.
- Du hast nur ein Leben — strebe nach Exzellenz, denn dein Potenzial wird nur durch dich beschränkt.
- Erfolg heute entsteht nicht durch das, was du konsumierst, sondern durch das, was du ignorierst.
- In dem Moment, wo du anfängst dich zu bewegen, kommen immer mehr Möglichkeiten auf dich zu.
- Wer ständig ins Universum reingibt, bekommt auch zurück.

## Anti-Vision (zuerst!)

Bevor klar ist, wo man hin will, wird definiert, wo man **auf keinen Fall** hin will — ungefiltert schreiben. Leitfragen:

- Wie soll dein Leben in 3 Jahren auf keinen Fall aussehen?
- Was würde dich unglücklich machen?
- Welches Gehalt möchtest du nicht verdienen?
- In welchen Umständen möchtest du auf keinen Fall leben?
- Was wäre schmerzhaft, wenn enge Freunde/Familie das über dich denken würden?
- Welche Situationen haben sich nicht gut angefühlt und sollen künftig vermieden werden?

## Vision in 7 Lebensbereichen

Vision je Bereich bestimmen — **als wäre Scheitern unmöglich**, groß träumen:

1. **Deine Person** — Wie siehst du dich als Persönlichkeit? Wie wirkst du auf andere? Mimik, Körperhaltung? Welche Eigenschaften/Stärken sind ausgeprägt? Inwiefern bist du Inspiration für andere?
2. **Gesundheit & Fitness** — Idealer Gesundheits-/Fitnesszustand? Welche sportlichen Herausforderungen gemeistert?
3. **Beziehungen** — Bindung zur Familie? Eigene Familie? Beziehung zu Freunden? Was macht deine Beziehungen besonders?
4. **Business** — Wie sieht das Business aus, wenn Scheitern unmöglich wäre? Größe, Mitarbeiter, Office, Arbeitsort, Kernaussage, weitere Businesses?
5. **Lifestyle** — Typischer Alltag von morgens bis abends. Plus **Bucket List**: Wo/wie wohnst du, wie oft reisen, welche Ereignisse erleben?
6. **Finanzen** — Finanzielle Mittel, Umsatz, monatliches Einkommen, Sachwerte (Autos, Häuser, privates Gym)? Wenn EIN Sachwert frei wählbar — welcher?
7. **Spiritualität / Inneres** — Verhältnis zu dir selbst, nährende Praxis, Dankbarkeit.

## Visionboard-Anker

- **Vision (3 Jahre):** …
- **3-Monats-Vision:** … (dies + die Anti-Vision sind die zwei Pflichtfelder im 30-Minuten-Schnellstart; Rest kann warten — siehe [[Founder Workspace – Onboarding]])

## Werte & Mission

- **Was macht dich besonders / deine Verkaufsargumente:** 3 Punkte
- **5 Unternehmenswerte** jeweils mit Definition (Wert = Bedeutung)
- **Mission:** Warum machst du dein Business? Was ist die tiefere Mission dahinter?

## Ziele

- **5 große Ziele** für die nächsten Jahre
- **3 Ziele** für die nächsten 3 Monate → in den Ziele-Tracker des Workspace übertragen und mit Tasks verknüpfen

## Die 30 Visionsübungen

Vertiefung für alle, die nach dem Sheet merken „da steckt noch mehr". Nicht auf einmal — eine pro Woche, ungefiltert schreiben. Prämisse: **Visionieren = bewusst die Zukunft gestalten** (nicht Tagträumen); Übungen brechen Routinen, fremde Erwartungen und unbewusste Überzeugungen auf. Vier Bereiche:

### Bereich 1 — Zukunft entwerfen
1. **Die große Erbschaft** — Finanziell ausgesorgt, aber du musst irgendeiner Tätigkeit nachgehen. Welche?
2. **Die „unmögliche Stellenanzeige"** (Design Thinking) — Traumjob-Anzeige ohne Grenzen: Aufgaben, Team, Werte, Bezahlung, Freiheiten.
3. **5-Jahres-Zeitreise** (Covey, „Begin with the End in Mind") — Idealen Job gefunden, Arbeitsalltag im Detail beschreiben.
4. **Die „3 Leben"-Methode** (E. Gilbert, Big Magic) — aktueller Job / etwas ganz Neues / größte Leidenschaft. Welches fühlt sich am lebendigsten an?
5. **Zukunftsbrief an dich selbst** (Satir) — Brief ans Ich in 5 Jahren: welche Entscheidungen führten dahin, wofür jetzt schon dankbar?
6. **Karriere als Landkarte** — Berge (Herausforderungen), Flüsse (Flow), Lichtungen (Klarheit), nächster Pfad.

### Bereich 2 — Stärken & Interessen
7. **50-Jobs-Liste** — 50 faszinierende Tätigkeiten schnell notieren, dann Muster erkennen.
8. **Energie-Check** — Eine Woche Tagebuch: was gibt Energie, was raubt sie, wann Flow?
9. **Das Team in deinem Kopf** — innere Stimmen (Perfektionistin, Abenteurer, Realistin): welche zu laut, welche zu leise?
10. **Verändertes Familien-Skript** — unbewusste Familienmuster im Berufsleben; neue Geschichte schreiben.
11. **Stärkenfeedback** — 3–5 Menschen fragen: Was sind meine Stärken? Wann blühe ich auf?
12. **Alien-Blick** — Ein Alien beobachtet nur dein Verhalten: für welchen Job wärst du gemacht?

### Bereich 3 — Hindernisse & Blockaden
13. **Höllen-Job-Analyse** — Schlimmster Job; dann umdrehen zum Positiv-Spiegel.
14. **Worst-Case-Plan** — Schlimmstes bei Jobwechsel; wie damit umgehen, was gibt Sicherheit?
15. **Systembrett der Zukunft** — Symbolische Objekte für Ressourcen, Ängste, Unterstützer, Herausforderungen platzieren und verschieben.
16. **Unsichtbare Verträge aufdecken** — Unausgesprochene Verpflichtungen mit dem Umfeld; neue formulieren.
17. **Systemische Skulptur** — Jobsituation mit Figuren/Lego als Skulptur, Figuren sprechen lassen.
18. **Parallelwelt-Expedition** — Einen Tag so leben, als hättest du den Traumjob schon.
19. **Unsichtbare Bühne** — Publikum hört nur, sieht nicht: was erzählst du ohne Angst vor Urteil?
20. **Ahnenorakel** — Ahnen/inspirierende Vorfahren befragen: was würden sie raten?
21. **Zukunft betreten (Bodenanker)** — A4-Blätter: Vergangenheit/Gegenwart/Möglichkeitsraum/Vision physisch abschreiten.
22. **Wiederholung der Parallelwelt-Expedition** — zweiter Durchgang, andere Wahrnehmung.

### Bereich 4 — Vision aktivieren & visualisieren
23. **Radikale Neugierde-Challenge** — In 2 Wochen 5 Gespräche mit Menschen aus faszinierenden Berufen (15 Min via LinkedIn).
24. **Interview-Rollenspiel** — Improvisiertes Interview: Traumjob schon erreicht, wie geschafft?
25. **Rückwärts-Vision (Regnose)** — Mit 80 zurückblicken: beste Entscheidung, wichtige Fehler, Botschaft ans heutige Ich.
26. **24-Stunden-Vision** — Perfektes Leben startet in 24 Stunden: was tun, um vorbereitet zu sein?
27. **Magisches Notizbuch** — Alles Hineingeschriebene wird real: erste 10 Dinge.
28. **Symbol deiner Zukunft** — Intuitiv ein Objekt in der Wohnung finden, das für die Vision steht.
29. **Visionwalk** — In der Natur unfokussiert/fokussiert schauen: was will dieses Element mitteilen?
30. **Vision-Board** — Bilder/Worte/Symbole; sichtbar am Schreibtisch aufhängen. „Plane nicht. Geh auf Empfang."

**Abschluss:** Was hat überrascht? Welche Übung half am meisten? 3 konkrete Sofort-Schritte → in Ziele-Tracker (Bereich „Vision").

**Quelle der Übungen:** inspiriert vom „Workbook — 30 Visionsübungen, systemisch und kreativ" von Birgit Permantier (cosense.de); Methoden nach Otto Scharmer (Theorie U), Richard Bolles (*What Color is Your Parachute?*), Julia Cameron (*Der Weg des Künstlers*), Stephen Covey, Elizabeth Gilbert, Virginia Satir.

## Anwendung

Das Clarity Sheet ist Schritt 2 des vollen Setups und Teil-Pflicht im 30-Minuten-Schnellstart (siehe [[Founder Workspace – Onboarding]]). Rhythmus laut Workspace: 1× ausfüllen, monatlich reviewen. Marcos gelebte Antworten wohnen in Träume, Ziele, Wünsche & Ängste *(privat → Marco Brain)* und Persönlichkeit *(privat → Marco Brain)*. Die Werte/Mission speisen die Positionierung im [[Inner GOAT]]-Kosmos.

## Verwandte Notizen

- [[Mindset & Glaubenssätze]]
- [[Founder Workspace – Onboarding]]
- [[Founder Workspace V2]]
- Träume, Ziele, Wünsche & Ängste *(privat → Marco Brain)*
- Persönlichkeit *(privat → Marco Brain)*
- [[Home]]
