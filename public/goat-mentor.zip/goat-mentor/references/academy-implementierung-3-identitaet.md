---
type: wissen
tags: [academy, identität, mindset, glaubenssätze, persönlichkeitsentwicklung, reiter-implementierung]
reiter: Reiter 1 – Implementierung
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 3 – Identität

Das dritte Modul der [[Inner GOAT Academy]] ist der Wendepunkt vom Außen zum Innen. Nach Vision, Strategie und Produktivitäts-System (Modul 1 & 2) geht es hier um die eigentliche Ursache dafür, warum Gründer trotz vorhandener Strategie **nicht ins Handeln kommen**: Blockaden, Glaubenssätze und die eigene Identität.

Die Kernthese des Moduls: Du hast keine Business-Probleme, sondern persönliche Probleme, die sich durch dein Business zeigen. Wer die äußere Struktur hat und trotzdem prokrastiniert, Erfolge nicht genießen kann oder sich im Hamsterrad gefangen fühlt, sitzt an einer inneren Bremse. Das Modul liefert das Modell dahinter (Identität → Glaubenssätze → Verhalten → Ergebnisse), zeigt wie Glaubenssätze entstehen, und gibt konkrete Werkzeuge, sie aufzudecken und aufzulösen.

Thematisch verzahnt sich das Modul stark mit dem [[Storytelling Wissen]] — vor allem mit [[Der Bruch als Bauplan]] (der innere Wandel als eigentliche Transformation), [[Relevanz]] (Ist-Situation vs. Interpretation als Bedeutungsgebung) und der Idee der [[Die 12 Plots|Rebirth-Transformation]]. Die letzten beiden Lektionen (Shaolin-Tugenden, Personal Branding) verankern Identität in Werten und nach außen sichtbarer Marke.

---

## 01 · Einführung Identität

Modul-Auftakt. Nach der Ausrichtung nach außen (Modul 1 & 2) geht es jetzt um das Lösen von **Blockaden** und **Blindspots** — den Dingen, die du über dich selbst noch nicht weißt.

Vier typische Szenarien, die alle Teilnehmer kennen:
1. Du kennst die Strategien (YouTube, Mentoren, Coaching), setzt sie aber nicht um.
2. Prokrastination — Aufgaben stehen im Kalender, du schiebst sie vor dir her.
3. Du erreichst Erfolg, kannst ihn aber nicht genießen — 24/7-Arbeitsdrang.
4. Körper vs. Geist — physisch anwesend (Familie, Urlaub), psychisch noch bei der Arbeit.

Alle vier sind **kein Produktivitäts-, sondern ein Blockade-Problem.** Mehr Tipps oder Motivationsvideos helfen nicht. Was hilft: Klarheit über die unbewussten Muster. Dein Gehirn hat einen (emotionalen, unbewussten) Grund, warum es dich bremst — auch wenn es von außen irrational wirkt.

Bereits hier eingeführt: die **4 Bewusstseins-Ebenen** (unbewusste Inkompetenz → bewusste Inkompetenz → bewusste Kompetenz → unbewusste Kompetenz), die in Lektion 05 vertieft werden. Kernbotschaft: Allein das Bewusstwerden einer Blockade verändert alles — du siehst Welt, Verhalten, andere Menschen und dein Business plötzlich anders.

---

## 02 · Was ist Mindset?

Aufräumen mit dem inflationären Mindset-Begriff. **Mindset = Mind + Set** → "how your mind is set" — wie dein Verstand zu verschiedenen Themen eingestellt ist. Der Verstand ist wie ein Computer mit gespeicherten Einstellungen zu Geld, Verkauf, Beziehungen, dir selbst.

Kernprinzip: **Alles was du glaubst ist wahr** — nicht objektiv, sondern als deine persönliche Realität. Wer glaubt "alle Männer sind Arschlöcher", für den werden alle Männer Arschlöcher sein. Wer glaubt "Verkaufen ist schlecht", für den ist es schlecht.

Es gibt kein richtiges/falsches oder gutes/schlechtes Mindset — nur: **Was funktioniert für mich, was nicht?** Destruktive Business-Überzeugungen ("Geld verdirbt den Charakter", "Verkäufer sind Abzocker", "Ich bin nicht gut genug") sind nicht falsch, aber hinderlich fürs Ziel.

Häufige Missverständnisse: Mindset ist nicht nur positiv denken, visualisieren und warten (The Secret, Law of Attraction) oder Bücher lesen (= Wissenskonsum, nicht Persönlichkeitsentwicklung). Mindset ist **auch Umsetzung** — "hinter jedem Universum steckt ein Tu-Niversum" — und 100% Eigenverantwortung.

Mindset-Arbeit in 4 Schritten: (1) Überzeugungen erkennen und hinterfragen, (2) Herkunft analysieren, (3) hilfreiche Anteile behalten, destruktive auflösen, (4) durch konstruktivere ersetzen.

---

## 03 · Häufige Fehler

Was unterscheidet erfolgreiche von erfolglosen Coaching-Teilnehmern? **Umsetzung** — nicht Wissen. Zwei Rahmenwerke:

**Coachability (Fähigkeit, sich coachen zu lassen) — 4 Eigenschaften:**
1. **Kein Ego** — Ratschläge annehmen, Fehler zugeben, Zwischenergebnisse zeigen. Das Ego ist ein Schutzwall, der auch zurückhält.
2. **Disziplin** — kurzfristige Reize unterdrücken für das langfristige Ziel.
3. **Umsetzung** — Aufgaben machen, in Calls kommen, Fragen stellen.
4. **Feedback einholen** — von Coach und Community.

**Die 5 Grundprinzipien für maximalen Erfolg:**
1. **Aktiv an Calls teilnehmen** — immer mindestens eine Frage. Wenn keine da ist: Was ist meine Ist-Situation, was ist meine Soll-Situation? Die Lücke ist die Frage.
2. **Radikal ehrlich sein** — keine Ausreden. "Weil" aus dem Wortschatz streichen — es wurde einfach nicht gemacht. Ist-Zustände statt Wishful Thinking.
3. **Fokus auf Beweise** — dass es bei anderen und bei dir klappt, auch im Kleinen.
4. **100% Verantwortung übernehmen** — die Andrew-Tate-Regen-Anekdote: Du bist immer zu 100% verantwortlich (nicht schuld) für deine Situation. Keiner rettet dich.
5. **Vorausschauend lernen** — manche Lektionen treffen heute noch nicht zu, werden es aber.

---

## 04 · Du hast keine Business-Probleme

Die zentrale Umdeutung des Moduls: **Die meisten Business-Probleme sind keine Business-Probleme, sondern persönliche Probleme, die sich durchs Business zeigen.**

**Das Mikroskop-Modell:** Du bist das Präparat, dein Business ist das Mikroskop. Das Business macht sichtbar, was schon immer da war — Glaubenssätze und Muster, die privat unsichtbar bleiben, zeigen sich im Business glasklar.

Praxisbeispiel "Ich muss es allen recht machen": zeigt sich als jedem Kunden hinterherlaufen, sich in Verhandlungen kleinmachen, Deals unter Wert, Dauerstress. Das Problem ist nicht mangelnde Verhandlungsstrategie, sondern der dahinterliegende Glaubenssatz.

Der prägende Satz: *"Wenn du ein Business machst, wirst du durch jeden Glaubenssatz, den du hast, einmal durchgeschleift."* Deshalb ist Persönlichkeitsarbeit keine Kür, sondern Pflicht — sie macht den Weg von "Fahrradfahren mit Gegenwind" zu Leichtigkeit. (Vgl. [[Der Bruch als Bauplan]]: das eigentliche Wachstum passiert innen.)

---

## 05 · Bewusstsein erweitern — Die 4 Stufen der Kompetenz

Das klassische Kompetenz-Modell, erklärt am Autofahren:

| Stufe | Bezeichnung | Bedeutung |
|---|---|---|
| 1 | Unbewusste Inkompetenz | Du weißt nicht, dass du es nicht kannst (Baby) |
| 2 | Bewusste Inkompetenz | Du weißt, dass du es nicht kannst (5-Jähriger sieht Autos) |
| 3 | Bewusste Kompetenz | Du kannst es mit Konzentration (Fahrschüler) |
| 4 | Unbewusste Kompetenz | Automatisch, ohne Nachdenken (erfahrener Fahrer) |

Dasselbe gilt für Akquise, Verkauf, Kommunikation und Blockadenlösen. Du befindest dich meist in Stufe 1 oder 2 — bis dir jemand einen Spiegel vorhält. Dann beginnt Stufe 3: bewusstes, kleinschrittiges Training, bis es Stufe 4 wird.

Wichtigste Botschaft gegen den "Schnips-und-morgen-kann-ich-es"-Drang: Es geht nicht um alles-sofort, sondern um **kleine, tägliche Schritte** über Wiederholung. Wer gerade kämpft, ist in Stufe 2/3 — das ist ein Zeichen von Wachstum, nicht Schwäche. (Ergänzt durch das Geduld-Prinzip: Geduld ist ein trainierbarer Muskel.)

---

## 06 · Verhaltensmuster

Warum man sich im Hamsterrad fühlt — das **4-Ebenen-Modell**:

**Identität / Glaubenssätze (Wurzel)** → **Emotionen** → **Verhalten** → **Ergebnisse (sichtbar)**

Ergebnisse sind alles im Leben (Umsatz, Beziehungen, Kleidung). Sie werden durch Verhalten ausgelöst, Verhalten durch Emotionen, Emotionen durch die Identität/Glaubenssätze.

Der häufigste Fehler: Menschen versuchen, auf Ergebnis- oder Verhaltensebene zu ändern (teure Klamotten kaufen, um 6 Uhr aufstehen, neues Business). Das wirkt kurzfristig, aber das Grundgefühl bleibt, weil die Glaubenssätze unverändert sind.

**Zwei Fallstudien:**
- **Der Business-Hopper:** springt von Business zu Business, sobald es schwierig wird — vermeidet die Minderwertigkeitsgefühle an seinen Limits. Das Muster liegt nicht im Business, sondern in der Vermeidungsstrategie.
- **Der Workaholic:** glaubt, permanent arbeiten zu müssen, fühlt sich schlecht ohne Arbeit. Erst durch bewusstes Musterunterbrechen (mehrere Tage nichts tun → spontan Fallschirmspringen) entdeckt er echte Freude. Das Muster war ein Glaubenssatz, keine äußere Notwendigkeit.

Leitfrage: nicht "Was mache ich falsch?", sondern "Welche Emotion vermeide ich — und welcher Glaubenssatz steckt dahinter?"

---

## 07 · Deine Identität

Vertiefung als **Identitätspyramide**: Identität → Glaubenssätze → Verhalten → Ergebnisse. Die einzige nachhaltige Veränderung beginnt oben, an der Identität.

**Das Be-Do-Have-Prinzip** (gegen das schulische "Have-Do-Be"):
- **Be → Do → Have** — erst bist du die Person im Kopf, dann handelst du entsprechend, dann hast du die Ergebnisse.
- Sixpack: Erst **bist** du eine disziplinierte Person, dann folgen Ernährung/Gym, dann der Sixpack.
- Supercar: Erst **bist** du im Kopf die erfolgreiche Person, dann folgen Handlungen und Ergebnisse.

**Loser- vs. Winner-Identität:** Negative Überzeugungen ("Verkaufen = Abzocken", "nicht kompetent genug") → Prokrastination, Overthinking → Loser-Gefühl. Konstruktive Überzeugungen ("Verkaufen = Probleme lösen", "Kunden kommen täglich zu mir", "Ich schaffe Mehrwert") → Umsetzung + Entspannung → Winner-Gefühl. Keine der beiden ist "die Wahrheit" — beide sind formbare Überzeugungen.

Wichtiger Nebenpunkt: **Entspannung ist so wichtig wie Anspannung** (Muskel-Analogie — der Muskel wächst in der Pause). Oft ist eine Stunde entspannen wertvoller als fünf Stunden operativ vor dem PC. Viele können nicht entspannen, weil sie glauben, 24/7 arbeiten zu müssen. Accountability (Verantwortung für die eigene Wahrnehmung übernehmen) ist der Startpunkt der Identitätsarbeit.

---

## 08 · Glaubensätze die dich zurückhalten

**Das Bewusstseins-Modell:** Dein System besteht aus Bewusstsein (durch Aufmerksamkeit gesteuert, wie ein Taschenlampen-Lichtkegel) und Unbewusstsein (riesig — hier schlummern die meisten Überzeugungen). 99,9% aller Reize werden unbewusst verarbeitet.

**Vier Kategorien negativer Business-Glaubenssätze:**
1. Über Verkaufen ("Verkaufen = Abzocken")
2. Über sich selbst ("Ich bin nicht kompetent genug")
3. Über Geld ("Geld verdirbt den Charakter", "bei anderen ist es besser aufgehoben")
4. Über die eigene Dienstleistung ("Mein Angebot ist den Preis nicht wert")

**Das Gummiband-Modell:** Je näher du deinem Ziel kommst, desto stärker zieht dich ein unbewusster Glaubenssatz zurück. Ziel = 10.000 €/Monat, Glaubenssatz = "Verkaufen = Abzocken" → der Glaubenssatz lehnt das Ziel ab → du prokrastinierst Verkauf → Ergebnis bleibt aus. Entscheidend sind vor allem die **unbewussten** Glaubenssätze.

**Die dunkle Karte:** Dein Bewusstsein ist eine riesige, dunkle Karte. Jede Erkenntnis über dich lässt ein Licht aufgehen. Bewusstseinserweiterung = die Karte Stück für Stück erhellen — der erste Schritt jeder Veränderung.

---

## 09 · Entstehung von Glaubensätzen

Das theoretische Herzstück des Moduls. Ein Glaubenssatz ist zunächst nur ein wiederkehrender Gedanke. **Die 6 Schritte der Entstehung:**

1. **Interpretation / Übernahme** — Wir interpretieren eine Situation (Mutter fragt "Warum nur eine 3?" → "Ich bin nicht gut genug") oder übernehmen Überzeugungen von außen (Eltern: "Geld verdirbt den Charakter").
2. **Verbindung mit Emotion** — Der Gedanke koppelt sich an Scham/Schuld/Wut → Abwärtsspirale: mehr Gedanken = mehr Emotion = mehr Gedanken.
3. **Der Glaube entsteht** — Schubladendenken: "Ich bin zu doof." Aus einer Annahme wird ein Glaube.
4. **Filter aktiv** — Eine "Brille" mit Filter: wir nehmen nur bestätigende Situationen wahr (Confirmation Bias), blenden Gegenteiliges aus.
5. **Selbsterfüllende Prophezeiung** — Der Verstand passt Verhalten an, um Recht zu behalten (Überleben = Recht haben).
6. **Teil der Identität** — Durch Wiederholung wird der Glaube zur nicht mehr hinterfragten Identität.

**Das Handy-Beispiel** (die tiefere Definition): Ein Glaubenssatz schließt eine Wissenslücke mit einer Annahme. "Fällt das Handy?" = Wissen (Erdanziehung, eine Information). "Geht es kaputt?" = Glauben (hunderte Informationen fehlen → wir schlussfolgern). Da wir nie alle Informationen haben, denken wir energiesparend in Schubladen — was zu verzerrten Schlussfolgerungen führt.

Praxis-Anwendung: Antwortet ein Kunde nicht, ist der "schwarze Kreis" der Möglichkeiten riesig (Urlaub, krank, kein Bedarf, privates Problem). Ein Kunde schrieb sich immer 10 alternative Erklärungen auf → seine eigene ("es liegt an mir") sank rechnerisch von 100% auf 10% Wahrscheinlichkeit. Das entlastet enorm.

Kernprinzip: **Alles was du glaubst ist wahr — aber nur deine Realität.** 100 Menschen, dieselbe Situation, 100 Interpretationen. Und: Genauso wie Glaubenssätze erlernt werden, können sie verlernt werden. **Du bist nicht deine Glaubenssätze — du hast sie.** (Direkter Bezug zu [[Relevanz]]: Bedeutung entsteht durch Interpretation, nicht durch die Situation selbst.)

---

## 10 · Unterbewusste Absichten

Umdeutung der Ergebnis-Formel. Falsch: "Mehr Tun = Mehr Ergebnisse" (widerlegt durch Fabrikarbeiter im Dritte-Welt-Land, der 8–10h arbeitet und wenig verdient). Auch "Glück" erklärt es nicht. **Richtig: Ergebnisse sind eine Folge von Absicht.**

Der Gamechanger: **Alle Ergebnisse, die du willst, aber nicht hast, sind ebenfalls Folge einer Absicht** — nämlich einer subbewussten Absicht, die das Gegenteil will. Wer keine mehrfach fünfstelligen Umsätze hat, hat irgendwo eine Absicht, die das verhindert (z.B. "Ablehnung vermeiden" als Überlebensstrategie in der Komfortzone).

| Symptom | Mögliche subbewusste Absicht |
|---|---|
| Keine Akquise | Ablehnung vermeiden |
| Niedrige Umsätze | Keinen Stress / wenig arbeiten müssen |
| Keine öffentlichen Postings | Nicht beurteilt werden |
| Kein Wachstum | Freundeskreis / Familie nicht verlieren |

**Die "Wozu"-Methode:**
- Falsch: "Warum mache ich das nicht?" → führt zu Ausreden und Selbstschutz.
- Richtig: "Wozu dient es mir, das nicht zu tun?" → führt zum echten Glaubenssatz.
- Anschluss: "Was benötigt es, damit ich das Ziel erreiche?" → lösungsorientiert, zukunftsgerichtet.

Vier Untersuchungsbereiche: Überzeugungen über dich selbst (emotionale Trigger, Selbstsabotage), Geld (wozu viel/wenig auf dem Konto?), Verkaufen (wo prokrastinierst du Akquise?), Dienstleistung/Zielgruppe. Aufgabe: alle auftauchenden Glaubenssätze notieren — besonders die mit starker Emotion. Der erste Gedanke bei einer unangenehmen Frage ist fast immer der relevanteste.

---

## 11 · Wie dein Verstand funktioniert

Die praktische Methode, Glaubenssätze aufzudecken — kompakt und anwendbar:

**Schritt 1: Emotional Trigger erkennen** — Wo reagierst du emotional stärker, als die Situation es rechtfertigt? Dort liegt ein aktiver Glaubenssatz. Der Trigger ist der Zeigefinger, der auf den Glaubenssatz zeigt — starke Emotionen sind wertvolle Information.

**Schritt 2: Ist-Situation von Interpretation trennen:**

| Ist-Situation | Interpretation |
|---|---|
| Person antwortet nicht | "Ich gehe ihr auf die Nerven" |
| Ich prokrastiniere Akquise | "Ich bin nicht kompetent genug" |
| Kein neuer Kunde diese Woche | "Mein Angebot taugt nichts" |

**Schritt 3: Glaubenssatz benennen** — "Warum denke ich das?" → "Weil Verkaufen für mich Abzocken bedeutet."

**Schritt 4 (alternativ): Die Wozu-Methode** — Schicht für Schicht graben ("Wozu dient es mir, das nicht zu tun?").

Praxis-Tipp: Der erste Gedanke ist fast immer der relevanteste — sofort aufschreiben, vor dem inneren Zensor.

---

## 12 · IST-Situation & Interpretation

Das Konzept aus Lektion 11 als eigenständiges, mächtiges Prinzip. Zunächst **Mindset Debugging**: Mindset-Arbeit heißt oft nicht mehr lernen, sondern destruktive Überzeugungen *löschen* (wie Bugs im Programm). Junge Gründer sind oft schneller erfolgreich, weil sie weniger eingebrannte destruktive Überzeugungen mitbringen.

**Ist-Situation vs. Interpretation** — jede Situation aus zwei Welten sehbar:

| Ist-Situation | Interpretation A | Interpretation B |
|---|---|---|
| Wassertropfen fallen | "Schlechtes Wetter" | "Gutes Wetter" (nach Dürre) |
| Bayern schießt ein Tor | Freude (Bayern-Fan) | Ärger (Dortmund-Fan) |
| Kunde antwortet nicht | "Ich bin ein Versager" | "Er ist vielleicht krank" |

Kernpunkt: **Emotionen entstehen nicht durch Außenumstände, sondern durch die Bedeutung, die wir ihnen geben** (Regen = "nur Wassertropfen, die vom Himmel fallen"; ein Tor = "ein Mensch bewegt etwas Rundes in etwas Eckiges").

**Fehler existieren nicht** — ein Fehler ist keine Ist-Situation, sondern eine Interpretation. Moral ist ein menschliches Konstrukt (Amerika feiert gescheiterte Business, die deutschsprachige Kultur bewertet). Es gibt nur zwei Kategorien: **Erfolg/Fortschritt** oder **Lernchance**. Das macht resilient — es gibt keine "Rückschläge", nur Lernchancen.

**Worauf du dich fokussierst, wird mehr:** Fokus auf Mangel → mehr Mangel; Fokus auf Fülle → mehr Fülle; Fokus auf Lernchancen → mehr Wachstum. Das ist Neurologie, kein Zufall. (Enger Bezug zu [[Relevanz]] und zur Reframing-Logik guten Storytellings.)

---

## 13 · Glaubensätze auflösen durch Gegenbeispiele

Erste Auflösungs-Technik. Wichtige Grundhaltung: **Glaubenssätze sind Überlebensmechanismen** — nicht schlecht, sondern mit Ursprung und Sinn. Jeder hat hilfreiche und nicht hilfreiche Seiten. Ziel ist nicht Bekämpfen, sondern einen **konstruktiveren Glaubenssatz** finden, der die hilfreichen Aspekte behält.

**Die Gegenbeispiel-Methode:** Glaubenssätze leben von bestätigenden Beweisen — die einfachste Schwächung ist, Gegenbeispiele zu finden.

| Destruktiver Glaubenssatz | Gegenbeispiel suchen |
|---|---|
| "Alle Hunde beißen" | Sanfte Hunde kennenlernen |
| "Geld verdirbt den Charakter" | Reiche + wundervolle Menschen finden |
| "Verkaufen = manipulieren" | Eigene Kauferfahrungen mit echtem Mehrwert |
| "Ich schaffe das nicht" | Auflisten, was du schon geschafft hast |
| "Mehrfach fünfstellig ist unrealistisch" | Menschen finden, die es erreicht haben |

**Kein Schwarz-Weiß, sondern Schieberegler:** Es geht nicht ums sofortige Umkippen ins Gegenteil. Jedes Gegenbeispiel verschiebt den Regler ein Stück. Manche Glaubenssätze bröckeln sofort, andere brauchen Zeit.

Der Merksatz: **"Glaubenssätze leben von Beispielen und sterben durch Gegenbeispiele."**

---

## 14 · Glaubensätze sammeln

Übungs-Lektion mit Arbeitsblatt (im Video verlinkt). Aufgabe: alle destruktiven Glaubenssätze systematisch sammeln, **bevor** man sich die vorgegebene Liste anschaut.

**Die 4 Kategorien:**
1. **Identität** — "Ich bin nicht gut genug", "Ich falle zur Last", "Ich bin nicht charismatisch"
2. **Verkaufen** — "Verkaufen = manipulieren", "Als Verkäufer bin ich untergeordnet", "Kunden haben keine Zeit für mich"
3. **Geld** — "Geld verdirbt den Charakter", "Geld muss hart erarbeitet werden", "Wenn ich Geld habe, wird es mir weggenommen"
4. **Dienstleistung, Branche & Kunden** — "Coaches sind Abzocker", "Es gibt schon genug Anbieter", "Meine Zielgruppe hat kein Geld", "Finanzberatung = Schneeballsystem"

**Farbcode-System:** dunkel markiert = starke Emotion → prioritär; hell markiert = weniger intensiv → trotzdem aufschreiben.

**Hilfsfragen zum Aufdecken:**
- "Wozu dient es mir, X nicht zu haben/tun?"
- "Was könnte Negatives passieren, wenn ich X erreiche?"
- "Wie reagiere ich, wenn plötzlich Geld an meine Tür klingelt?" (erste Reaktion = ehrlichster Glaubenssatz — beim Autor selbst: "Geld muss hart erarbeitet werden")
- "Was könnte ein Klient denken, wenn ich Akquise mache?"

Grundlage aller Veränderung: Du kannst nur verändern, was du siehst. Je ehrlicher und vollständiger die Liste, desto wirkungsvoller die spätere Auflösung.

---

## 15 · Glaubensätze auflösen (2)

Der vollständige **3-Schritte-Auflösungsprozess** (mit Arbeitsblatt):

**Schritt 1 — Vorlese-Methode:** Die gesammelte Liste laut vorlesen und beobachten, was sich innerlich tut. Viele Glaubenssätze fühlen sich beim Hören sofort wie "Bullshit" an und lösen sich → streichen. Noch wirkungsvoller: eine vertrauensvolle Person liest sie vor.

**Schritt 2 — Das 4-Fragen-System** (für die verbliebenen):

| Frage | Beispiel: "Geld ist schlecht" |
|---|---|
| Ist das wirklich wahr? | "Nein — ich freue mich über Geld" |
| Ist das immer / bei jeder Person so? | "Nein — viele Reiche spenden" |
| Wie wäre mein Leben ohne diesen Glaubenssatz? | "Mehr Freiheit, Reisen, Sicherheit" |
| Welche Gegenbeweise gibt es? | "Große Stiftungen, Spenden, Hilfsorganisationen" |

→ Der Glaubenssatz beginnt zu bröckeln (muss sich nicht sofort auflösen).

**Schritt 3 — Hartnäckige Glaubenssätze (tiefes Aufdröseln):**
1. **Ist-Situation notieren** — was ist wirklich passiert? (keine Interpretation, am besten die Situation der Erstentstehung)
2. **Schlussfolgerung sichtbar machen** — "Daraus habe ich geschlossen, dass..." — mehrmals laut vorlesen (viele Schlussfolgerungen unterliegen einer kindisch-naiven Logik)
3. **10 alternative Möglichkeiten** — Wie könnte es noch sein? (Kunde antwortet nicht → im Urlaub, krank, anderer Anbieter, privates Problem, übersehen...) → die ursprüngliche Schlussfolgerung verliert an Gewicht.

Auflösung ist ein Prozess, kein Ereignis — manches sofort, anderes über Wochen/Monate. Beides ist Fortschritt.

---

## 16 · Funktion des Verstandes

"Die Kraft der Gedanken." **Der vollständige Schöpfungsprozess:**

**Überzeugungen → Gedanken → Emotionen → Verhalten → Ergebnisse**

In beide Richtungen bearbeitbar:
- **Vorwärts:** Überzeugungen ändern → alles folgt.
- **Rückwärts (Reverse Engineering):** gewünschtes Ergebnis definieren → welches Verhalten, welche Emotionen, Gedanken, Überzeugungen brauche ich? Du bist der Schöpfer — du kannst Dinge im Leben "materialisieren".

**Die Hamsterrad-Falle** (drei Temporal — Vergangenheit, Jetzt, Zukunft): Das Gehirn schließt automatisch von vergangenen Misserfolgen auf zukünftige Ergebnisse. Vergangene Akquise → kein Abschluss → negative Emotion. Heute steht Akquise an → Gehirn ruft die alte Emotion ab (Frust, Druck — obwohl es objektiv keinen Grund gibt) → das prägt das Verhalten → wieder kein Abschluss. Wir "predicten" die Zukunft aus der Vergangenheit und bleiben im Hamsterrad. Einstein: *"Wahnsinn ist, immer dasselbe zu tun und andere Ergebnisse zu erwarten"* — aber Handeln allein reicht nicht, man muss zuerst anders denken und fühlen.

**Neuroplastizität / Replaying:** Dein Gehirn speichert alle Erfolge und Misserfolge. Was du häufig abspielst, wird stärker (wie ein Muskel). Ständiges Abspielen von Misserfolgen → mehr Misserfolge. Bewusstes Abrufen positiver Erinnerungen (MVP im Fußballturnier, erster Kunde, ein Kompliment) → positive Emotion → positiveres Verhalten. **Du entscheidest täglich, welche Bilder du abspielst — und damit, welche Identität du stärkst.**

**Rationales Denken als Werkzeug** (Aufgabe: einkommende Reize prüfen und die zurückweisen, die nicht auf Fakten beruhen):
- Gibt es eine rationale Begründung für diese Überzeugung?
- Kann es sein, dass ich mich täusche?
- Würde ich bei einer anderen Person zum gleichen Schluss kommen?
- Warum weiter so handeln, als wäre die Überzeugung wahr, wenn es keinen Grund dafür gibt?

Und Gedankenhygiene: Welche Gedanken sind gut für mich, welche nicht? Die empfundenen Emotionen machen einen großen Teil der Lebensqualität aus.

---

## 17 · Higher Self

Die praktisch wirkungsvollste Lektion (und die längste). **Dein Higher Self** = die höchste, beste Version von dir, die alle Ziele schon erreicht hat. Sie existiert bereits in dir — es ist das Visions-Ich aus Modul 1. Sie handelt aus totalem Vertrauen, denkt in Wachstum, sieht Investitionen statt Kosten, findet Gründe warum es geht.

**Mangeldenken vs. Fülledenken** (ausführlich, damit man sich wiedererkennt):

| Mangeldenken | Fülledenken |
|---|---|
| "Hoffentlich zahle ich alle Rechnungen" | "Wie verdiene ich 30x im Monat?" |
| "Bloß nicht verlieren" | "Ich will gewinnen" |
| "Dinge existieren in Knappheit" | "Es gibt genug für alle" |
| "Was wenn es nicht klappt?" | "Wie sieht es aus, wenn es funktioniert?" |
| Kosten sehen | Mehrwert / Investition sehen |
| Du siehst die Löcher im Käse | Du siehst den Käse |

Weitere Mangel-Marker: Ziele nur auf Absicherung statt Wachstum ("wenn ich 4.000 € mache, ist alles gut" statt "ich will 30.000 €"), immer Ausreden ("geht nicht, weil..."), nur Potenzial zum Scheitern statt Möglichkeiten, extreme Angst Geld zu verlieren, ständige Visualisierung von Worst-Cases, Neid ("der Kuchen ist begrenzt"). Die **Lounge-Anekdote** (den Teller aus Angst überfüllen, obwohl es genug für alle gibt) und die **Tasche-Anekdote** ("Kaufst du diese Tasche für 1.000 €?" — die richtige Antwort ist "Was ist drin?", nicht "Nein") illustrieren Mangel- vs. Fülledenken.

**Praktische Anwendung — vor jeder Entscheidung zwei Optionen:** aus dem jetzigen Ich oder aus dem Higher Self. Leitfrage: *"Wie würde ich handeln, wenn ich bereits 10x erfolgreicher wäre / 30 statt 3 Kunden hätte?"* Ein fordernder Kunde: aus dem Jetzt-Ich läufst du hinterher; aus dem Higher Self ziehst du klare Grenzen. "Ich kann nicht verkaufen" → Higher-Self-Antwort: "Ich lerne es."

**Higher Self ≠ "Fake it till you make it":** Es geht nicht ums nach-außen-so-tun (das erzeugt nur Druck), sondern ums **innerliche** Denken aus dieser Perspektive. Die Person, die du jetzt bist, produziert die jetzigen Ergebnisse — wer Level-10-Ergebnisse will, muss aus dem Higher Self denken. Fragen tauschen: "Warum bekomme ich das nicht hin?" → "Was sind die Bedingungen, damit ich es hinbekomme?" (Die Joe-Dispenza-Impulse ergänzen: Präsenz im Jetzt durchbricht den automatischen Mangel-Kreislauf; Identität ist auch körperlich verankert; Herz/Bauch mitentscheiden lassen.)

---

## 18 · Abschluss Identität

Zusammenfassung des Moduls. Rückblick auf die Learnings: was Mindset ist, wie Verhaltensmuster und Glaubenssätze funktionieren, die eigene Identität und die eigenen Blindspots.

**Der größte Gewinn ist das Bewusstsein**, nicht die Lösung. Du hast jetzt eine *bewusste Inkompetenz* (Stufe 2) — du weißt, dass du limitierende Glaubenssätze hast. Allein das führt dazu, dass du Welt, eigenes Verhalten, andere Menschen und dein Business anders siehst:
- Prokrastination ist nicht Faulheit, sondern Angst vor Ablehnung / innerer Konflikt.
- Andere sind nicht herzlos, sondern haben eigene Blockaden → mehr Empathie.
- Im Business geht es oft nicht um Money, sondern um Selbstwert und Angst.

Die "Magie des Bewusstseins": Allein durch das Wissen um eine Blockade passiert Veränderung — "OK, ich merke das Muster, ich probiere mal was anderes."

**Die Reise-Einordnung:** Modul 1 & 2 = Außen-Struktur (Vision, Strategie, Produktivität — das WAS und WANN). Modul 3 = Innen-Struktur (Blockaden, Glaubenssätze, Identität — das WARUM und WER). Erst äußere, dann innere Struktur → dann explodiert das Business. Ausblick: die nächsten Module liefern die Techniken zum Auflösen und zum Aufbau einer neuen Identität. (Vgl. [[Der Bruch als Bauplan]]: das Bewusstwerden ist der Wendepunkt der Rebirth-Story.)

---

## 19 · Die 14 Shaolin-Tugenden — Dein täglicher Wertekompass

Ein Werte-Rahmenwerk als Kompass für Identität: **WuDe** ("der Charakter des Kriegers") aus der Shaolin-Tradition — kein religiöses, sondern ein praktisches System zur Charakterentwicklung. Ein Krieger ist hier jemand, der sich selbst vollständig beherrscht.

**Vier mitgebrachte Tugenden (Grundvoraussetzungen):**
1. **Disziplin** — Selbstbeherrschung immer, nicht nur wenn es passt.
2. **Selbstbeherrschung** — Meister der eigenen Emotionen, nicht ihr Sklave.
3. **Bescheidenheit** — sich nie überschätzen, die Umgebung nie unterschätzen.
4. **Wohlwollen** — Wertschätzung des Lebens, echter Respekt als natürliche Haltung.

**Zehn erlernte Tugenden — Handeln & Verhalten:** Demut (Vision > eigene Wünsche), Respekt (auch vor sich selbst), Rechtschaffenheit (volle Verantwortung), Vertrauen (eine Persönlichkeit werden, der man vorbehaltlos vertraut), Loyalität (zeigt sich in schlechten Zeiten).
**Geist & Verstand:** Wille (Ziel nie aus den Augen verlieren), Beständigkeit (täglich eine bessere Version), Beharrlichkeit (kontinuierliche Anstrengung, auch wenn niemand zuschaut), Geduld (pausieren, lernen, neu ansetzen — Geduld als trainierbarer Muskel), Mut (bewusster Mut trotz Angst, nicht blinder Mut).

**Tägliche Praxis:** Wähle pro Tag eine Tugend, beobachte dich vom Aufwachen an (basieren Gedanken und Handlungen auf ihr?). 14-Tage-Zyklus, dann von vorne.

Leitgedanke: *"Es ist besser, ein Krieger im Garten zu sein, als ein Gärtner im Krieg."* Reflexionsfragen: Welche Tugenden hast du kultiviert? Welche fehlen und würden dir gerade am meisten bringen?

---

## 20 · Personal Branding = Identität, keine Show

Verbindung von innerer Identität zur nach außen sichtbaren Marke. Kernbotschaft: **Personal Branding beginnt nicht auf LinkedIn, sondern in dir.** Der häufigste Fehler ist, mit dem Außen zu beginnen (Profil, Posts) — das fühlt sich unecht an, und andere spüren das. Die richtige Frage: *"Wer bist du, wenn niemand zuschaut?"* Deine Marke ist keine Maske, sondern eine **Lupe** — sie vergrößert, wer du wirklich bist.

**Die Olivenbaum-Metapher:** Wenn du alle Früchte deines Lebens (Erfahrungen, Niederlagen, Erkenntnisse, Werte) auspresst — welche goldene Essenz kommt heraus? Das ist deine Marke. (Enger Bezug zu [[Der Bruch als Bauplan]]: die Essenz entsteht aus den durchlebten Brüchen.)

**Das Markensteuerrad — 4 Dimensionen:**

| Dimension | Frage |
|---|---|
| Tonalität | Wie bin ich? (Eigenschaften, Stärken — wie du *tatsächlich* bist) |
| Markenkompetenz | Wer bin ich? (Kern-Kompetenzen, Erfahrungen) |
| Reason Why & Benefit | Was biete ich? (USP — was bekommen andere, das sie woanders nicht bekommen?) |
| Markenbild | Wie trete ich auf? (Kleidung, Sprache, Stil — folgt dem Innen) |

**Drei psychologische Wirkungshebel:** Social Proof (Testimonials, Referenzen senken Skepsis), Autorität (Medien, Auszeichnungen — visuelle Qualitätssignale), Gleichheit (Menschen mögen Ähnliche — "Das könnte ich selbst geschrieben haben").

Die wichtigste Entscheidung: **Für was willst du stehen?** Nicht für alles, nicht für jeden — für etwas Konkretes. *"Auf LinkedIn und im Leben gewinnt nicht der Lauteste, sondern der Klarste."* Wenn du nicht definierst, wie man dich sehen soll, tut es jemand anderes. Kommuniziere nicht *was* du tust, sondern *was es für den anderen bedeutet* — hier greift das [[Storytelling Wissen]] und [[Relevanz]] direkt ins Personal Branding.

Aufgabe (3 Klarheitssätze): Wofür stehst du? Für wen bist du da? Was bekommen Menschen von dir, das sie sonst nirgends finden?
