---
type: wissen
tags: [founder-workspace, onboarding, notion, setup, inner-goat]
quelle: Notion
erstellt: 2026-07-08
---

# Founder Workspace – Onboarding

Der Einstieg in den [[Founder Workspace V2]] — das komplette Founder-Betriebssystem von [[Inner GOAT]] (Vision · Mindset · Sales · Akquise · Tracking, alles verknüpft). Diese Notiz fasst die beiden Einstiegsseiten „Start hier" (volles Setup) und „Schnellstart in 30 Minuten" zusammen: Zweck, schneller Einstieg, tägliche Routine.

## Zweck & Zielgruppe

Gebaut für selbstständige Gründer, Coaches, Berater, Solo-Entrepreneure, die ihr Business systematisch aufbauen wollen. Inhalt:

- **Vision & Clarity** — Klarheit über die Richtung (7 Lebensbereiche) → [[Clarity Sheet]]
- **Mindset & Glaubenssätze** — Belief-Library + persönlicher Auflösungs-Workflow → [[Mindset & Glaubenssätze]]
- **Sales Foundation** — Positionierung (3S-Formel) + bis zu 3 Kundenavatare
- **Akquise & Skripte** — 6 erprobte Skripte (Kaltakquise bis Closing)
- **Sales-Tracker · Habits · Cockpit · Tasks · Ziele · Meeting Notes · Social · Dokumenten-Hub**

## Schnellstart in 30 Minuten

Kein Zeit fürs volle Setup? Diese 4 Dinge machen sofort handlungsfähig; alles andere (30 Visionsübungen, alle 6 Skripte, Work Credo, Ziele) ist Vertiefung und kann warten.

1. **Clarity light (10 Min)** — im [[Clarity Sheet]] NUR zwei Felder: Anti-Vision (Wie soll das Leben in 1 Jahr auf keinen Fall aussehen?) und 3-Monats-Vision.
2. **Erster Avatar (8 Min)** — in Sales Foundation den Haupt-Avatar anlegen: Branche, Demografie, größter Painpoint, Wunschzustand.
3. **Zwei Skripte griffbereit (7 Min)** — Kaltakquise-Opener + Kennenlern-/Discovery-Skript öffnen und Platzhalter in eigene Sprache tauschen.
4. **Tägliche Routine starten (5 Min)** — Cockpit als Browser-Startseite; abends ersten Sales-Tracker-Eintrag machen.

## Volles Setup (Tag 1, 2–3 Std)

Checkliste „Start hier": (1) ganze Wurzelseite duplizieren · (2) [[Clarity Sheet]] ausfüllen · (3) Glaubenssatz-Library durchgehen, „Trifft mich" markieren · (4) Avatar 1 anlegen · (5) Positionierung (3S-Formel) · (6) 6 Sales-Skripte lesen & personalisieren · (7) erste 5 Leads eintragen · (8) Habit-Tracker starten · (9) 3 Ziele für 3 Monate · (10) Cockpit als Startseite.

> Wichtig beim Duplizieren: **die GANZE Wurzelseite** kopieren (mit Inhalt/Untereinträgen), sonst brechen die Datenbank-Relationen.

## Tägliche Routine (15 Min)

- **Morgens (5 Min):** Cockpit öffnen · Tasks reviewen · Top-3-Prioritäten · Habit-Eintrag starten.
- **Abends (10 Min):** Daily Sales Activity (Calls, Pitches, Discoveries, Sales Calls, Umsatz) · Lead-Tracker updaten · Habit-Eintrag abschließen · bei Meeting: Meeting-Notes-Eintrag mit Deal + Firma + Tasks.

## Profi-Tipps & Rhythmus

- Deals immer mit Firma + Avatar verknüpfen → Conversion-Rate pro Avatar sichtbar.
- Skripte einmal durchgehen und als „Master-Skripte" speichern.
- Glaubenssätze monatlich reviewen (1. des Monats, 4-Fragen-Framework).
- Habits sind King — jeden Abend eintragen (größter Hebel für Konsistenz).
- Sales-Calls IMMER tracken, auch No-Shows — nur saubere Daten zeigen die Conversion-Rates.

Rhythmus-Kurzform: Cockpit täglich · Clarity 1× + monatlich · Mindset wöchentlich · Sales Foundation 1× + quartalsweise · Skripte vor jedem Call · Sales-Tracker + Habits täglich abends · Ziele wöchentlich.

## Anwendung

Diese Notiz ist die Landkarte für den Workspace-Start. Details der beiden Kern-Sheets: [[Clarity Sheet]] und [[Mindset & Glaubenssätze]]. Die laufenden Tracker (Daily Activity, Lead-, Habit-, Setup-Fortschritt, Journal) leben im Notion-Workspace selbst, nicht im Vault. Community/Kontakt: inner-goat.com · info@inner-goat.com · BRYGHT | Inner GOAT. — Marco & Nel.

## Verwandte Notizen

- [[Clarity Sheet]]
- [[Mindset & Glaubenssätze]]
- [[Founder Workspace V2]]
- [[Inner GOAT]]
- [[Home]]
