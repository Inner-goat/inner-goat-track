---
type: wissen
tags: [academy, implementierung, mindset, glaubenssaetze, uebungen, visualisierung, higher-self]
reiter: Reiter 1 – Implementierung
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 5 – Übungen und Training

Das abschließende Modul von Reiter 1 – Implementierung der [[Inner GOAT Academy]] überführt das theoretische Wissen der vorherigen Module in konkretes, wiederholbares Training. Nachdem die Teilnehmer gelernt haben, wie ihr System, ihre Identität und ihre Glaubenssätze funktionieren und wie sich Blockaden lösen lassen, liefert Modul 5 die praktischen Übungen, um neue Überzeugungen dauerhaft zu verankern.

Die Kernidee: **Wissen allein verändert nichts.** Das Mindset ist ein Muskel — dauerhafter Wandel entsteht nur durch regelmäßige Wiederholung, genau wie beim Sport. Die Übungen sind bewusst so gebaut, dass man sie immer wieder aufrufen kann, insbesondere für Glaubenssätze, die im Alltag gerade akut sind.

Thematisch ist das Modul eng verwandt mit [[Der Bruch als Bauplan]]: Das alte System kämpft ums Überleben, und genau die Widerstände (die „Tests") sind das Signal, dass echte Transformation im Gange ist.

---

## 01 · Einführung Übungen

Video-Einführung, in der Nils Konzept und Aufbau des Moduls vorstellt.

**Worum es geht:** Modul 4 hat die häufigsten Blockaden theoretisch beleuchtet — Modul 5 baut darauf auf und liefert konkrete, wiederholbare Übungen und Techniken, mit denen neue Überzeugungen verankert und alte Muster aufgebrochen werden.

**Kernaussagen:**
- Am Anfang stehen ein paar Erklärvideos, die Prinzipien vertiefen; darunter finden sich jeweils die zugehörigen Aufgaben.
- Empfehlung: Die Aufgaben nicht nur einmal durchgehen. Die Wirkung entsteht durch **Wiederholung** — idealerweise als feste Zeit (halbe Stunde bis Stunde am Wochenende oder abends), gezielt für Glaubenssätze, die gerade sehr akut sind.
- Was das Modul abdeckt: Arbeit mit Glaubenssätzen (Higher Self, neue Überzeugungen verankern), Visualisierung, alltagstaugliche Anleitungen, Umgang mit Rückschlägen und Widerstand.

**Mindset-Impuls (A3):** Erfolg entsteht nicht durch einen einzigen großen Sprung, sondern durch einfache, tägliche Schritte. Der häufigste Fehler ist, zu groß zu denken, statt klein zu starten. Klein denken und täglich tun — so entsteht Momentum, das sich selbst verstärkt.

**Community-Aufgabe:** Welche Übung nimmst du dir zuerst vor — und wann genau führst du sie zum ersten Mal durch? Plan in der Community teilen.

---

## 02 · Higher Self Glaubensätze

In dieser Lektion geht es darum, auf Überzeugungsebene das Higher Self zu integrieren — also die stärkenden Glaubenssätze zu entwickeln, die deine Zielversion bereits trägt.

**Grundprinzip:** Alles, was du glaubst, kannst du *für* dich oder *gegen* dich glauben. Worauf du dich fokussierst, wird mehr. Also: glaube für dich.

**Das System als Computer:** Über die fünf Sinneskanäle (hören, riechen, sehen, schmecken, fühlen) nimmst du Reize auf. Diese laufen durch deine Programmierungen (Glaubenssätze) und produzieren Gedanken → Emotionen → Verhalten → Ergebnisse. Deine „Software" braucht Updates: Hinderliche Programme wurden im letzten Modul gelöscht — jetzt werden neue installiert.

**Das Leitsystem (wie ein Navigationsgerät):** Der Mensch hat körperliche, emotionale und spirituelle Bedürfnisse. Das Leitsystem arbeitet stark unbewusst und meldet sich, wenn du vom Weg abkommst. Es funktioniert nach vier Prinzipien:

1. **Es braucht ein Ziel** — konkret (z.B. „10.000 € Monatsumsatz") oder potenziell (z.B. „Ich bin ein gefragter Coach"). Ohne Ziel keine Richtung. Wichtig: Achte, *welches* Ziel du setzt — hast du das Ziel „nicht abgelehnt zu werden", führt dich das Leitsystem genau dorthin.
2. **Entspannung statt Anstrengung** — Brian Tracy: „In allen mentalen Dingen ist die Anstrengung selbst ihr größter Feind." Entspannung bringt dich schneller zum Ziel (Fahrradfahren mit Rückenwind statt Gegenwind).
3. **Negatives Feedback ist wichtig** — Fähigkeiten werden durch Versuch und Irrtum gelernt (Babys beim Greifen). Erfolge werden gespeichert und überschreiben fehlerhafte Systeme. Rückschläge sind kein Zeichen für den falschen Weg.
4. **Vertrauen** — die Geduld und Gewissheit, dass sich das Leitsystem meldet, wenn du abkommst. An diesem Punkt mit dem Higher Self aus Modul 1 verbinden.

**Ergänzende Prinzipien aus dem Begleitdokument:**
- Neue Überzeugungen müssen **gefühlt** werden — nicht durch reines Nachdenken, sondern durch emotionale Verbindung. Das Gehirn unterscheidet nicht zwischen Vorstellung und Realität.

**Übung – Dein Higher Self:** Stell dir vor, du bist bereits die Version von dir, die du sein möchtest. Schreibe 5–10 Glaubenssätze auf, die diese Person über sich, ihr Business und ihre Kunden hat.

**Mindset-Impuls (A3):** Negative Überzeugungen machen uns zu „Zombies unserer eigenen Vergangenheit". Sätze wie „Ich bin nicht gut genug" produzieren genau diese Ergebnisse. Aber: Mindset ist kein Schicksal, sondern ein Programm, das du neu schreiben kannst.

**Community-Aufgabe:** Schreibe 3 stärkende Higher-Self-Glaubenssätze auf, die sich noch nicht „wahr" anfühlen, aber wahr sein sollen. Gütekriterien: wahr, flexibel, überzeugend, nützlich.

---

## 03 · Neue Glaubensätze annehmen

Hier geht es darum, neue Glaubenssätze nicht nur zu kennen, sondern sie wirklich **anzunehmen und in den Alltag zu integrieren** — der Übergang von bewusster zu unbewusster Kompetenz.

**Vorgehen:** Nicht alles auf einmal. Stück für Stück, und mit dem Stärksten anfangen — also mit den Glaubenssätzen, wo du gerade selbst eine akute Blockade spürst. Sonst droht Überforderung.

**Die zentrale Hebel-Frage:**
> „Wie müsste ich mich verhalten, wenn ich nach meinem neuen Glaubenssatz handele?"

Der Trick: Nicht darauf warten, den Glaubenssatz zu „fühlen" — sondern sofort so handeln, als ob er bereits wahr wäre. Beispiel: Wenn ich überzeugt bin, „Als Verkäufer bin ich Problemlöser und Chancengeber" — wie handle ich dann im Chat, in Gesprächen, in der Akquise, mit Kunden?

**Reflexionsfragen zum Implementieren:**
- Woran würdest *du* erkennen, dass der Glaubenssatz ein Teil von dir ist? Woran würden *andere* es erkennen?
- Wie nehmen dich deine Mitmenschen wahr? Wie gehst du mit dir und anderen um? Wie redest du mit dir und anderen?
- Wie reagierst du in Situationen, in denen du sonst Herausforderungen hast?
- Bist du **proaktiv** oder passiv? Bist du **bereit zu lernen**? Wie **artikulierst** du dich? Wie **fühlst** du dich?
- Was macht dein Higher Self anders als deine jetzige Person?

**Bewusstsein ist essenziell:** Wenn sich nach ein, zwei Tagen nichts ändert, ist die Gefahr groß, in alte Muster zurückzufallen. Manchmal dauern Dinge, bis sie anlaufen — genau das ist Training, kein Scheitern.

**Schritt-für-Schritt-Übung (aus dem Begleitdokument):**
1. Identifiziere einen hartnäckigen, limitierenden Glaubenssatz.
2. Finde heraus, in welcher Situation er entstanden ist — und was du damals daraus geschlossen hast.
3. Mach dir bewusst, dass du diese Schlussfolgerung **interpretiert** hast. Hänge an den Glaubenssatz: „Und daraus habe ich geschlossen, …" — und lies ihn mehrmals laut vor.
4. Hinterfrage die Logik: „Woher weiß ich, dass meine Schlussfolgerung zu 100 % den Tatsachen entspricht?" / „Wenn ich es gar nicht weiß — könnte es dann auch anders sein?" / „Wie könnte es noch sein?" → mindestens 5–10 alternative Möglichkeiten aufschreiben.

**Mindset-Impuls (A3):** Übernimm volle Verantwortung — nicht als Selbstgeißelung, sondern als Befreiung. Wer aufhört, sich als Opfer zu sehen, fängt an, als Macher zu handeln.

**Community-Aufgabe:** Wähle einen Glaubenssatz, den du gerade aktiv annimmst. Beschreibe konkret, welches Verhalten du ab sofort ableitest — und melde dich in einer Woche mit deiner Erfahrung zurück.

---

## 04 · Glaubensätze verstärken

In dieser Lektion zeigt Nils, wie du neue Glaubenssätze aktiv **stärkst und festigst** — durch schriftliche Übungen und den Aufbau eines inneren Verteidigungssystems.

**Auswahl der neuen Glaubenssätze:** Wähle Glaubenssätze, die sich für dich gut anfühlen — entweder aus den vorgeschlagenen Listen (Geld, Verkaufen, Identität, Kunden, Business) oder selbst formuliert. Nutze besonders die, die du in der Übung aus Lektion 03 bearbeitet hast. Alte und neue Glaubenssätze übersichtlich gegenüberstellen.

**Kernübung – Angriff und Verteidigung:** Für jeden neuen Glaubenssatz baust du ein inneres Rollenspiel auf. Der **Verteidiger** hält den neuen Glaubenssatz; der **Angreifer** ist der Kritiker im Kopf (Zweifel, alter Glaubenssatz, mögliche Einwände anderer). Du schreibst den Dialog aus und liest ihn regelmäßig durch — das bestärkt den Glaubenssatz enorm.

Beispiel (verkürzt): Neuer Satz „Ich kann aktiv auf Leute zugehen und sie von mir als Berater begeistern" (70 % überzeugt). Angriff: „In Spezialfällen hast du nicht das nötige Fachwissen." Verteidiger: „Wenn ich etwas nicht beantworten kann, habe ich ein Netzwerk, um Experten hinzuzuziehen — und es gibt mir die Chance zu lernen." Und so weiter, Einwand um Einwand.

**So nutzt du die Übung:**
1. Wähle einen neuen Glaubenssatz, den du verankern willst.
2. Schreibe alle möglichen Einwände dagegen auf (der „Angriff").
3. Formuliere zu jedem Einwand eine überzeugende Antwort aus der neuen Überzeugung heraus (der „Verteidiger").
4. Lies die Tabelle regelmäßig — idealerweise täglich.

Zusätzlich: **Beweise sammeln** für jeden Glaubenssatz (leitet über zu Lektion 05).

**Vorschlagslisten aus dem Begleitdokument:**

*Zu Geld:* Ich darf Geld verlangen · Ich entscheide mich für Reichtum · Ich fühle mich wohl mit viel Geld · Ich genieße es, Geld zu verdienen · Ich habe es verdient, viel Geld zu haben · Ich ziehe Geld an · Mit Macht und Geld kann ich viel Gutes bewirken.

*Zum Verkaufen:* Als Verkäufer bin ich Chancenvermittler und Problemlöser · Ich weiß, was dem Kunden das Leben leichter und erfolgreicher macht · Ich schaffe Mehrwert · Der Return on Investment des Kunden wird deutlich höher sein als sein Investment · Ich liefere Mehrwert, für den er später dankbar ist.

**Mindset-Impuls (A3):** Mangelnder Fokus ist eine der größten Gefahren fürs Wachstum. Moderne Ablenkungen kämpfen wie Gladiatoren um deine Aufmerksamkeit. Wer Fokus trainiert, trainiert die Fähigkeit, an seinen Überzeugungen dranzubleiben.

**Community-Aufgabe:** Erstelle deine eigene Verteidiger-Angriff-Tabelle für deinen wichtigsten neuen Glaubenssatz. Teile Glaubenssatz und stärksten Verteidiger-Satz — und lass andere Lücken in der Verteidigung finden.

---

## 05 · Finde Beweise

Diese Lektion erklärt, warum das aktive **Suchen nach Beweisen** für neue Glaubenssätze entscheidend ist — und wie sich die Technik in den Alltag integriert. Nils vermittelt das Prinzip über eine eigene Anekdote (ein schönes Beispiel für [[Storytelling Wissen]] in der Lehre).

**Das Grundprinzip:** Glaubenssätze leben davon, bestätigt zu werden, und sterben, wenn wir Gegenbeweise finden. Das Gehirn arbeitet nach **selektiver Wahrnehmung** — es sieht, was es zu sehen erwartet. Wer glaubt, kein guter Verkäufer zu sein, nimmt jede Absage als Beweis wahr und ignoriert Erfolge. Diesen Mechanismus kannst du bewusst umkehren.

**Nils' Story:** Sein alter Glaubenssatz war „Ich muss hart arbeiten und extrem viel leisten, um Kunden zu verdienen" — und das funktionierte auch. Dann sah er Freunde mit mehr Umsatz bei weniger Arbeit (kleines Ad-Budget, riesiger ROI, entspanntes Auftreten). Diese **Gegenbeispiele** brachten ihn auf einen neuen Glaubenssatz: „Meine Traumkunden kommen auf mich zu." Er suchte gezielt nach Belegen — eine Anfrage hier, eine Weiterempfehlung dort, Verlängerungen von selbst — und der Satz verfestigte sich. Das veränderte sogar seine unbewusste Ausstrahlung.

**Die Übung – Beweise sammeln:** Schreibe täglich 3–5 konkrete Situationen auf, die deinen neuen Glaubenssatz bestätigen, egal wie klein. Schon der Kaffee, den du dir mittags frei kaufst, ist ein Beweis für „Geld ist Freiheit". Beispiel für „Ich bin ein guter Coach und helfe Menschen": „Ein Kunde sagte, das letzte Gespräch habe ihm sehr geholfen." / „Ich habe ein schwieriges Thema einfach erklärt."

**Was dabei passiert:** Dein Gehirn beginnt aktiv nach solchen Momenten zu suchen; du trainierst deine Wahrnehmung aufs Positive; der Glaubenssatz bekommt immer mehr „Ankerpunkte" in der Realität und fühlt sich mit der Zeit wie eine Tatsache an. Auch die Vergangenheit lohnt sich: Wo waren schon Beweise, die du ausgeblendet hast?

**Wichtig:** Es geht *nicht* darum, die Realität zu verzerren — sondern Dinge zu sehen, die wirklich passieren, aber bisher übersehen wurden.

**Empfehlung:** Ein tägliches „Beweis-Tagebuch", 5 Minuten morgens oder abends.

**Mindset-Impuls (A3):** Tue, was dich wirklich bewegt. Nur wer aus echter Überzeugung handelt, findet täglich neue Beweise. Leidenschaft ist der Motor, der Glaubenssätze von einer Idee in gelebte Realität verwandelt.

**Community-Aufgabe:** Starte heute dein Beweis-Tagebuch. Schreibe 3 Beweise für deinen wichtigsten neuen Glaubenssatz auf (heute oder aus der Vergangenheit) und teile einen davon.

---

## 06 · Visualisierung

Diese Lektion führt in die Kraft der **Visualisierung** ein — eine der wirkungsvollsten Techniken, um neue Überzeugungen zu verankern und sich mental auf Erfolg vorzubereiten. Sie arbeitet auf der Gedanken- und Emotionsebene.

**Was ist Visualisierung?** Bildhafte Vorstellungen davon zu entwickeln, wer du gerne wärst und was du gerne hättest — so lebendig, dass dein Gehirn sie als real verarbeitet.
> „Dein Computer stellt die Daten, die du ihm fütterst, nicht in Frage, sondern verarbeitet sie."

Das Gehirn unterscheidet nicht zwischen einer lebhaften Vorstellung und dem realen Erleben — dieselben neuronalen Muster entstehen.

**Zentrale Erkenntnis:** Du visualisierst *ständig* — meist unbewusst und oft negativ (Grübeln, Sorgen, Worst-Case). Wenn du dir vorstellst, wie du die Steuererklärung machst, einen Kundentermin hast oder dir Sorgen um eine Rechnung machst, ist das Visualisierung. Der Schlüssel liegt darin, es **bewusst** und **positiv** zu tun. Über positive Bilder aktivierst du dein zielorientiertes Leitsystem, das dich automatisch dorthin führt.

**Anleitung – so visualisierst du richtig (so detailliert wie möglich):**
- **Was siehst du?** → Farben, Formen, Personen, Helligkeit, Umgebung
- **Was hörst du?** → laut/leise, dumpf/klar, nah/fern, Geräusche/Musik
- **Was fühlst du?** → Körpergefühl, Emotion, Energielevel; *wo* im Körper sitzt das Gefühl?
- **Was sagst du?** → deine Worte, dein Tonfall, deine Körpersprache

Je öfter und detaillierter du positiv visualisierst und dabei richtig in das Gefühl gehst, desto realer erscheint das Endergebnis. Neue Wünsche kombiniert mit starken Gefühlen produzieren neues Verhalten. Es geht darum, das „Bild des Siegers" vor sich zu sehen — den Weg musst du noch nicht genau kennen.

**Praktische Übung:** Nimm dir täglich 5–10 Minuten (idealerweise morgens) und visualisiere eine konkrete Situation, auf die du dich vorbereitest (Salescall, Erstgespräch, Akquise, Präsentation). Geh durch die Situation, als wäre sie bereits erfolgreich verlaufen — und spüre die Emotion dahinter. Du kannst auch dein Higher Self visualisieren.

**Mindset-Impuls (A3):** Die Komfortzone ist nicht der Feind, sondern der Ausgangspunkt. Ziel ist nicht, sie zu verlassen, sondern kontinuierlich zu erweitern. Visualisierung bereitet dein Gehirn auf die Version von dir vor, die du werden willst.

**Community-Aufgabe:** Visualisiere heute Abend oder morgen früh 5 Minuten eine konkrete Situation. Beschreibe danach kurz: Was hast du gesehen, gehört und gefühlt — und wie hat es deine Stimmung beeinflusst?

---

## 07 · Das Universum wird dich testen

Die abschließende Lektion behandelt eines der wichtigsten Mindset-Konzepte: Warum **Rückschläge und Widerstände** nicht das Gegenteil von Fortschritt sind, sondern ein Zeichen, dass du auf dem richtigen Weg bist. Das ist inhaltlich der Kern von [[Der Bruch als Bauplan]] — das alte System kämpft um sein Überleben.

**Das Kernkonzept:**
> „Das Universum — oder dein Unterbewusstsein — wird dich testen, sobald du anfängst, dich zu verändern."

Sobald du neue Glaubenssätze annimmst, größere Ziele verfolgst oder aus alten Mustern ausbrichst, stößt du auf Widerstand. Das ist kein Zufall. Randbemerkung von Nils: „Es gibt keine Business-Probleme — nur persönliche Probleme, die sich in deinem Business manifestieren."

**Nils' Stories:**
- Als er sich ein familiäres Thema ansah, kamen Tage später — ohne aktive Beschäftigung — starke negative Emotionen hoch, und plötzlich tauchten passende Menschen in seinem Leben auf. Tests.
- Ein Kunde erkannte in einer Session, dass er glaubte „Die Welt ist gegen mich", und transformierte den Satz zu „Die Welt ist für mich" — er ging bester Laune raus. Zehn Minuten später platzte ein Vertrag. Nils' Antwort: „Das ist ein Test. Bist du wirklich bereit, den neuen Glaubenssatz anzunehmen?"

**Warum das passiert:**
- Das Gehirn liebt **Konstanz** — Veränderung wird als Bedrohung wahrgenommen.
- Alte Systeme (Gewohnheiten, Überzeugungen, soziales Umfeld) „testen", ob du es ernst meinst.
- Rückschläge kurz nach einer Entscheidung sind besonders häufig — und besonders gefährlich, weil sie sich wie ein Signal zum Aufhören anfühlen.

**Die richtige Interpretation (Umdeutung):**

| Was du denkst | Was es wirklich bedeutet |
| --- | --- |
| „Das klappt nicht für mich." | „Ich bin nah an einer echten Veränderung." |
| „Vielleicht ist das doch nicht mein Weg." | „Ich werde gerade getestet." |
| „Ich schaffe das nicht." | „Mein altes System kämpft um sein Überleben." |

**Die richtige Haltung:** Nicht ängstlich durch den Tag gehen, sondern mit vollem Vertrauen und offener Neugier: „Was in meinem Leben will mich gerade für meine neuen Glaubenssätze testen?" Jeder Gegenbeweis ist nur ein Test. Und es ist nicht schlimm, einen Test mal nicht zu bestehen — entscheidend ist das **Bewusstsein**, dass du zurückgefallen bist, denn dann kann dein Leitsystem dich wieder auf die richtige Bahn bringen. Mit jedem Test wirst du stärker und resilienter.

**Kernbotschaft:** Die entscheidende Frage ist nicht „Werde ich getestet?", sondern **„Wie reagiere ich auf den Test?"** Wer die Testphasen übersteht, wächst. Wer beim ersten Gegenwind aufhört, bleibt, wo er ist. Geh mit der Frage rein: „Was kann ich dabei über mich lernen?"

**Mindset-Impuls (A3):** Angst ist kein Hindernis, sondern ein Aktivposten — sie zeigt, dass du an deiner Wachstumsgrenze bist. Trainiere deinen Risikomuskel: Je öfter du trotz Angst handelst, desto stärker wirst du.

**Community-Aufgabe:** Beschreibe eine Situation, in der du gerade getestet wirst oder kürzlich wurdest. Wie hast du reagiert — oder wie wirst du reagieren? Teile deinen Test in der Community; ihr seid nicht allein damit.

---

## Verwandte Notizen

- [[Inner GOAT Academy]] — Gesamtstruktur und Reiter
- [[Storytelling Wissen]] — Nils lehrt hier durchgängig über Anekdoten (Lektion 05, 07)
- [[Der Bruch als Bauplan]] — die „Tests" des Universums als Wachstumsbrüche (Lektion 07)
- Higher Self — Bezugsversion für neue Glaubenssätze (Lektion 02, 03, 06)
