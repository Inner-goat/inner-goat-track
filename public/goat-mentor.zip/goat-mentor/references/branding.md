---
type: wissen
tags: [branding, marke, voice, funnel, inner-goat]
quelle: Notion
erstellt: 2026-07-08
---

# Branding

Der Markenkern von [[Inner GOAT]]: wofür die Marke steht, wie sie klingt, wie sie aussieht — und wie die einzelnen Gewerbe als Funnel ineinandergreifen (von Social über Podcast und Academy bis [[Mailenstein GbR]]).

## Markenarchitektur — welche Marken es gibt

- **Marco (Personal Brand)** — Instagram, LinkedIn, [[insight Impact]]
- **Nel (Personal Brand)** — LinkedIn (genannt Steinkühler)
- **[[Inner GOAT]]** (im Vordergrund, orange) — Podcast, Storybuilder Cards & Pro, Storytelling-Beratung, [[Wall of GOATs]], **Inner GOAT Academy**, (zukünftig) Sales Cards, (zukünftig) Sales Quick Beratung, (zukünftig) GOAT Assistants / Inner GOAgenTs
- **[[Mailenstein GbR]]** (im Hintergrund) — braucht Logo + eigene Webseite. Positionierung: Investor Relations / Events / Premium premium premium / black & white / mystisch, elegant, elitär, schlicht

**Wozu die einzelnen Gewerbe dienen:**
- den Mehrwert und den *perceived value* von Inner GOAT stärken (schöne Webseite mit Marco = Storytelling und Nel = Sales)
- eigene Flexibilität
- Speaker-Auftritte

## Positionierung — Inner GOAT vs. Mailenstein

Während **Mailenstein** Premium-Beratung für fortgeschrittene Personal Brands und Unternehmen macht, ist **Inner GOAT** die Marke für deutschsprachige Gründer, die am Anfang ihrer Selbstständigkeit stehen.

**Der Funnel:**

Instagram / TikTok und LinkedIn → Inner GOAT Podcast → [[Inner GOAT Academy]] → [[Mailenstein GbR]] Beratung

## Branding-Guidelines

**Logo:**
- immer orange auf weiß
- Social-Media-Logo immer gleich

**Sprache:**
- Alles ist auf Deutsch

## Geschichte, Versprechen, Vision

- **Grundgeschichte:** Wir wollen eine Community für gleichgesinnte Gründer schaffen.
- **Kern-Konzept:** Wir glauben an die innere Ziege — dein Vorbild und bestes Potenzial ist in dir.
- **Versprechen:** Wir machen Unternehmertum so leicht, dass es jeder kann — indem wir ein Ökosystem schaffen, in dem sich jeder hilft, und die richtigen Tools an die Hand geben.
- **Vision:** Wir bauen die mutigste Gründercommunity Deutschlands. Wir geben dem Unternehmer alles, was er braucht, um erfolgreich zu sein (die Welt verändern und dabei Geld drucken).

## Verwandt

- [[Inner GOAT]] · [[Inner GOAT Academy]] · [[Mailenstein GbR]]
- [[Video-Guidelines]] · [[Reel-Skripte (Beispiele)]] · [[Newsletter-Master-Strategie]]
- [[Outreach-Stil LinkedIn]] · [[Storytelling-Content-Regeln]]
