---
type: wissen
tags: [academy, networking, community, netzwerk, host-mindset, dunbar, social-currency, storytelling]
reiter: Reiter 2 – Networking & Storytelling
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 1 – Netzwerk & Community

Teil der [[Inner GOAT Academy]]. Nachdem Reiter 1 an der inneren Welt gearbeitet hat (Klarheit, Energie, Identität, Glaubenssätze), geht dieses Modul nach außen: zu einer der wichtigsten Ressourcen für Leben und Business – dem Netzwerk.

Die Kernthese des Moduls: **Fast alles, was wir über Networking gelernt haben, ist falsch.** Networking ist nicht Visitenkarten tauschen, nicht möglichst viele Kontakte sammeln, nicht auf Events pitchen. Echtes Netzwerken ist menschlich, natürlich und basiert auf Geben statt Nehmen. Das Leitbild des ganzen Moduls: **Netzwerken = Gärtnern, nicht Jagen.** Diese Haltung schlägt eine Brücke zu Marcos Storytelling-Arbeit im [[Storytelling Wissen]] und zu [[Relevanz]] – denn ein Netzwerk wirkt nur, wenn du für andere relevant wirst.

Die sieben Lektionen bauen aufeinander auf: von der Grundhaltung (Investor / Host) über die Club-Mechanik und Netzwerktypen bis zu Dunbar-Zahl, Social Currency und dem Spiegel-Prinzip.

---

## 01 · Einführung Netzwerk: Be an investor

Auftakt-Video zu Reiter 2. Es rahmt das gesamte Modul und stellt die provokante These auf: Fast alles, was du über Networking gelernt hast, ist falsch – Kontakte sammeln und pitchen ist das *Gegenteil* von echtem Netzwerken.

**Kernaussagen:**
- Networking heißt **investieren und organisieren** – man weiß nie, wen man treffen wird. Jeder ist ein Investor.
- Die Essenz beim Netzwerkaufbau: Menschen, Profession und Purpose kennen. Egal wo du bist – verhalte dich wie der **Co-Gastgeber, nicht wie der Gast**.
- Networking ist **kein Jagen (Hunting), sondern Gärtnern (Gardening)** – das Kultivieren von Beziehungen und einer Kultur des Vertrauens.

**Die drei Leitprinzipien:**
1. Networking bedeutet, eine Kultur des Vertrauens wachsen zu lassen – Gardening, nicht Hunting.
2. Vertrauen aufbauen heißt, in andere zu investieren – **Give, don't take.**
3. Du investierst in andere, indem du dein **Child's Mindset** anwendest (neugierig, offen, frei von Kalkül).

**Ziel des Networkings:** dezentrale Netzwerke mit einem zentralen Wertesystem schaffen. Themen, die nicht passen (Politik, Fußball), werden herausgeschnitten. Du „manipulierst" die Kultur einer Gruppe im positiven Sinn: Du baust ein Framework, machst Regeln – und lässt den Menschen zugleich ihre Individualität.

**Host als Statusgewinn:** Bei den meisten Events schätzen Menschen die *Verbindungen* am meisten – selbst wenn Location und Essen schlecht sind. Trotzdem liegt das durchschnittliche Budget fürs Verbinden bei null. Gutes Hosting schafft eine Private-Party-Atmosphäre (so machen es die Superreichen). Wer profitiert am meisten? Immer der Host – durch das Verbinden von Menschen steigt sein sozialer Status. **Goldene Regel: Sei immer der Host.**

**Community-Aufgabe:** Was war dein größtes Missverständnis über Networking, bevor du dieses Modul angefangen hast? Und was hat sich durch die Einführung schon verändert?

---

## 02 · Netzwerk = Wie bauen wir einen Club?

Diese Lektion verschiebt den Fokus von *Kontakten* auf *Wirkung* und liefert eine konkrete Bauanleitung für eine Community („Club").

**Kernprinzip – eine Kontaktliste ist kein Netzwerk:**
Wie viele Kontakte sind im Handy gespeichert – und wie viele davon *wirken* tatsächlich? Ein echtes Netzwerk ist wie ein Organismus: Es lebt, wenn etwas fließt. Wirkung entsteht erst, wenn Menschen einander helfen. Sonst ist es nur ein Adressbuch.

**Beiträge sichtbar machen (Social Credits):** Ein Gründer bittet nach jedem Event um Feedback – „Wer hat dir heute geholfen? Wer hat dir eine Tür geöffnet?" Die Top-Connectoren werden öffentlich gefeiert. Menschen *wollen* helfen – sie brauchen nur einen Rahmen dafür.

**Werte statt Meinungen:** Ein starkes Netzwerk basiert nicht auf gleichen Meinungen, sondern auf gemeinsamen Werten – Respekt, Großzügigkeit, Neugier. „Du musst nicht denken wie ich. Aber wir müssen das gleiche Spiel spielen. Wir müssen wollen, dass andere wachsen."

**Wie baut man einen Club? (Checkliste):**
1. **Meeting Routines** – das Wichtigste: Frequenz. (Die Kirche trifft sich jeden Sonntag.)
2. Vision
3. Wertesystem
4. Network Rules
5. **Meeting Rituals** (ohne Rituale fühlen sich Leute verloren – Rituale geben Verbundenheit)
6. Kommunikationskanäle
7. Network Name
8. Member Acquisition System
9. Catering
10. VIP Guest

**Struktur ist Pflicht:** Wenn sich jemand danebenbenimmt, greift der Host ein (Non-Ego-Mindset – Verantwortung übernehmen). Ohne Struktur kein Netzwerk – sonst verbreitet sich schlechtes Verhalten wie ein Virus. Kultur ist ein Set aus **Regeln, Werten und Ritualen.**

**Vision:** Eine gute Vision bewirkt extrem langfristigen, emotional positiven Wandel und bringt Benefits. Entscheidend ist, die Vision effektiv kommunizieren zu können.

**Die 3 Rs:**
- **Routines:** Mach es regelmäßig (Beispiel Rotary Club – wöchentliches Treffen, rotierende Besuche, jeder bringt jemanden mit).
- **Rituals:** z. B. 3-minütige Meditation zu Beginn, der erste Kaffee, die erste Vorstellung. Sie geben Sicherheit, reduzieren Ängste, schaffen Wohlgefühl.
- **Rules:** Wie man sich verhält – z. B. keine Pitches.

**Medien = Macht:** Wer entscheidet, welche Kommunikation durchgeht, hat die Macht. Für die Kirche war das Sonntagstreffen die „Radiostation". Martin Luther war erfolgreich, weil er ein neues Kommunikationstool nutzte – den Buchdruck.

**Aufgabe:** Scroll durch deine Kontakte. Wen könntest du heute mit jemandem vernetzen, dem das helfen würde? Schreibe eine kurze Nachricht – ohne Gegenleistung.

---

## 03 · Host-Mindset & Angels: Räume für andere schaffen

Die zentrale Haltungs-Lektion des Moduls: eine einzige Entscheidung, die alles im Networking verändert – die **Host-Haltung**.

**Was bedeutet Host-Mindset?** Sei immer der Gastgeber, egal wo du bist. Die meisten gehen zu einem Event und fragen: „Was bekomme ich heute?" Der Host fragt: „Wem kann ich helfen? Wen kann ich mit wem bekannt machen? Wie sorge ich dafür, dass sich Menschen wohlfühlen?" Menschen erinnern sich an *Erlebnisse* – nicht an Orte oder Inhalte. Wer das positive Erlebnis schafft, wird erinnert.

**Beispiel:** Ein Gründer geht als Teilnehmer (nicht Veranstalter) zu einer Konferenz, begrüßt Gäste, stellt Menschen vor, sorgt dafür, dass Gespräche entstehen. Er wird als Gastgeber wahrgenommen und bekommt Zugänge, die anderen verschlossen bleiben – nicht wegen Status, sondern weil er **Verantwortung übernommen** hat.

**Gastgeber-Status als Wettbewerbsvorteil:** Der Host bringt Respekt, Vertrauen und Sichtbarkeit. Du musst kein Event veranstalten, um Gastgeber zu sein – du kannst es in jedem Gespräch, jeder Gruppe, jeder Situation sein.

**Angels – dezentrale Gastgeber:** Wenn du Formate kreierst (Events, Calls, Communities), setzt du *Angels* ein: Menschen, die deine Werte verkörpern und als dezentrale Gastgeber wirken. Kurze Sprachnachricht vor dem Event: „Begrüße drei Neue, verbinde zwei Menschen mit ähnlichen Zielen." So multiplizierst du deinen Impact, ohne überall gleichzeitig zu sein. (Im Change Management heißen sie **Change Agents**.)

**Vertiefende Konzepte:**
- **Social Coding:** Du veränderst die Kultur einer Gruppe. Ein Ad-hoc-Netzwerk ist eine „Aufzug-Situation" – übernimm Verantwortung. Selbsttest: Bring auf einer Party fremde Leute dazu, miteinander zu reden.
- **Center of Attention:** Wer wildfremde Leute verbindet, dessen Social Credits steigen rasant – alle denken, du musst der Host sein.
- Sei nicht der **Concierge** (das Netzwerk um dich herum gebaut), sondern der **Host** (das Netzwerk trägt sich selbst).
- **Skalierungs-Grenze:** Auf einer virtuellen Party schaffst du nur ~150 echte Verbindungen. Willst du darüber hinaus, „werde eine Radiostation, nicht ein Sprecher" – dezentralisiere deinen Host-Spirit (Hospitality Spirit).

**Wege, Menschen zur Interaktion zu bringen:**
- **Intervention:** Spiele und Aufgaben (Speed Dating, Kamera-Pflicht auf Zoom, 6-Augen-Prinzip: mit mind. 3 Leuten reden). Wirksam, aber aufwendig.
- **Involve Angels:** Mitglieder werden zu guten Hosts gebrieft und multiplizieren das Netzwerk.
- **Nudging:** Rahmenbedingungen, die bestimmtes Verhalten fast unvermeidlich machen (Aschenbecher-Position, Schuhe am Eingang, Unisex-Toilette mit einem Waschbecken, langsamer Barkeeper, erzwungene Zoom-Delays). Nudges sind ein Framework – welche Interaktion entsteht, kannst du nicht kontrollieren.

**Leitsatz:** Du bist der perfekte Host, wenn deine Macht *gespürt, aber nicht gesehen* wird.

**Host-Haltung in der Praxis (statt … so):**
| Statt … | … so |
|---|---|
| „Was bekomme ich?" | „Wem kann ich helfen?" |
| Visitenkarten verteilen | Andere miteinander bekannt machen |
| Eigene Geschichte erzählen | Anderen zuhören & Brücken bauen |
| Auf Bestätigung warten | Initiative ergreifen |

---

## 04 · Die 3 Netzwerktypen

Ein klares Framework, um zu erkennen, welchen Netzwerktyp man gerade aufbaut oder in dem man sich bewegt – und dadurch gezielter zu agieren.

**Typ 1 – Ad-hoc-Netzwerk:** Spontan, kurzlebig, oft intensiv (z. B. Menschen mit demselben Ziel im selben Zugabteil). Es entsteht schnell Verbindung, löst sich aber auf, sobald das Ziel erreicht ist. Wertvoll für kurzfristige Aufgaben – nicht der Ort für langfristiges Vertrauen. Nachhaltigkeit: **gering.**

**Typ 2 – Zwecknetzwerk:** Bildet sich um ein konkretes gemeinsames Ziel (Fridays for Future, Projektgruppe, Gründerteam). Mehr Tiefe als Ad-hoc, aber an das Ziel geknüpft. Wird das Ziel erreicht oder aufgegeben, muss sich das Netzwerk neu erfinden, um zu überleben. Nachhaltigkeit: **mittel.**

**Typ 3 – Soziales Netzwerk:** Das kraftvollste und nachhaltigste. Es existiert für die *Beziehung selbst* – nicht für ein Ziel (Rotary Club, Alumni-Netzwerk, echte Community). Menschen kommen zusammen, weil sie zusammen sein wollen – wegen Vertrauen, Werten, gemeinsamer Identität. Aus diesem Netzwerk entstehen *von selbst* neue Projekte, Chancen und Kooperationen. Nachhaltigkeit: **hoch.** Das ist das Netzwerk, das du langfristig aufbaust.

| Typ | Charakteristik | Beispiel | Nachhaltigkeit |
|---|---|---|---|
| Ad-hoc | Spontan, kurzlebig | Zufallsbekanntschaft bei Event | Gering |
| Zweck | Um ein gemeinsames Ziel | Projektgruppe, Bewegung | Mittel |
| Sozial | Für die Beziehung selbst | Community, Alumni, Club | Hoch |

**Die entscheidende Frage:** Was ist der *Wertekern* deines Netzwerks? Nicht das Ziel – sondern die Verbindung. Die meisten bauen unbewusst Ad-hoc- oder Zwecknetzwerke und wundern sich, warum sich alles so kurzlebig anfühlt.

---

## 05 · Dunbar-Zahl: Qualität vor Quantität

Die wissenschaftliche Grundlage für „weniger ist mehr" im Netzwerk – aus der Evolutionsbiologie.

**Die Dunbar-Zahl:** Der Anthropologe Robin Dunbar zeigte, dass das menschliche Gehirn biologisch nur etwa **150 echte Beziehungen** aufrechterhalten kann. Nicht 1.000, nicht 5.000 – so groß waren menschliche Stämme seit ~200.000 Jahren.

**Kontakt ≠ Beziehung:** 3.000 LinkedIn-Kontakte und 2.000 Instagram-Follower sind keine Beziehungen. Eine echte Beziehung braucht Vertrauen, Wiederholung, persönlichen Austausch, gegenseitiges Kennen – das kostet Zeit und emotionale Kapazität. Diese Kapazität ist auf 150 begrenzt.

**Die Dunbar-Schichten:**
| Schicht | Anzahl | Art der Beziehung |
|---|---|---|
| Innerster Kreis | ~5 | Absolutes Vertrauen, erste Anlaufstelle |
| Enger Kreis | ~15 | Echte Freundschaft, regelmäßig |
| Aktiver Kreis | ~50 | Bedeutsame Bekannte |
| Netzwerk | ~150 | Echte Beziehungsfähigkeit |

**Merksatz:** 20 echte, tiefe Beziehungen schlagen 2.000 oberflächliche Kontakte – in Karriere, Business und Leben. Beispiel: Ein Event mit 20 kuratierten Personen bringt oft mehr echte Zugänge als eine Massenveranstaltung mit 500. Priorisieren ist keine Schwäche, sondern **Intelligenz.**

**Was gute Netzwerke brauchen (drei Dinge):**
- **Vertrauen** als Fundament – entsteht durch wiederholte, positive Erfahrungen.
- **Wiederholung** – echte Beziehungen brauchen regelmäßigen Kontakt.
- **Nähe** – nicht unbedingt physisch, aber inhaltlich und emotional.

**Netzwerk-Architektur:** Du bist das Zentrum der Interaktion und musst orchestrieren (griech. *dyctio* = Netz). Wenn du mit jedem befreundet bist, verlässt sich jeder auf dich – das ist die instabile Baum-/Concierge-Architektur. Ein echtes Netzwerk ist eine multi-verbundene Struktur, in der Ressourcen effizient geteilt werden wie in einem Organismus (Prinzip „one out of many" – so wenig Einfluss von oben wie möglich).

**Aufgabe:** Wer sind deine echten Top-20 – die Menschen, mit denen Austausch wirklich bedeutsam ist? Schreib sie auf. Und: Wann warst du zuletzt in echtem Kontakt mit ihnen?

---

## 06 · Social Currency & Werte

Diese Lektion verbindet Networking mit Identität ([[Der Bruch als Bauplan]] und die innere Arbeit aus Reiter 1) und führt zwei kraftvolle Konzepte ein: das **Spiegel-Prinzip** und **Social Currency**.

**Das Spiegel-Prinzip:** *„Das Netzwerk spiegelt dich – positiv wie negativ."* Die Menschen, die du anziehst, entsprechen deinem inneren Zustand:
- Denkst du in Mangel → ziehst du Menschen an, die nehmen.
- Bist du großzügig → ziehst du Menschen an, die geben.
- Bist du unklar → hast du ein diffuses Netzwerk.
- Bist du klar und fokussiert → ziehst du klare, fokussierte Menschen an.

Das ist keine Magie, sondern Psychologie – Menschen lesen unterbewusst deine Energie, Haltung und Klarsignale. Wenn dein Netzwerk dich nicht zufriedenstellt, lautet die erste Frage nicht „Wo finde ich bessere Menschen?", sondern **„Wer bin ich gerade?"**

**Energie schlägt Hierarchie:** Menschen folgen im Netzwerk nicht dem Rang, sondern der **Resonanz**. Du brauchst keinen Titel und keinen Status – du brauchst Energie: Klarheit, Haltung, Intention. Präsenz und echtes Zuhören ziehen an.

**Networking = Persönlichkeitsentwicklung:** Networking ist keine separate Fähigkeit, sondern Arbeit an Kommunikation, Empathie und Selbstführung. Alles aus Reiter 1 (Identität, Glaubenssätze, Selbstbeherrschung) zahlt direkt auf das Netzwerk ein.

**Werte – Vorhersehbarkeit schafft Sicherheit:** Interventions, Nudges, Angels und Values machen uns verlässlich füreinander. Sie sind „manipulativ" im positiven Sinn – sie erzeugen Vorhersehbarkeit, und Menschen wollen Liebe und Sicherheit. Das innere Regelwerk definiert die Identität einer Gruppe.

**Value-Ebenen (Stages of Values):**
- **Personal Level** und **Group Level** (sollten sich überschneiden).
- Ebene 1 – Lifestyle-Werte (dafür würdest du nicht töten).
- Ebene 2 – z. B. ob Englisch gesprochen werden soll.
- Ebene 3 – z. B. ob Frauen zur Schule gehen dürfen.
- **Rezept für robuste Netzwerke:** auf Ebene 1 matchen, auf Ebene 3 divers sein, Ebene 2 muss ergänzen. Ein Basis-Level an Einigkeit ist essenziell. Unterschiedlichkeit (verschiedene Skills) macht stark – nicht zu homogen. Gruppen mit sehr starkem gemeinsamem Wertesystem brauchen keine Leader; je individualistischer die Gruppenwerte, desto selbstständiger und altruistischer funktioniert die Gruppe (wie Special Forces – niemand wird zurückgelassen).

**Social Currency:** Unsere Gesellschaft redet uns ein, Geld sei das Wichtigste – in Wahrheit ist es **Vertrauen** (Geld gibt es erst seit ~9.000 Jahren; davor wurden Ressourcen getauscht). Social Currency ist alles, was du besitzt außer Geld (Wedding-Cake-Modell):
- Dein persönliches Wissen.
- Die Menschen in deinem Netzwerk.
- Deine Organisation – die kollektive Kraft der Ressourcen.

Du setzt Social Currency ein, indem du für Menschen wichtige Probleme löst, die *emotional und dringend zugleich* sind. Wer Sicherheit gibt, für den tun Menschen alles. Voraussetzung: herausfinden, was Menschen wirklich brauchen – dafür musst du **verletzlich bleiben** und echte Gespräche führen.

**Hausaufgabe:** Schreib auf, welche Menschen du kennst und was sie anbieten können – und was du selbst weißt.

**Kernfrage der Lektion:** Wer bin ich, wenn niemand zuschaut? Und: Wer zieht mich gerade an?

---

## 07 · Abschluss Netzwerk & Community

Zusammenfassung und Übergang zu Modul 2 (Storytelling & Kommunikation).

**Was du in diesem Modul gelernt hast:**
- Ein echtes Netzwerk entsteht nicht durch Kontakte, sondern durch **Wirkung** – durch das, was du gibst, und durch die Haltung des Gastgebers.
- Es gibt **drei Netzwerktypen** – das soziale ist das nachhaltigste, weil es auf Beziehung statt Zweck gebaut ist.
- Menschen führen nur ~150 echte Beziehungen (**Dunbar**) – 20 tiefe sind mehr wert als 2.000 oberflächliche.
- **Dein Netzwerk spiegelt dich** – die Menschen, die du anziehst, sind ein Echo deines inneren Zustands.

**Der letzte Gedanke – Netzwerken = Gärtnern, nicht Jagen:**
- *Jagen:* Ich will etwas, habe ein Ziel, schieße. Treffer = gut, sonst Zeitverschwendung.
- *Gärtnern:* Ich pflege, bin geduldig, weiß, dass der Boden Vertrauen braucht und Wachstum Zeit. Nicht jede Pflanze trägt sofort Früchte – aber ein gepflegter Garten trägt irgendwann von selbst.

Die mächtigste Haltung ist das **kindliche Mindset** – neugierig, offen, frei von Kalkül. Beispiel: Ein Gründer geht zu einem Event nicht, um Investoren zu finden, sondern mit der Frage „Wem kann ich heute helfen?". Ein Investor wird auf ihn aufmerksam – nicht weil er gepitcht hat, sondern weil er *nicht* gepitcht hat.

**Deine nächsten Schritte:**
1. Wähle 3 Menschen aus deinem Netzwerk – und melde dich heute ohne Anlass bei ihnen.
2. Überlege: Welche Host-Haltung kannst du diese Woche einnehmen?
3. Denke dein Netzwerk in Schichten: Wer sind deine Top-5? Deine Top-20?

**Leitbild des Moduls:** Netzwerken = Gärtnern, nicht Jagen.

---

*Verwandte Notizen: [[Inner GOAT Academy]] · [[Storytelling Wissen]] · [[Der Bruch als Bauplan]] · [[Die 12 Plots]] · [[Relevanz]]*
