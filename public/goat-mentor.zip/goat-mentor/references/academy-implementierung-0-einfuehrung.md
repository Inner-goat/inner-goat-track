---
type: wissen
tags: [academy, implementierung, einführung, onboarding]
reiter: Reiter 1 – Implementierung
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 0 – Einführung

Das Einstiegsmodul der [[Inner GOAT Academy]]. Es holt den Kunden ab, erklärt, warum diese Video-Akademie anders aufgebaut ist als klassische Online-Kurse, und gibt den roten Faden durch die vier Kernmodule vor. Ziel: das Mindset und die Erwartung setzen, bevor die eigentliche Arbeit an Struktur, Business-Basics, Identität und Drucksituationen beginnt. Kernversprechen: Prokrastination, Overthinking, Antriebslosigkeit und inkonsistente Umsetzung als Themen aus der Welt schaffen, damit der Kunde sein volles GOAT-Potenzial ausschöpft.

## Willkommen

Begrüßungsvideo und Onboarding in die Akademie. Kernaussagen:

- **Begrüßung & Gratulation.** Herzlich willkommen zur Video-Akademie. Glückwunsch zur Entscheidung, das Inner-GOAT-Coaching zu buchen. Freude auf die gemeinsame Zusammenarbeit über die nächsten Monate.

- **Warum diese Akademie anders ist.** Bewusste Abgrenzung von typischen Coaching-Video-Kursen mit „elendig langen Videos", auf die man keinen Bock hat. Die Inner-GOAT-Akademie ist so aufgebaut, dass die Videos kurz gehalten sind und nur die wirklich wichtigsten Dinge vermittelt werden.

- **Was du hier lernst.** Genau die Dinge, damit Prokrastination, Overthinking, Antriebslosigkeit und inkonsistente Umsetzung keine Themen mehr sind. Der erste Schritt der Akademie: alle Hürden aus der Welt schaffen, die davon abhalten, das volle GOAT-Potenzial auszuschöpfen.

- **Der Aufbau der vier Kernmodule:**
  - **Modul 1 – Struktur & Systeme:** Wie strukturierst du dich? Welche Systeme brauchst du für dich und dein Business, um konstant und mit Leichtigkeit in die Umsetzung zu kommen?
  - **Modul 2 – Business-Basics:** Die letzten Basics, die nötig sind, damit das Business funktioniert und läuft.
  - **Modul 3 – Identität & Blockaden:** Schritt für Schritt, wo Blockaden herkommen und wie sie entstanden sind. Mit 1:1-Anleitungen zum eigenständigen Herausarbeiten – und anschließendem Auflösen. (Vgl. thematisch [[Der Bruch als Bauplan]].)
  - **Modul 4 – Druck- und Stresssituationen souverän führen:** Umgang mit Stress- und Drucksituationen im Business-Alltag – für mehr Zeit, mehr Umsatz, mehr Lebensqualität und generell mehr Leichtigkeit. Vermittelt über konkrete Prinzipien und Strategien.

- **Warum die Reihenfolge wichtig ist.** Die Akademie Schritt für Schritt durcharbeiten (sofern nicht individuell anders besprochen). Das Ganze beruht auf einem System, das mit über hundert Inner-GOAT-Kunden etabliert und 1:1 durchgegangen wurde. Videos daher in Reihenfolge ansehen.

- **So nutzt du die Videos langfristig.** Gewisse Videos sind so konzipiert, dass man sie immer wieder anschauen kann. Taucht ein Trigger oder eine Herausforderung erneut auf, holt man sich das passende Video und bringt das Thema wieder ins Bewusstsein.

- **Fragen & Calls.** Fragen, Abweichungen oder Punkte, die nicht zutreffen, immer im Call stellen – dort wird individuell geklärt.

- **Was du mitnehmen wirst.** Videos in Reihenfolge ansehen und die zugehörigen Aufgaben durcharbeiten. Damit lässt sich schon sehr viel lösen: dem Entkommen aus Prokrastination, aus Overthinking und aus negativen Gedankenspiralen.

- **Wie schnell Ergebnisse kommen.** Schon nach einzelnen Videos werden Blockaden aufgelöst. Häufig sind es kleine Hebel, die man umlegen muss, um in die Umsetzung zu kommen und „die vollen PS auf die Straße zu bringen" – statt im Kreisverkehr zu fahren, auf die Überholspur wechseln und Vollgas geben.

- **Los geht's.** Empfehlung: direkt mit dem Einführungsmodul starten.

## Einführung

Reines Video-Element ohne begleitenden Text in Notion. Inhaltliche Einordnung: Der erste inhaltliche Einstieg nach der Begrüßung – führt in die Arbeitsweise und den Aufbau der Akademie ein und leitet zum Prinzipien-Video über. (Kein Lehrtext hinterlegt; Inhalt wird im Video vermittelt.)

## Prinzipien

Reines Video-Element ohne begleitenden Text in Notion. Inhaltliche Einordnung: Legt die grundlegenden Prinzipien der Inner-GOAT-Arbeit fest, auf denen die folgenden Module aufbauen – das gemeinsame Fundament für Struktur, Business-Basics, Identitäts-/Blockadenarbeit und den Umgang mit Druck. (Kein Lehrtext hinterlegt; Inhalt wird im Video vermittelt.)

---

Siehe auch: [[Inner GOAT Academy]] · [[Storytelling Wissen]]
