---
type: wissen
tags: [academy, blockaden, mindset, psychologie, verkaufen, akquise, ablehnung, emotionen, implementierung]
reiter: Reiter 1 – Implementierung
quelle: Notion Inner GOAT Academy
erstellt: 2026-07-08
---

# Modul 4 – Blockaden lösen

Teil der [[Inner GOAT Academy]], Reiter 1 – Implementierung. Nachdem in den vorherigen Modulen Systeme, Planung und Glaubenssätze etabliert wurden, geht es in diesem Modul komplett um **Blockadelösung**: die inneren Hindernisse, die trotz richtiger Strategie und etablierter Systeme davon abhalten, in die Umsetzung zu kommen.

Der Aufbau des Moduls ist bewusst zweiteilig: Zuerst vermittelt Nils **allgemeine Prinzipien** in Form von Vergleichen, Metaphern und Geschichten (Welten, Wert, Emotionen). Danach geht er auf **viele einzelne, konkrete Blockaden** ein (Ablehnung, Verkaufen, Preise, Prokrastination, innerer Kritiker etc.). Die didaktische Kernanweisung: nicht passiv zuschauen, sondern beim Schauen sofort **Verbindungen zur eigenen Situation** herstellen. Einzelne Videos sollen bei Bedarf mehrfach angeschaut werden, wenn eine Blockade akut auftritt.

Roter Faden durch das ganze Modul: Es gibt **kein richtig und kein falsch**, nur „funktioniert das für dich in deinem Wertesystem?". Emotionen sind **Informationen, keine Hindernisse**. **Identität schlägt Verhalten**. Und: Blockaden lösen sich nicht durch Willenskraft, sondern durch Bewusstsein und neue Überzeugungen (vgl. [[Storytelling Wissen]] zum Bruch- und Wandlungsmotiv, [[Der Bruch als Bauplan]]).

---

## 01 · Einführung Blockaden

Modul-Intro und Rahmensetzung. Psychologische Blockaden sind der häufigste Grund, warum Menschen trotz richtiger Strategie und Systeme keine Ergebnisse erzielen. Glaubenssätze und Verhaltensmuster wirken wie unsichtbare Programme; fehlt emotionale Freiheit, bleibt die Umsetzung aus.

Lösungsweg des Moduls: allgemeine Prinzipien über Metaphern/Geschichten verstehen, **sofort** Verbindungen zur eigenen Situation herstellen (nicht nur zuschauen), spezifische Blockaden identifizieren und wiederholt angehen. Allein das aktive Reflektieren schafft Bewusstsein — und „dein System fängt von selbst an zu arbeiten".

**Reflexionsfragen:** Welche Blockade hält dich gerade am meisten davon ab, deine Systeme umzusetzen? Wo bremsen dich innere Blockaden bereits? Welche alten Glaubenssätze stecken dahinter?

**Aufgabe:** Aufschreiben, welche spezifischen Blockaden die Umsetzung gerade verhindern — und bei welchen Videos dieses Moduls die Antworten liegen.

## 02 · Es gibt verschiedene Welten

Kernprinzip, das laut Nils seine Sicht auf Leben und Business komplett verändert hat. Auf der Erde gibt es nicht **eine** Welt, sondern tausende: Selbstständigkeit, Angestelltentum, Sportler-Sein, LinkedIn, Instagram, jede Agentur, jede Familie, jede Wohngemeinschaft. Eine „Welt" = eine Gruppe mit eigenen **Gesetzen, Normen und Regeln** (Metapher: ein riesiger Sportplatz — Handball, Fußball, Tennis; wer beim Handball den Ball kickt, fliegt raus).

**Das Problem:** Menschen leben gleichzeitig in mehreren Welten (z. B. Studium + Business, Angestellt + Business) und **vermischen deren Regeln**. Glaubenssätze der alten Welt (z. B. „Verkaufen ist schlecht", „so viel arbeiten ist uncool") werden in die neue mitgenommen und blockieren dort. Das ist wie Tennis mit dem Baseballschläger — funktioniert nicht.

**Champions-League-Regel:** In jeder Welt gibt es Bedingungen, die zu erfüllen sind. Wer sie verweigert (z. B. keine Akquise, kein Vertrieb), spielt bestenfalls Kreis- oder Oberliga, aber nie Champions League. In der Selbstständigkeit sind Marketing und Akquise solche Gesetze.

**Zweite Ebene — dein eigenes Wertesystem:** Es gibt nicht nur die Welten im Außen, sondern deine innere Welt. Richtig/falsch existiert nur innerhalb eines Wertesystems. Wenn du gegen deine Werte handelst (z. B. ein aufgezwungenes Skript vorliest, das sich falsch anfühlt), wirst du dich **immer selbst sabotieren**. Handelst du integer mit dir selbst, fühlt es sich am leichtesten an. Die Unterscheidung „das ist mein Wertesystem" vs. „das ist eine zu überwindende Blockade" ist Thema der folgenden Videos.

**Aufgabe:** Aufschreiben, was erfolgreiche Menschen in der Zielwelt konkret tun — und ehrlich prüfen, welche dieser Bedingungen man selbst schon erfüllt und welche man noch verweigert.

## 03 · Du hast das Gefühl, nicht gut genug zu sein

Baut direkt auf dem Welten-Prinzip auf. Provokante Ausgangsthese: „Ich bin nicht gut genug — und das ist ein Fakt." Der springende Punkt ist die Rückfrage: **Wofür** nicht gut genug? **Worin** minderwertig? Nils ist nicht gut genug, um beim FC Bayern zu spielen oder 10 Mio. Umsatz zu machen — aber sehr wohl gut genug, um Kunden zu gewinnen und Blockaden zu lösen.

**Das Modell:** Wenn du deine Welt größer machen willst (mehr Umsatz, mehr Tiefe, erster Mitarbeiter, Vertriebsteam), betrittst du eine Zone, in der du **noch keinen Wert bewiesen** hast — dort bist du zunächst „wertlos" (= ohne Wert, nicht: minderwertig als Mensch). Das System interpretiert diese Wachstumszone als Gefahr („könnten abgelehnt werden, könnten sterben") und hält dich klein. Sich beim Betreten einer neuen Welt „nicht gut genug" zu fühlen, ist deshalb **völlig normal und gesund** — kein Defizit.

**Fußball-Probetraining-Metapher:** Wer neu in eine Welt springt, bekommt erst einen Marktwert zugewiesen (Kreisklasse). „Minderwertig" heißt nur: minderer Wert als die Profis — noch. Wert wird **aufgebaut** durch Training, Umsetzung, Ergebnisse. Zentrale Korrektur: **Selbstvertrauen entsteht nicht vor dem Handeln, sondern durch Handeln trotz Unsicherheit.**

Hier trennt sich Spreu vom Weizen: Viele finden Ausreden, ihre Welt klein zu halten (keine Akquise, keine Sales Calls, keine tieferen Beziehungen) — was okay ist, aber dann darf man sich nicht über fehlende Ergebnisse beschweren. Aus jedem Ergebnis → Erkenntnis → Korrektur → besseres Ergebnis.

**Aufgabe:** Einen Bereich identifizieren, wo Wert aufgebaut werden soll, und diese Woche den ersten echten Schritt machen — nicht perfekt, sondern um Ergebnisse zu produzieren und zu lernen.

## 04 · Was ist richtig und was ist falsch?

Ständiges inneres Bewerten („das war gut / falsch / zu langsam") ist einer der größten Stressfaktoren und Blockaden. Kernaussage: **Richtig und falsch sind ein vom Menschen geschaffenes Konstrukt.** Frisst ein Tier ein anderes, ist es weder richtig noch falsch — es ist satt; es hat funktioniert. Die bessere Frage ist nicht „ist das richtig?", sondern „**funktioniert das für dich** (in deinem Wertesystem)?".

**Alles hat einen Vorteil:** Was nur Nachteile hätte, würde nicht existieren (abgebrannter Baum → Mineralien → neues Leben). Auch **Prokrastination hat einen versteckten Vorteil** — z. B. schützt Nicht-Posten vor Ablehnung, vor sichtbarer Inkompetenz, vor wenig Likes. Dahinter liegt meist eine **emotionale Blockade** (Angst) — genau das Gefühl, das man nicht fühlen will. Die Vorstellung dieser Angst ist das eigentliche Hindernis.

**Emotionen werden fälschlich als „falsch" verurteilt:** Angst, Wut, Trauer, Neid — gesellschaftlich geprägt („Indianer weinen nicht"). Diese Verurteilung blockiert. Zentrale Formel: **Schmerz ist normal und unvermeidlich — Leid entsteht erst durch Widerstand.** Widerstand leisten wir im Kopf („so darf ich mich nicht fühlen"). Viele Aufgaben sind mit Emotionen verbunden, die wir erst **als negativ interpretieren** und dann meiden. Leitet über zu Lektion 05.

**Aufgabe:** Eine prokrastinierte Aufgabe notieren, die damit verbundene ungewollte Emotion benennen, erkennen: das Gefühl ist nicht falsch, nur unbequem — und die Aufgabe trotzdem machen.

## 05 · Emotionen verstehen

Vertieft die Emotions-Thematik mit einem Erklärmodell. **Wie Emotionen entstehen:** Wir nehmen über die fünf Sinne permanent Millionen Reize auf und verarbeiten sie gleichzeitig (Metapher: Verdauung — man verdaut nicht Pommes und Schnitzel nacheinander). Die bewusste Verarbeitungskapazität ist winzig; **~99,9 % läuft unbewusst**. Aus diesen 99,9 % entsteht ein Gefühl — ohne dass wir den Auslöser kennen. Das Grübeln über das „Woher" führt oft nur zu Overthinking.

**Das 0,1-%-Problem:** Sobald ein Gefühl auftaucht (Scham, Furcht, Aggression, auch Freude), schaltet sich das bewusste 0,1-%-Ich ein und sagt „so dürfen wir uns nicht fühlen" — obwohl das gesamte Unterbewusstsein dieses Gefühl gerade produziert hat. Wer ist dieses 0,1 %, das das überstimmt?

**Emotion als Leitsystem:** Anknüpfung an das innere Leitsystem (Torpedo-Metapher: kein Navigationsgerät, aber Rückkopplung bei Abweichung). Wiederkehrende Emotionen sind ein Signal des Systems: „Schau dir etwas an." Wiederholte Prokrastination, immer gleiche Menschen/Konflikte im Leben → Hinweis, ein inneres Thema anzusehen. **Dreck unter den Teppich kehren** macht ihn nicht weg, sondern mehr. Wichtige Abgrenzung: **nicht** in Selbstmitleid/Opferrolle verfallen (Finger auf andere = drei Finger auf sich selbst), sondern fragen: „Was gebe ich ins Universum, dass mir das begegnet?"

**Die Herdplatten-Metapher:** Ein Gefühl nur kurz anfassen und wegziehen („alles gut") führt dazu, dass man morgen wieder draufdrückt. Einmal **richtig** hineinfühlen (durch die Scham durchgehen, ehrlich sein) = im Unbewussten wartet eine **Erkenntnis**. Danach passt sich das System **automatisch** an (man geht nicht mehr in die Rolle) — statt nur so zu tun. Das ist echtes persönliches Wachstum. Disziplin-Abgrenzung: Ein einzelner „keine-Lust"-Tag → trotzdem machen; **wiederkehrendes** Ausweichen über langen Zeitraum → dahinterliegendes Thema anschauen.

**Aufgabe:** Eine regelmäßig unterdrückte Emotion identifizieren und aufschreiben, was sie über die aktuelle Situation sagen könnte — ohne Selbstverurteilung.

## 06 · Druck, performen zu müssen

Leistungsdruck entsteht laut Nils nicht aus hohen Zielen, sondern aus der **Lücke zwischen dem Bild nach außen und dem, was man tatsächlich ist**. Sprach-Analyse als Kernbild: **ent-täuschen = das Ende der Täuschung.** Wer Angst hat, jemanden (z. B. einen Kunden) zu enttäuschen, hält irgendwo eine Täuschung/Maske aufrecht — projiziert ein Bild, das er noch nicht darstellt, oder verspricht Leistung, die er nicht halten kann. Diese Differenz erzeugt den Druck.

**Emotionale Schuldsteine:** Jedes Mal, wenn man nach außen ein besseres Bild gibt (der tolle Unternehmer, der große Bruder, das perfekte Instagram-Hotel-Foto), baut man einen „Schuldstein" auf den eigenen Schultern auf — emotionale Schulden sich selbst und anderen gegenüber. Über Freunde, Familie, Dating, Business hinweg entsteht eine ganze **Mauer**, die irgendwann erdrückt (bei Nils: Stressattacken, keine Lebensqualität, Familie/Urlaub nicht genießen können).

**Differenzierung:** Kein Aufruf zur schonungslosen Selbstentblößung — im Sales Call geht es um den Sales Call, nicht ums Jammern. Aber generell **Ehrlichkeit an den Tag legen**, v. a. bei Familie, Freunden, Mitarbeitern, Partnern. Bewusst entscheiden: Was teile ich, was nicht? Wenn Ehrlichkeit, Authentizität und Qualität deine Werte sind, verstößt die Maske gegen deine Werte → Overthinking, Prokrastination, Selbstzweifel, Stress. Der Ausweg: Mauer einreißen, ehrlich teilen, Business und Leben auf festen Boden stellen — auch wenn dabei Scham/Peinlichkeit/Frust zu fühlen sind.

**Aufgabe:** Eine Person/Situation wählen, in der man eine Rolle spielt, und diese Woche einmal echter/ehrlicher sein als bisher.

## 07 · Du musst es allen Menschen recht machen

People-Pleasing als Blockade. Das Gefühl, sich ständig nach Familie, Freunden, Kunden, Partner, Mitarbeitern richten zu müssen, damit man **nicht abgelehnt** wird. Klarstellung: Das ist oft ein **Schutzmechanismus**, kein reiner Altruismus. Mögliche Ursachen: sich nicht mit eigenen Themen auseinandersetzen wollen (leichter, anderen zu helfen), oder ein egoistischer Kern (man tut es, um selbst nicht abgelehnt zu werden).

**Die Kosten:** Wer immer nur einen Teil von sich zeigt, wird **auch nur für diesen Teil** gemocht — echte, tiefe Beziehungen entstehen nicht. Grenzen werden nicht gezogen, alles wird hineingefressen, bis es explodiert (Freundschaft/Zusammenarbeit wird abrupt gekündigt) — die andere Person versteht nicht, woher das kommt, weil nie klar kommuniziert wurde.

**Sauerstoffmasken-Prinzip:** Im Flugzeug zieht man **immer sich selbst zuerst** die Maske auf, dann Kindern/Bedürftigen. Wer sich verausgabt, kann anderen nicht mehr helfen. **Wasserglas-Metapher:** Ein leeres Glas kann kein Wasser in andere gießen. Erst auf sich achten, das eigene Glas füllen, klare Grenzen und Meinungen vertreten — nur dann kann man anderen wirklich Qualität geben. Konkret: Lieber in geiler Energy weniger Zeit mit Freunden, als viel Zeit mit schlechtem Gewissen und dem Gefühl „ich sollte arbeiten". Andere müssen die Grenzen nicht sofort verstehen.

**Aufgabe:** Diese Woche bewusst einmal Nein sagen / eine Grenze setzen, auch wenn es uncomfortable ist — und beobachten, was sich verändert.

## 08 · Das Gefühl von Überforderung

Eine der häufigsten Blockaden bei Selbstständigen: zu viele Aufgaben/Projekte, kein klarer Startpunkt → statt irgendwas zu tun, tut man **gar nichts**, fühlt sich gelähmt, verurteilt sich, hinterfragt das ganze Business, rutscht in eine Abwärtsspirale. Kernaussage: Überforderung ist kein Zeichen „es ist zu viel", sondern **ein Signal für unklare Prioritäten und fehlendes System**. Ausweg ist nicht mehr Motivation, sondern kleinere, konkrete Schritte.

**Gesetz:** *Inaction leads to more inaction. Action leads to more action.*

**Konkreter Ablauf, wenn man in der Spirale steckt:**
1. **Physisch und mental rauskommen** — aufstehen, raus, eine Runde um den Block, rauszoomen (Vogelperspektive). Fragen: Was habe ich schon erreicht, wo komme ich her? Ist das in 3 Tagen / 3 Monaten / 3 Jahren noch eine Herausforderung? (Meist nein → nimmt den Druck raus.)
2. **Alle Aufgaben aufschreiben.**
3. **Priorisieren** — was bringt Umsatz oder ist Grundlage dafür (z. B. Steuerthema)?
4. **Rausstreichen**, was gerade nicht gebraucht wird (Platzhalter nach hinten schieben).
5. Wichtige Aufgaben mit **Deadline** in den Kalender (inkl. Puffer), feste Termine sichten.
6. Große Projekte in **kleine Action Steps** unterteilen — je kleiner, desto leichter der Einstieg (erster Step kann „bei Google etwas eingeben" oder „nur über den Post nachdenken" sein).

Ergänzung: Bei Lähmung hilft es, erst **irgendetwas** zu tun (Spülmaschine ausräumen, kurz Sport), um Geschwindigkeit/Entscheidungsmomentum aufzunehmen. In so einer Spirale zu landen ist normal und menschlich — entscheidend ist der Umgang, dass man sich nicht darin verliert.

**Aufgabe:** Heute alle offenen Aufgaben aufschreiben, nach Umsatzrelevanz priorisieren, Unnötiges streichen, drei kleine Action Steps für morgen definieren.

## 09 · Evolutionspsychologische Sicht auf Ablehnung

Erklärt, **woher** die Angst vor Ablehnung kommt — allein dieses Bewusstsein bringt Erleichterung. Unser mentales System läuft auf **veralteter Software**. Vor ~100.000 Jahren lebten Menschen in Stämmen von 150–200; **Ausschluss aus der Gruppe bedeutete den sicheren Tod** (allein in der Wildnis nicht überlebensfähig, andere Gruppen nahmen niemanden auf). Ablehnung = Tod. Dieses Programm läuft immer noch, obwohl es heute völlig irrational ist: Lehnt jemand ein Angebot ab, passiert **rein gar nichts** — man hat weiter Essen, Freunde, Familie, finanzielle Mittel.

**Das Update:** Das System braucht bewusst ein Software-Update — durch **wiederholte Erfahrung**, dass Ablehnung nicht tötet. Anknüpfung Komfort- vs. Wachstumszone: Wenn man in der Wachstumszone oft genug abgelehnt wird und jedes Mal merkt „ich sterbe nicht", wird das Ergebnis zur **neuen Komfortzone** — das Gehirn lernt: „Wir können abgelehnt werden, ohne zu sterben." Entlastende Botschaft: Es stimmt nichts mit dir nicht — es ist ein veraltetes, allen Menschen gemeinsames System.

**Aufgabe:** Diese Woche gezielt 10 normalerweise prokrastinierte Nachrichten schreiben — mit dem Wissen: Die mögliche Ablehnung tötet dich nicht, sie trainiert dich.

## 10 · Umgang mit Ablehnung

Praktisches Konzept, das über Verkauf/Akquise hinaus fürs ganze Leben gilt. Kette: **Identität → Prozesse → Ergebnis.** Identität = dein Higher Self (der erfolgreich-entspannte Unternehmer). Prozesse = alles Anpassbare (Akquiseprozess, Angebot, Nachrichten, Auftreten, Artikulation). Diese Prozesse produzieren Ergebnisse.

**Der Denkfehler:** Bei einem unerwünschten Ergebnis (z. B. Call ohne Abschluss) schlussfolgern wir auf die **Identität** — „ich bin ein Loser". Das lehrt uns die Gesellschaft. Aber: **Ergebnisse sind kein Feedback für die Identität — sie sind immer nur Feedback für den Prozess.** Nicht du wirst abgelehnt, sondern dein Prozess. Keine Antwort auf eine Nachricht → der Prozess (Nachricht) wurde abgelehnt. Noch keine 100k/Monat → die Prozesse fehlen (kein Ad, kein Budget), nicht die Identität.

**Beispiel Dating:** Frau auf Party angesprochen, keine Nummer bekommen — nicht „ich bin ein Loser", sondern vielleicht war der Prozess (Energie, Ansprache, Timing) nicht passend. Wer diese Unterscheidung verinnerlicht, dem fällt die **emotionale Aufladung** und die Abwärtsspirale weg: „Okay, mein Prozess wurde nicht angenommen — nächsten Prozess anpassen." Aus Ergebnis → Erkenntnis → Prozess anpassen → neues Ergebnis. Wichtig: Prozess erst anpassen, wenn man etwas **wiederholt** gemacht hat, nicht nach einem einzigen Versuch.

**Aufgabe:** Den Akquise-Prozess aufschreiben, der gerade nicht die gewünschten Ergebnisse liefert; benennen, was konkret angepasst werden könnte, und die Anpassung nächste Woche konsequent testen.

## 11 · Ständiges Gedankenkarussell

Metapher gegen negative Gedanken/Emotionen: **Die Hunde im Park.** Du sitzt auf der Bank, um dich herum viele Hunde — du bist nicht einer davon, du bist der **Beobachter**. Übertragung: Die Hunde sind deine Gedanken und Emotionen. **Du bist nicht deine Gedanken/Emotionen — du hast sie.** Nicht alles, was du denkst, ist wahr; nicht alles, was du fühlst, bist du.

**Kernprinzip:** *Wogegen du dich widersetzt, setzt sich fest.* Gehst du auf einen aggressiven Hund los, um ihn zu „eliminieren", beißt er sich fest und wird stärker. Genauso Emotionen: Sagst du „die darf ich nicht haben", verstärken sie sich. Anknüpfung an das 0,1-% vs. 99,9-% aus Lektion 05 — das bewusste Ich kämpft gegen das Unterbewusstsein und verliert.

**Der 5-Stufen-Algorithmus** (in die Beobachterperspektive gehen und zu sich selbst sagen):
1. **Annehmen:** „Schön, dass du da bist."
2. **Einordnen:** „Ich weiß, du bist ein Gedanke/eine Emotion aus der Vergangenheit."
3. **Neutralisieren:** „Ich finde dich total interessant." (interessant = weder gut noch schlecht, gleichmütig — löst die Kraft des Gedankens).
4. **Situation prüfen:** Was ist die Situation, was interpretiere ich? (gern schriftlich).
5. **Perspektivwechsel:** „Was würde ich meiner besten Freundin / meinem Bruder / einem geliebten Menschen in genau dieser Situation sagen?" — und genau das sich selbst sagen.

Je öfter trainiert, desto besser. (Vgl. Dr. Joe Dispenza: 95 % der Gedanken kreisen um Vergangenheit/Zukunft; das Higher Self lebt im Jetzt.)

**Aufgabe:** Beim nächsten negativen Gedanken bewusst die Stufen 1–3 anwenden — mindestens dreimal diese Woche.

## 12 · Umgang mit dem inneren Kritiker

Der innere Kritiker ist kein Feind, sondern eine **schlecht gehörte Stimme**. Apple-Metapher: Am Vorstandstisch sitzen der Chief Innovation Officer (will das neue Produkt, „steck alles rein") und der CFO/„Devil's Advocate" (mahnt: „das müssen wir erst prüfen"). Ohne die kritische Finanzstimme wäre Apple schnell pleite. Wird der CFO aber vom ganzen Raum niedergebrüllt („halt's Maul, geh raus"), obwohl ihm die Firma wichtig ist, **meldet er sich lauter, plustert sich auf, nimmt den ganzen Raum ein** — weil er sich nicht gehört fühlt.

**Übertragung:** Dieser Tisch ist dein Kopf. Der innere Kritiker (bei Akquise: „mach das nicht", „poste das Bild nicht") hat eine echte **Schutzfunktion**. Ihn dauerhaft unterdrücken macht ihn lauter. Konstruktiver Umgang:
- **Gehör geben:** „Du bist gehört — erzähl mir, was du zu sagen hast, ich höre dich an, ich respektiere deine Meinung."
- **Argumente rational sortieren:** hilfreiche annehmen, unnütze (aus alter Angst) dankend ablehnen — „Danke, dass du mich schützen willst, aber ich poste das Bild trotzdem, weil es gut ist."
- So fühlt sich die Stimme gesehen/respektiert, **und man kommt trotzdem ins Handeln.**

Auch die reine Innovator-/Motivator-Stimme allein wäre schlecht — Kritik ist nötig. Der Kritiker will nichts Böses; er ist ein Teil von dir, der dich unterstützen will. (Dispenza: Herz-Gehirn-Kohärenz; aus dem Herzen statt aus der Angst entscheiden macht den Kritiker leiser.)

**Aufgabe:** Beim nächsten inneren Dialog aufschreiben, was der Kritiker sagt, was daran hilfreich ist, was nicht — und was die bewusste eigene Entscheidung trotzdem ist.

## 13 · Angst, höhere Preise zu nennen

Konkrete Blockade: Man kennt den eigenen Wert, aber im Sales Call kommt die höhere Zahl (1.500 → 2.000) nicht über die Lippen — man wird leise, stottert, verkauft unter Wert und ärgert sich danach. Eine Hauptursache liegt in der **Welt-Prägung** (vgl. Lektion 02): Aufgewachsen in einer Nicht-Unternehmerwelt, wo man für ~2.500–3.000 € rund 160 Std./Monat arbeitet, erscheint „10 Std. Arbeit = 3.000 €" unfair. In deinem Kopf **ist** es dann unfair.

**Die Umdeutung — du verkaufst keine Stunden, sondern Wert:** In der Selbstständigkeit gelten andere Gesetze. Frag: Was hat der Kunde davon? Meist mehr Zeit, Geld, Freiheit, Selbstverwirklichung. **Rechenbeispiel:** Ein Anwalt (250 €/Std.) braucht 3 Std./Woche für LinkedIn-Posts = 12 Std./Monat = 3.000 €, die du ihm allein an Zeitwert einsparst — plus Reichweite, Neukunden, Ansehen, weniger Stress, mehr Zeit mit der Familie (kaum in Geld zu fassen). Der **Return on Investment** des Kunden ist ein Vielfaches der Investition.

Preise sind weder richtig noch falsch — aber man **darf sich seines Wertes bewusst sein**. Konkret aufschreiben: Welchen Mehrwert (in Zeit, Geld, Freiheit) liefere ich? Das macht es leichter, höhere Preise zu nennen. (Vgl. [[Relevanz]] / Outcome-Denken: „Stop selling time, start buying it" — verkaufe nie eine Stunde, immer ein Ergebnis.)

**Aufgabe:** Diese Woche konkret ausrechnen, was der Kunde durch die Zusammenarbeit spart/gewinnt (in Euro und Stunden), die Zahl aufschreiben und vor dem nächsten Sales Call laut vorlesen.

## 14 · Möchtest du der Person nichts verkaufen?

Adressiert den Einwand „Ich will keine Akquise machen, ich will niemandem etwas verkaufen." Darunter liegt eine negative Bewertung von „Verkaufen". Entscheidende Umdeutung: **Im ersten Schritt geht es gar nicht ums Verkaufen, sondern ums Bedarf-Abchecken.** Alles Schritt für Schritt.

**Ablauf der Akquise:**
1. **Bedarf prüfen** (nicht Interesse — Unterschied!). Jemand kann Bedarf haben, ohne es zu wissen. Bei Versicherungen kennt man die Verträge noch nicht → checken. Bei Website/LinkedIn/Copywriting sieht man den Bedarf oft direkt (schlechte Seite/Texte/Auftritt).
2. **Offenheit prüfen** — ist die Person für den Bedarf offen? Wenn nicht: **Problembewusstsein schaffen** (nicht sofort abwimmeln lassen, wenn Bedarf klar da ist, aber Ausreden kommen).
3. **Finanzen prüfen** — hat die Person die Mittel? Die zwei Bedingungen sind **Bedarf + finanzielle Mittel.** Fehlt eins, gibt es keinen Grund, etwas „aufzuschwatzen" — genau das ist das negativ geprägte Bild vom Verkaufen.

Sind Bedarf und Budget da, **darfst du frei verkaufen und dich dabei gut fühlen** — Fokus auf den Mehrwert (mehr Geld → mehr Freiheit, Wachstum, Vertrauen, Sicherheit). Als Verkäufer bist du **Problemlöser**. Nützliche neue Glaubenssätze statt „ich gehe Leuten auf die Nerven": „Ich gebe Kunden das, was sie sich sehnlich wünschen", „Der ROI meines Kunden wird deutlich höher sein als seine Investition", „Die Person freut sich über die Möglichkeit, ihr Unternehmen wachsen zu lassen." Diese Glaubenssätze bewusst rausschreiben und verstärken.

**Aufgabe:** Diese Woche einer Person schreiben, bei der man Bedarf sieht — nicht mit dem Ziel zu verkaufen, sondern zu prüfen, ob Bedarf und Offenheit da sind. Eine ehrliche Nachricht.

## 15 · Verkaufen

Grundsätzliche Blockaden-Auflösung zum Thema Verkaufen. **Warum ist Verkaufen so wichtig?** Es findet immer statt — im Business (Produkt/Dienstleistung), als Angestellter (sich selbst vermarkten), beim Dating. Im Business ist **Cashflow das Blut des Unternehmens** (wie Blut im Körper), und Cashflow entsteht in 99 % der Fälle durch Verkaufen.

**Ist-Situation vs. Interpretation:** Verkaufen ist zunächst nur **Kommunikation** — „manipulativ / dreckig / abzocken" ist die aufgesetzte **Interpretation** (ein Glaubenssatz). Wortanalyse: **ver-kaufen = fair kaufen.** Du kannst nichts verkaufen, wenn es nicht gekauft wird — der **Käufer sitzt immer am längeren Hebel** und kann jederzeit Nein sagen (selbst unter Zwang bliebe das Nein möglich). Du hast **nie 100 % Kontrolle** über den Abschluss; du kannst nur dich, dein Produkt, deine Rahmenbedingungen bestmöglich platzieren (Skript, Artikulation, Auftreten).

**Ablehnung ist normal:** Metapher — durch die Straße gehen und fragen „willst du kaufen?"; oder im Drogeriemarkt zwischen 20 Deos wählt man eins, lehnt 19 ab. Selbst ein Arzt (Käufermarkt) kann nicht jedem etwas „verkaufen" — manche gehen aus Prinzip nicht zum Arzt. Es gibt Menschen, die Reiche ablehnen, und solche, die Arme ablehnen. Kernsatz: **Du wirst abgelehnt — du kannst nur wählen, wofür.** Für großen oder kleinen Erfolg?

**Wachstumszone positiv bewerten:** Verkaufen ist zunächst Wachstumszone. Bewertet man sie negativ, flieht man zurück in die Komfortzone (Metapher: Kind, das beim ersten Malen niedergemacht wird, will nie wieder malen). Verkaufen **positiv bewerten** → öfter machen → wird neue Komfortzone/Gewohnheit. Entscheidend ist, **überhaupt Ergebnisse zu produzieren**: Ergebnis → Erkenntnis → Korrektur → besseres Ergebnis. Wer Verkaufen vermeidet, nimmt sich die Möglichkeit, besser zu werden. Erinnerung: Vieles (z. B. Schuhe binden) konntest du mal nicht und kannst es jetzt — Verkaufen ist lernbar.

**Aufgabe:** Diese Woche mindestens fünf Verkaufs-Aktivitäten (Nachrichten, Calls, Angebote), jede danach **positiv bewerten** — egal welches Ergebnis — und notieren, was gelernt wurde.

## 16 · Du hast Angst davor, was andere über dich denken

Eine der häufigsten Blockaden gegen Sichtbarkeit und Umsetzung. Man grübelt, was Zielgruppe, Branchenkollegen, Partner oder Freunde denken → versucht, es allen recht zu machen → Dauerstress, langsameres Arbeiten, körperlich anwesend / gedanklich bei der Arbeit. **Fakt:** Es wird **immer** Menschen mit einer Meinung geben (auch zu diesem Video: super / egal / kompletter Müll).

**Der Kernmechanismus:** *Wovor du Angst hast, dass andere über dich denken, so denkst du meist über dich selbst.* Plakativ: Du hast keine Angst, jemand sagt „du siehst aus wie eine Palme" — weil du 100 % überzeugt bist, dass das nicht stimmt. Triggert dich aber „du arbeitest zu viel" oder „du willst mir nur was verkaufen", löst es eine negative Emotion aus → dort liegt dein **Triggerpunkt** und deine eigene Selbstverurteilung. Der Stress kommt nicht von der Meinung anderer, sondern davon, **wofür du dich selbst verurteilst.**

**Der Weg raus** ist nicht Gleichgültigkeit, sondern ein gefestigtes Selbstbild: Aufschreiben, wovor man Angst hat (was andere denken), dann fragen: „Warum verurteile ich mich dafür? Inwiefern verstößt das gegen mein Wertesystem?" — und das anpassen. Ziel: nicht es allen recht machen, sondern **es sich selbst recht machen.**

**Aufgabe:** Aufschreiben, welche Meinungen anderer am meisten triggern; dann fragen: „Wofür verurteile ich mich, wenn ich das denke?" Das ist der echte Startpunkt zur Veränderung.

## 17 · Egoismus im Verkauf

Provokante Umkehrung. Alle typischen Verkaufsängste — „ich will nicht abgelehnt werden", „ich will niemandem auf die Nerven gehen", „ich will nicht, dass man schlecht über mich denkt" — haben eine Gemeinsamkeit: **Ich, ich, ich.** Das ist im Kern **egoistisch**. Denn im Business geht es nicht um dich, sondern um deine **Mission**: Mehrwert stiften, Menschen helfen, positiven Impact schaffen.

**Spotlight-Effekt (Psychologie):** Wir **überschätzen** die Aufmerksamkeit, die wir bekommen. Niemand liegt abends im Bett und denkt schlecht über dich — alle sind mit sich selbst beschäftigt (Beispiele: Gym, Straße — jeder denkt, alle schauen ihn an). Das ist entlastend.

**Mindset-Shift:** Nicht fragen „Wie vermeide ich Ablehnung?", sondern „**Was kann ich Gutes für meine Kunden tun?**" — zwei völlig verschiedene Fragen. Mission/Why aktiv immer wieder abspielen (die Neuronen, die du feuerst, werden stärker; was du nicht abspielst, verblasst). **Unterlassene Hilfeleistung:** Wenn jemand ein Problem hat (Übergewicht, keine Reichweite, teure Verträge, Mindset-Blockaden) und du die Lösung, ist Schweigen wie an einem Hilfebedürftigen vorbeizugehen. Mit dieser Haltung verkauft man mit Lockerheit — weil man wirklich hilft.

**Aufgabe:** Das eigene „Warum" in einem Satz aufschreiben und vor dem nächsten Sales Call / der nächsten Akquise laut vorlesen.

## 18 · Prokrastination von Akquise

Warum man Akquise aufschiebt („ich will kein dreckiger Verkäufer / Manipulator / Wannabe sein"). Nils erzählt eine eigene Story (vgl. [[Storytelling-Content-Regeln]]): Vor der Selbstständigkeit bekam er auf Instagram unseriöse MLM-/Krypto-Nachrichten von „jungen Business-Typen mit roter Krawatte" und **bewertete sie als „Wannabes"**. Jahre später, beim eigenen Akquise-Start: „Ich will keine Nachrichten schreiben — die anderen könnten denken, ich sei ein Wannabe."

**Wo die Blockade wirklich entsteht:** Nicht dort, wo andere ihn verurteilen könnten, sondern dort, **wo er selbst andere verurteilt hat.** Die Personen zeigten nur ein **Verhalten** (eine Nachricht = eine Aneinanderreihung von Buchstaben); er legte eine **Identität** darüber („Wannabe-Unternehmer") und **verschmolz Verhalten und Identität**. Würde er nun selbst dieses Verhalten ausüben, wäre er selbst ein „Wannabe" → Blockade. Alles entsteht **in einem selbst**, durch die eigene Bewertung / den Widerstand gegen die Erfahrung.

**Die Auflösung — entwerten:**
- **Verhalten von Identität trennen:** „Ich habe eine Nachricht bekommen" — nicht „das sind Wannabes/Abzocker". (Man muss die Nachricht nicht toll finden, aber auch nicht schlecht — als Erfahrung neutral annehmen.) Wer eine ganze Branche mit einer negativen Identität verknüpft, lehnt automatisch einen Teil von sich selbst ab.
- **Neid erkennen:** Starke Emotional-Trigger deuten oft auf **Neid** (z. B. „die machen Akquise / haben etwas, wofür sie brennen — und ich nicht"). Ego runterschrauben, den Menschen **Anerkennung** geben: „Wer Akquise macht, ist ein Macher — er tut, was 95 % der Selbstständigen nicht tun." Nils beurteilt bei einer Nachricht nicht mehr das Was/Warum, sondern denkt „ist ein Macher".
- **Wertebasierte Akquise (zentrale Regel):** *Schreib niemals Nachrichten, die du selbst nicht bekommen möchtest; sag nie Dinge am Telefon, die du selbst nicht gesagt bekommen möchtest.* Handelt man gegen die eigenen Werte, sabotiert man sich selbst.

Wirkkette: Gedanken ändern → Emotionen ändern sich → Verhalten ändert sich.

**Aufgabe:** Heute eine Nachricht schreiben, die man selbst gern bekommen würde — mit vollem Fokus auf den Nutzen für die andere Person.

## 19 · Emotionale Achterbahn

Die schwankenden Emotionen, die stark **vom Umsatz/Output abhängen**: hoher Umsatz → „ich regiere die Welt"; schwacher Monat → „ich bin ein Versager". Problem der Identifikation mit dem Output: Man muss dann permanent hohen Output fahren, und bei einem Tief scheint die ganze Identität verloren.

**Was kannst du zu 100 % kontrollieren?** Netflix-Metapher: Ob du heute Suits schaust, kontrollierst du nicht (Server könnten down sein). Kontrollierbar sind nur zwei Dinge: deine **Handlung** und deine **Einstellung** (aufregen vs. „super, dann habe ich zwei Stunden zum Meditieren/Lesen"). Der **Output ist nie zu 100 % kontrollierbar** — deshalb Emotionen und Lebensqualität nicht daran festmachen.

**Fokus auf den Input** — drei Kontrollfragen:
1. Leistest du **genug** Input? (Quantität — z. B. nur einmal die Woche posten?)
2. Leistest du Input an den **richtigen Stellen**? (falsche Plattform?)
3. Leistest du **konsistenten** Input? (zu unregelmäßig?)

Modell: **Input → Prozess → Output.** Nur Input und Prozess sind steuerbar; der Output fällt unten raus. Bei einem Tief zuerst Input prüfen (dieselben drei Dinge wie in guten Phasen erfüllt?), dann den **Prozess** hinterfragen/anpassen. Und: Das schlechte Gefühl bei mangelndem Output **bewusst** — für begrenzte Zeit, **nicht** in Opferrolle über Tage/Wochen — wahrnehmen. Dieser Schmerz treibt das System zurück in die Umsetzung („das wollen wir nicht mehr fühlen") → man steht wieder von allein früh auf, bleibt länger dran, geht im Sales Call mutiger vor. (Vgl. Dispenza: Output-Abhängigkeit entsteht durch das Pendeln zwischen Vergangenheit/Zukunft; das Higher Self ist im Jetzt.)

**Aufgabe:** Benennen, in welchem Bereich man gerade auf der Achterbahn ist — und den Fokus vom Output (Umsatz, Reaktionen) vollständig auf den Input (tägliches Tun) verschieben.

## 20 · Abschluss Blockaden

Abschluss und Ausblick. Das Modul hat Impulse zu vielen Blockaden im Unternehmertum gegeben. Empfehlung: die Videos, mit denen man sich **am stärksten verbinden** konnte, immer wieder anschauen — und bei akut auftretenden Blockaden gezielt das passende Video erneut nutzen und auf die eigene aktuelle Situation übersetzen.

**Die wichtigsten Learnings des Moduls im Überblick:**
- Blockaden sind keine Fehler, sondern **evolutionär verankerte Schutzmechanismen**.
- Häufigste Blockaden im Coaching-/Solo-Business: Angst vor Ablehnung, Angst vorm Verkaufen, Prokrastination, innerer Kritiker, Perfektionismus.
- **Emotionen sind Informationen, keine Hindernisse** — es kommt auf den Umgang an.
- **Identität schlägt Verhalten:** Wer sich als erfolgreicher Coach/Unternehmer sieht, handelt automatisch anders.
- Blockaden lösen sich **nicht durch Willenskraft**, sondern durch Verständnis und neue Überzeugungen — Bewusstsein ist immer der erste Schritt.

**Ausblick:** Das Wissen wirkt erst durch konsequente **Anwendung im Alltag** — nicht alle Blockaden auf einmal überwinden, sondern erkennen und Schritt für Schritt anders reagieren. Im nächsten Modul (Modul 5) folgen konkrete **Übungen und Trainings**, um neue Glaubenssätze zu verankern und das Gelernte in eine **unbewusste Kompetenz** zu überführen.

**Aufgabe:** Die am stärksten treffende Blockade aus Modul 4 benennen und einen konkreten ersten Schritt festlegen — ab morgen, nicht ab nächster Woche.

---

## Übergreifende Muster (Modul-Synthese)

Durch alle Lektionen ziehen sich wiederkehrende Denkwerkzeuge, die das Modul als System zusammenhalten:

- **Kein richtig/falsch, nur „funktioniert es in deinem Wertesystem?"** (02, 04, 13, 14, 18) — Bewertung als menschliches Konstrukt; Selbstsabotage, wenn man gegen die eigenen Werte handelt.
- **Welten & Wert** (02, 03, 13) — jede Welt hat eigene Gesetze; Wert wird durch Handlung aufgebaut, nicht vorher gegeben.
- **Emotionen fühlen statt bewerten/unterdrücken** (04, 05, 06, 11) — 99,9 % unbewusst; Schmerz + Widerstand = Leid; Herdplatte; Beobachterperspektive.
- **Identität vs. Prozess/Verhalten** (10, 18, 20) — Ergebnisse sind Feedback für den Prozess, nicht für die Identität; Verhalten von Identität trennen.
- **Ablehnung neu einordnen** (09, 10, 15, 16) — evolutionäres Relikt; Ablehnung trifft den Prozess; „wofür wirst du abgelehnt?".
- **Fokus auf Input & kleine Schritte** (08, 19) — Kontrollierbares steuern (Input, Prozess, Handlung, Einstellung), Output loslassen.
- **Raus aus der Ich-Zentrierung** (07, 16, 17) — Sauerstoffmaske/Wasserglas, Spotlight-Effekt, Mission über Angst.

Verwandte Notizen: [[Inner GOAT Academy]], [[Storytelling Wissen]], [[Der Bruch als Bauplan]], [[Die 12 Plots]], [[Relevanz]].
